from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario

from .data import CalibrationCounts, ObservedCounts


def outcome_label(outcome: tuple[int, ...]) -> str:
    return ",".join(str(int(value)) for value in outcome)


def _normalize_label(value: object) -> str:
    text = str(value).strip().replace(" ", "")
    if len(text) >= 2 and text[0] in "([" and text[-1] in ")]":
        text = text[1:-1]
    return text.lower()


def counts_template(scenario: Scenario) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for context in scenario.contexts:
        for outcome in context.outcomes:
            rows.append(
                {"context": context.name, "outcome": outcome_label(outcome), "count": 0}
            )
        rows.append({"context": context.name, "outcome": "star", "count": 0})
    return pd.DataFrame(rows)


def channel_template(scenario: Scenario, *, default_retention: float = 1.0) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for context in scenario.contexts:
        for outcome in context.outcomes:
            rows.append(
                {
                    "context": context.name,
                    "outcome": outcome_label(outcome),
                    "retention": float(default_retention),
                }
            )
    return pd.DataFrame(rows)


def calibration_template(scenario: Scenario) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for context in scenario.contexts:
        for outcome in context.outcomes:
            rows.append(
                {
                    "context": context.name,
                    "outcome": outcome_label(outcome),
                    "successes": 0,
                    "total": 0,
                }
            )
    return pd.DataFrame(rows)


def observed_counts_to_frame(scenario: Scenario, counts: ObservedCounts) -> pd.DataFrame:
    counts.validate(scenario)
    rows: list[dict[str, object]] = []
    for context, block in zip(scenario.contexts, counts.counts_by_context, strict=True):
        for outcome, count in zip(context.outcomes, block[:-1], strict=True):
            rows.append(
                {
                    "context": context.name,
                    "outcome": outcome_label(outcome),
                    "count": int(count),
                }
            )
        rows.append(
            {"context": context.name, "outcome": "star", "count": int(block[-1])}
        )
    return pd.DataFrame(rows)


def channel_to_frame(scenario: Scenario, channel: Channel) -> pd.DataFrame:
    channel.validate(scenario)
    rows: list[dict[str, object]] = []
    for context, block in zip(
        scenario.contexts, channel.retention_by_context, strict=True
    ):
        for outcome, retention in zip(context.outcomes, block, strict=True):
            rows.append(
                {
                    "context": context.name,
                    "outcome": outcome_label(outcome),
                    "retention": float(retention),
                }
            )
    return pd.DataFrame(rows)


def calibration_to_frame(
    scenario: Scenario, calibration: CalibrationCounts
) -> pd.DataFrame:
    calibration.validate(scenario)
    rows: list[dict[str, object]] = []
    for context, successes, totals in zip(
        scenario.contexts,
        calibration.successes_by_context,
        calibration.totals_by_context,
        strict=True,
    ):
        for outcome, success, total in zip(
            context.outcomes, successes, totals, strict=True
        ):
            rows.append(
                {
                    "context": context.name,
                    "outcome": outcome_label(outcome),
                    "successes": int(success),
                    "total": int(total),
                }
            )
    return pd.DataFrame(rows)


def _indexed_rows(frame: pd.DataFrame, required: set[str]) -> dict[tuple[str, str], pd.Series]:
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"CSV is missing columns: {sorted(missing)}")
    indexed: dict[tuple[str, str], pd.Series] = {}
    for _, row in frame.iterrows():
        key = (str(row["context"]).strip(), _normalize_label(row["outcome"]))
        if key in indexed:
            raise ValueError(f"duplicate CSV row for context/outcome {key}")
        indexed[key] = row
    return indexed


def load_observed_counts(path: str | Path, scenario: Scenario) -> ObservedCounts:
    frame = pd.read_csv(path)
    indexed = _indexed_rows(frame, {"context", "outcome", "count"})
    blocks: list[np.ndarray] = []
    expected: set[tuple[str, str]] = set()
    for context in scenario.contexts:
        values: list[int] = []
        for outcome in context.outcomes:
            key = (context.name, _normalize_label(outcome_label(outcome)))
            expected.add(key)
            if key not in indexed:
                raise ValueError(f"missing count row for {key}")
            value = float(indexed[key]["count"])
            if not value.is_integer() or value < 0:
                raise ValueError(f"count must be a nonnegative integer for {key}")
            values.append(int(value))
        star_key = (context.name, "star")
        expected.add(star_key)
        if star_key not in indexed:
            raise ValueError(f"missing count row for {star_key}")
        star = float(indexed[star_key]["count"])
        if not star.is_integer() or star < 0:
            raise ValueError(f"star count must be a nonnegative integer in {context.name}")
        values.append(int(star))
        blocks.append(np.asarray(values, dtype=int))
    extras = set(indexed) - expected
    if extras:
        raise ValueError(f"unrecognized count rows: {sorted(extras)}")
    counts = ObservedCounts(tuple(blocks))
    counts.validate(scenario)
    return counts


def load_channel(path: str | Path, scenario: Scenario, *, name: str = "csv_channel") -> Channel:
    frame = pd.read_csv(path)
    indexed = _indexed_rows(frame, {"context", "outcome", "retention"})
    blocks: list[np.ndarray] = []
    expected: set[tuple[str, str]] = set()
    for context in scenario.contexts:
        values: list[float] = []
        for outcome in context.outcomes:
            key = (context.name, _normalize_label(outcome_label(outcome)))
            expected.add(key)
            if key not in indexed:
                raise ValueError(f"missing channel row for {key}")
            value = float(indexed[key]["retention"])
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"retention must lie in [0,1] for {key}")
            values.append(value)
        blocks.append(np.asarray(values, dtype=float))
    extras = set(indexed) - expected
    if extras:
        raise ValueError(f"unrecognized channel rows: {sorted(extras)}")
    channel = Channel(name=name, retention_by_context=tuple(blocks))
    channel.validate(scenario)
    return channel


def load_calibration_counts(path: str | Path, scenario: Scenario) -> CalibrationCounts:
    frame = pd.read_csv(path)
    indexed = _indexed_rows(
        frame, {"context", "outcome", "successes", "total"}
    )
    successes_blocks: list[np.ndarray] = []
    total_blocks: list[np.ndarray] = []
    expected: set[tuple[str, str]] = set()
    for context in scenario.contexts:
        successes: list[int] = []
        totals: list[int] = []
        for outcome in context.outcomes:
            key = (context.name, _normalize_label(outcome_label(outcome)))
            expected.add(key)
            if key not in indexed:
                raise ValueError(f"missing calibration row for {key}")
            success = float(indexed[key]["successes"])
            total = float(indexed[key]["total"])
            if not success.is_integer() or not total.is_integer():
                raise ValueError(f"calibration counts must be integers for {key}")
            if not 0 <= success <= total:
                raise ValueError(f"calibration requires 0 <= successes <= total for {key}")
            successes.append(int(success))
            totals.append(int(total))
        successes_blocks.append(np.asarray(successes, dtype=int))
        total_blocks.append(np.asarray(totals, dtype=int))
    extras = set(indexed) - expected
    if extras:
        raise ValueError(f"unrecognized calibration rows: {sorted(extras)}")
    result = CalibrationCounts(tuple(successes_blocks), tuple(total_blocks))
    result.validate(scenario)
    return result
