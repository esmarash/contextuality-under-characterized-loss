# CSV data contract

The `fmci-analyze` command consumes three long-form CSV files. Context names and
outcome labels must match the selected built-in scenario exactly. Spaces and
outer parentheses/brackets in outcome labels are ignored.

## Observed counts

Required columns:

```text
context,outcome,count
```

For every context include one row for each complete detected outcome and one
row with outcome `star`. Counts are nonnegative integers. The star row denotes
attempted trials in that context for which no complete outcome was observed.

Example:

```csv
context,outcome,count
C12,"-1,-1",42
C12,"-1,1",501
C12,"1,-1",497
C12,"1,1",39
C12,star,588
```

The total attempted trials are the sum of all detected and star counts. Rows
must not be duplicated or omitted.

## Declared channel

Required columns:

```text
context,outcome,retention
```

There is one row per complete outcome and no star row. `retention` is the
conditional probability in `[0,1]` that the complete outcome is retained rather
than mapped to star.

Example:

```csv
context,outcome,retention
C12,"-1,-1",0.8
C12,"-1,1",0.8
C12,"1,-1",0.8
C12,"1,1",0.8
```

This file is a scientific model, not merely a convenience parameter. Its common
transport across the empirical and noncontextual models is a validity
assumption.

## Independent calibration counts

Optional required columns when supplied:

```text
context,outcome,successes,total
```

For each complete cell, `successes` is the number retained and `total` is the
number challenged in calibration, with integer constraints
`0 <= successes <= total`.

Example:

```csv
context,outcome,successes,total
C12,"-1,-1",642,800
C12,"-1,1",637,800
C12,"1,-1",646,800
C12,"1,1",639,800
```

The software constructs a simultaneous confidence box and reports whether the
declared channel lies inside it. A point channel remaining inside the box does
not itself propagate calibration uncertainty; use the sensitivity workflow for
a union over compatible channels.

## Built-in scenario labels

Generate templates programmatically to avoid transcription errors:

```python
from fmci_benchmarks.scenarios import get_scenario
from fmci_inference.io import counts_template, channel_template, calibration_template

scenario = get_scenario("three_cycle")
counts_template(scenario).to_csv("counts_template.csv", index=False)
channel_template(scenario).to_csv("channel_template.csv", index=False)
calibration_template(scenario).to_csv("calibration_template.csv", index=False)
```

Available scenario keys are `three_cycle`, `kcbs`, and `magic_square`.

## Output JSON

The report contains:

- attempted, detected, and star trial totals;
- channel identification and conditioning diagnostics;
- calibration-box compatibility when calibration is supplied;
- full and observed divergences, absolute loss, FMCI, delta intervals, Fieller
  set, and regularity classification;
- canonical contextuality-game successes, transported noncontextual bound,
  exact binomial tail, optional memory-robust label, optional pre-specified
  e-value, and raw observed generalized likelihood-ratio diagnostic;
- a machine-readable recommendation on whether scalar FMCI reporting is stable.

## Arbitrary sensitivity candidate manifest

`fmci-sensitivity --candidates` accepts a long-form CSV with required columns:

```text
candidate_id,context,outcome,retention
```

Each candidate must contain exactly one row for every complete outcome cell.
Optional numeric columns beginning with `parameter_` are copied into the output
and must be constant within a candidate. Example:

```csv
candidate_id,context,outcome,retention,parameter_eta,parameter_alpha
0,C12,"-1,-1",0.80,0.80,0.70
0,C12,"-1,1",0.80,0.80,0.70
...
1,C12,"-1,-1",0.82,0.82,0.70
```

The candidate grid is a computational approximation to the declared mechanism
family. Scientific conclusions require either exact inclusion of the true
candidate, a justified mesh-enclosure argument, or continuous optimization and
verified refinement around extrema and tipping contours.
