from __future__ import annotations

import itertools
import math
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

import numpy as np
from scipy.special import expit, logit
from scipy.stats import beta, qmc

from fmci_benchmarks.channels import Channel, three_cycle_eta_alpha_channel
from fmci_benchmarks.model import Scenario

from .data import CalibrationCounts, ObservedCounts
from .estimands import estimate_fmci
from .identification import IdentificationError, identification_report
from .inference import RegularInference, regular_inference
from .testing import witness_test


@dataclass(frozen=True)
class CalibrationBox:
    lower_by_context: tuple[np.ndarray, ...]
    upper_by_context: tuple[np.ndarray, ...]
    confidence_level: float
    familywise_method: str

    def contains(self, scenario: Scenario, channel: Channel, *, tolerance: float = 1e-12) -> bool:
        channel.validate(scenario)
        return all(
            np.all(np.asarray(rates) >= lower - tolerance)
            and np.all(np.asarray(rates) <= upper + tolerance)
            for rates, lower, upper in zip(
                channel.retention_by_context,
                self.lower_by_context,
                self.upper_by_context,
                strict=True,
            )
        )


@dataclass(frozen=True)
class ChannelCandidate:
    channel: Channel
    parameters: Mapping[str, float]


@dataclass(frozen=True)
class SensitivityRecord:
    parameters: Mapping[str, float]
    calibration_compatible: bool
    identified: bool
    minimum_retention: float
    condition_number: float
    full_divergence: float
    observed_divergence: float
    absolute_loss: float
    fmci: float
    fmci_ci_lower: float
    fmci_ci_upper: float
    fmci_ci_kind: str
    regularity_classification: str
    witness_pvalue: float
    witness_win_rate: float
    witness_null_bound: float
    message: str


@dataclass(frozen=True)
class SensitivityEnvelope:
    records: tuple[SensitivityRecord, ...]
    compatible_records: int
    point_fmci_range: tuple[float, float]
    union_fmci_interval: tuple[float, float]
    full_divergence_range: tuple[float, float]
    observed_divergence_range: tuple[float, float]
    pvalue_range: tuple[float, float]
    conservative_witness_pvalue: float
    calibration_adjusted_witness_pvalue: float
    combined_coverage_lower_bound: float
    tipping_parameters: tuple[Mapping[str, float], ...]


def simultaneous_clopper_pearson_box(
    scenario: Scenario,
    calibration: CalibrationCounts,
    *,
    confidence: float = 0.975,
) -> CalibrationBox:
    """Bonferroni-simultaneous exact binomial intervals for all detector cells."""

    calibration.validate(scenario)
    if not 0.0 < confidence < 1.0:
        raise ValueError("confidence must lie in (0,1)")
    number_of_cells = int(sum(len(context.outcomes) for context in scenario.contexts))
    family_alpha = 1.0 - confidence
    cell_alpha = family_alpha / number_of_cells
    lower_blocks: list[np.ndarray] = []
    upper_blocks: list[np.ndarray] = []
    for successes, totals in zip(
        calibration.successes_by_context,
        calibration.totals_by_context,
        strict=True,
    ):
        lower = np.empty_like(np.asarray(successes, dtype=float))
        upper = np.empty_like(np.asarray(successes, dtype=float))
        for i, (k, n) in enumerate(zip(successes, totals, strict=True)):
            k_int = int(k)
            n_int = int(n)
            if n_int <= 0:
                lower[i], upper[i] = 0.0, 1.0
                continue
            lower[i] = (
                0.0
                if k_int == 0
                else float(beta.ppf(cell_alpha / 2.0, k_int, n_int - k_int + 1))
            )
            upper[i] = (
                1.0
                if k_int == n_int
                else float(
                    beta.ppf(
                        1.0 - cell_alpha / 2.0,
                        k_int + 1,
                        n_int - k_int,
                    )
                )
            )
        lower_blocks.append(lower)
        upper_blocks.append(upper)
    return CalibrationBox(
        lower_by_context=tuple(lower_blocks),
        upper_by_context=tuple(upper_blocks),
        confidence_level=confidence,
        familywise_method="Bonferroni Clopper-Pearson",
    )


def three_cycle_eta_alpha_candidates(
    scenario: Scenario,
    *,
    eta_values: Sequence[float],
    alpha_values: Sequence[float],
) -> tuple[ChannelCandidate, ...]:
    if scenario.key != "three_cycle":
        raise ValueError("eta-alpha family is defined only for three_cycle")
    values: list[ChannelCandidate] = []
    for eta, alpha in itertools.product(eta_values, alpha_values):
        channel = three_cycle_eta_alpha_channel(scenario, float(eta), float(alpha))
        values.append(
            ChannelCandidate(channel=channel, parameters={"eta": float(eta), "alpha": float(alpha)})
        )
    return tuple(values)


def logit_tilt_candidates(
    scenario: Scenario,
    base_channel: Channel,
    feature_by_context: tuple[np.ndarray, ...],
    theta_axes: Sequence[Sequence[float]],
    *,
    parameter_names: Sequence[str] | None = None,
    clipping: float = 1.0e-6,
) -> tuple[ChannelCandidate, ...]:
    """Generate a multidimensional log-odds selection-bias family.

    ``logit(a_ci(theta)) = logit(a_ci(0)) + z_ci^T theta``.  A one-unit
    change in a component multiplies the corresponding detection odds by
    ``exp(z)``.
    """

    base_channel.validate(scenario)
    dimension = len(theta_axes)
    if dimension == 0:
        raise ValueError("theta_axes cannot be empty")
    if parameter_names is None:
        parameter_names = tuple(f"theta_{j + 1}" for j in range(dimension))
    if len(parameter_names) != dimension:
        raise ValueError("parameter_names has the wrong length")
    # A one-dimensional feature block is accepted for a one-parameter family;
    # otherwise blocks must have shape (events, dimension).
    normalized_features: list[np.ndarray] = []
    for context, feature in zip(
        scenario.contexts, feature_by_context, strict=True
    ):
        z = np.asarray(feature, dtype=float)
        if dimension == 1 and z.shape == (len(context.outcomes),):
            z = z[:, None]
        if z.shape != (len(context.outcomes), dimension):
            raise ValueError(f"feature shape mismatch in {context.name}")
        normalized_features.append(z)
    candidates: list[ChannelCandidate] = []
    for theta_tuple in itertools.product(*theta_axes):
        theta = np.asarray(theta_tuple, dtype=float)
        blocks: list[np.ndarray] = []
        for base, z in zip(
            base_channel.retention_by_context, normalized_features, strict=True
        ):
            base_safe = np.clip(np.asarray(base, dtype=float), clipping, 1.0 - clipping)
            blocks.append(expit(logit(base_safe) + z @ theta))
        parameters = {
            str(name): float(value)
            for name, value in zip(parameter_names, theta, strict=True)
        }
        candidates.append(
            ChannelCandidate(
                channel=Channel(
                    name="logit_tilt",
                    retention_by_context=tuple(blocks),
                    parameters=parameters,
                ),
                parameters=parameters,
            )
        )
    return tuple(candidates)


def sobol_parameter_points(
    bounds: Sequence[tuple[float, float]],
    *,
    points: int,
    seed: int = 20260713,
) -> np.ndarray:
    """Space-filling Sobol points for higher-dimensional sensitivity domains."""

    if points <= 0:
        raise ValueError("points must be positive")
    lower = np.asarray([item[0] for item in bounds], dtype=float)
    upper = np.asarray([item[1] for item in bounds], dtype=float)
    if np.any(upper <= lower):
        raise ValueError("every upper bound must exceed its lower bound")
    dimension = len(bounds)
    sampler = qmc.Sobol(d=dimension, scramble=True, seed=seed)
    exponent = int(math.ceil(math.log2(points)))
    unit = sampler.random_base2(exponent)[:points]
    return qmc.scale(unit, lower, upper)


def _fieller_hull(inference: RegularInference) -> tuple[float, float, str]:
    intervals = inference.fieller.fmci_intervals
    if not intervals:
        return math.nan, math.nan, inference.fieller.kind
    return (
        float(min(interval[0] for interval in intervals)),
        float(max(interval[1] for interval in intervals)),
        inference.fieller.kind,
    )


def run_sensitivity_analysis(
    scenario: Scenario,
    counts: ObservedCounts,
    candidates: Iterable[ChannelCandidate],
    *,
    calibration_box: CalibrationBox | None = None,
    conditional_confidence: float = 0.975,
    calibration_confidence: float | None = None,
    fmci_tipping_threshold: float = 0.5,
    randomized_contexts_verified: bool = False,
    context_unpredictability_verified: bool = False,
    channel_independently_fixed: bool = False,
    score_prespecified: bool = True,
) -> SensitivityEnvelope:
    """Evaluate FMCI and contextuality evidence over a declared channel family.

    If a simultaneous calibration box and conditional confidence intervals are
    used, the union interval has a conservative Bonferroni coverage lower bound
    of ``1 - alpha_calibration - alpha_conditional``, conditional on the true
    channel lying in the declared family and being represented by the grid.
    """

    records: list[SensitivityRecord] = []
    tipping: list[Mapping[str, float]] = []
    for candidate in candidates:
        compatible = (
            True
            if calibration_box is None
            else calibration_box.contains(scenario, candidate.channel)
        )
        report = identification_report(scenario, candidate.channel)
        if not compatible:
            records.append(
                SensitivityRecord(
                    parameters=dict(candidate.parameters),
                    calibration_compatible=False,
                    identified=report.point_identified,
                    minimum_retention=report.minimum_retention,
                    condition_number=report.worst_condition_number,
                    full_divergence=math.nan,
                    observed_divergence=math.nan,
                    absolute_loss=math.nan,
                    fmci=math.nan,
                    fmci_ci_lower=math.nan,
                    fmci_ci_upper=math.nan,
                    fmci_ci_kind="not-evaluated",
                    regularity_classification="calibration-incompatible",
                    witness_pvalue=math.nan,
                    witness_win_rate=math.nan,
                    witness_null_bound=math.nan,
                    message="candidate lies outside the simultaneous calibration box",
                )
            )
            continue
        if not report.point_identified:
            records.append(
                SensitivityRecord(
                    parameters=dict(candidate.parameters),
                    calibration_compatible=True,
                    identified=False,
                    minimum_retention=report.minimum_retention,
                    condition_number=report.worst_condition_number,
                    full_divergence=math.nan,
                    observed_divergence=math.nan,
                    absolute_loss=math.nan,
                    fmci=math.nan,
                    fmci_ci_lower=math.nan,
                    fmci_ci_upper=math.nan,
                    fmci_ci_kind="partial-identification-required",
                    regularity_classification="not-identified",
                    witness_pvalue=math.nan,
                    witness_win_rate=math.nan,
                    witness_null_bound=math.nan,
                    message="candidate channel does not point-identify the complete behavior",
                )
            )
            continue
        try:
            estimate = estimate_fmci(scenario, counts, candidate.channel)
            infer = regular_inference(
                scenario,
                counts,
                candidate.channel,
                estimate,
                confidence=conditional_confidence,
            )
            lower, upper, kind = _fieller_hull(infer)
            # No e-value is computed here: learning a Bernoulli alternative from
            # the same tested data would violate the pre-specification condition.
            test = witness_test(
                scenario,
                counts,
                candidate.channel,
                randomized_contexts_verified=randomized_contexts_verified,
                context_unpredictability_verified=context_unpredictability_verified,
                channel_independently_fixed=channel_independently_fixed,
                score_prespecified=score_prespecified,
            )
            message = "ok" if infer.diagnostics.classification == "regular" else "; ".join(
                infer.diagnostics.reasons
            )
            record = SensitivityRecord(
                parameters=dict(candidate.parameters),
                calibration_compatible=True,
                identified=True,
                minimum_retention=report.minimum_retention,
                condition_number=report.worst_condition_number,
                full_divergence=estimate.full_divergence,
                observed_divergence=estimate.observed_divergence,
                absolute_loss=estimate.absolute_loss,
                fmci=estimate.fmci,
                fmci_ci_lower=lower,
                fmci_ci_upper=upper,
                fmci_ci_kind=kind,
                regularity_classification=infer.diagnostics.classification,
                witness_pvalue=(
                    test.memory_robust_winlose_pvalue
                    if test.memory_robust_winlose_pvalue is not None
                    else math.nan
                ),
                witness_win_rate=test.observed_win_rate,
                witness_null_bound=test.transported_noncontextual_win_bound,
                message=message,
            )
            if np.isfinite(upper) and upper >= fmci_tipping_threshold:
                tipping.append(dict(candidate.parameters))
        except (IdentificationError, RuntimeError, ValueError, FloatingPointError) as exc:
            record = SensitivityRecord(
                parameters=dict(candidate.parameters),
                calibration_compatible=True,
                identified=report.point_identified,
                minimum_retention=report.minimum_retention,
                condition_number=report.worst_condition_number,
                full_divergence=math.nan,
                observed_divergence=math.nan,
                absolute_loss=math.nan,
                fmci=math.nan,
                fmci_ci_lower=math.nan,
                fmci_ci_upper=math.nan,
                fmci_ci_kind="failed",
                regularity_classification="failed",
                witness_pvalue=math.nan,
                witness_win_rate=math.nan,
                witness_null_bound=math.nan,
                message=str(exc),
            )
        records.append(record)

    usable = [
        record
        for record in records
        if record.calibration_compatible and np.isfinite(record.fmci)
    ]
    if not usable:
        return SensitivityEnvelope(
            records=tuple(records),
            compatible_records=0,
            point_fmci_range=(math.nan, math.nan),
            union_fmci_interval=(math.nan, math.nan),
            full_divergence_range=(math.nan, math.nan),
            observed_divergence_range=(math.nan, math.nan),
            pvalue_range=(math.nan, math.nan),
            conservative_witness_pvalue=math.nan,
            calibration_adjusted_witness_pvalue=math.nan,
            combined_coverage_lower_bound=0.0,
            tipping_parameters=tuple(tipping),
        )
    point_range = (
        float(min(record.fmci for record in usable)),
        float(max(record.fmci for record in usable)),
    )
    finite_lower = [record.fmci_ci_lower for record in usable if np.isfinite(record.fmci_ci_lower)]
    finite_upper = [record.fmci_ci_upper for record in usable if np.isfinite(record.fmci_ci_upper)]
    union = (
        float(min(finite_lower)) if finite_lower else 0.0,
        float(max(finite_upper)) if finite_upper else 1.0,
    )
    if calibration_box is None:
        calibration_alpha = 0.0
    else:
        calibration_level = (
            calibration_box.confidence_level
            if calibration_confidence is None
            else calibration_confidence
        )
        calibration_alpha = 1.0 - calibration_level
    conditional_alpha = 1.0 - conditional_confidence
    combined = max(0.0, 1.0 - calibration_alpha - conditional_alpha)
    finite_pvalues = [
        float(record.witness_pvalue)
        for record in usable
        if np.isfinite(record.witness_pvalue)
    ]
    if finite_pvalues:
        pvalue_range = (float(min(finite_pvalues)), float(max(finite_pvalues)))
        conservative_pvalue = pvalue_range[1]
        # If the independently generated calibration set misses the true channel
        # with probability at most alpha_calibration, adding that error budget
        # yields a conservative unconditional p-value. This remains conditional
        # on the declared family containing the true channel and on the verified
        # randomized-setting assumptions.
        adjusted_pvalue = min(1.0, conservative_pvalue + calibration_alpha)
    else:
        pvalue_range = (math.nan, math.nan)
        conservative_pvalue = math.nan
        adjusted_pvalue = math.nan
    return SensitivityEnvelope(
        records=tuple(records),
        compatible_records=len(usable),
        point_fmci_range=point_range,
        union_fmci_interval=union,
        full_divergence_range=(
            float(min(record.full_divergence for record in usable)),
            float(max(record.full_divergence for record in usable)),
        ),
        observed_divergence_range=(
            float(min(record.observed_divergence for record in usable)),
            float(max(record.observed_divergence for record in usable)),
        ),
        pvalue_range=pvalue_range,
        conservative_witness_pvalue=conservative_pvalue,
        calibration_adjusted_witness_pvalue=adjusted_pvalue,
        combined_coverage_lower_bound=combined,
        tipping_parameters=tuple(tipping),
    )
