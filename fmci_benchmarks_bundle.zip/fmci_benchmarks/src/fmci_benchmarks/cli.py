from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import yaml

from .experiments import run_all


_DEFAULTS: dict[str, Any] = {
    "output": "outputs",
    "visibility_points": 101,
    "eta_points": 51,
    "alpha_points": 51,
    "runtime_repetitions": 25,
}


def _load_config(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    payload = yaml.safe_load(path.read_text())
    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise ValueError("configuration file must contain a mapping")
    unknown = set(payload) - set(_DEFAULTS)
    if unknown:
        raise ValueError(f"unknown configuration keys: {sorted(unknown)}")
    return payload


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the unified FMCI contextuality benchmark suite."
    )
    parser.add_argument(
        "--config",
        type=Path,
        help="optional YAML configuration file",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="directory for CSV, JSON, report, and figure outputs",
    )
    parser.add_argument("--visibility-points", type=int)
    parser.add_argument("--eta-points", type=int)
    parser.add_argument("--alpha-points", type=int)
    parser.add_argument("--runtime-repetitions", type=int)
    parser.add_argument(
        "--quick",
        action="store_true",
        help="use small grids and one timing repetition for a smoke run",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    values = dict(_DEFAULTS)
    values.update(_load_config(args.config))
    for key in (
        "output",
        "visibility_points",
        "eta_points",
        "alpha_points",
        "runtime_repetitions",
    ):
        command_value = getattr(args, key)
        if command_value is not None:
            values[key] = command_value
    if args.quick:
        values.update(
            {
                "visibility_points": 11,
                "eta_points": 11,
                "alpha_points": 11,
                "runtime_repetitions": 1,
            }
        )
    output = Path(values.pop("output"))
    headline = run_all(output, **values)
    print(json.dumps(headline, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
