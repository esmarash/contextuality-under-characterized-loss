from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict
from pathlib import Path
from typing import Any, Sequence

import numpy as np
import pandas as pd

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.scenarios import get_scenario, list_scenarios

from .io import _normalize_label, load_calibration_counts, load_observed_counts, outcome_label
from .sensitivity import (
    ChannelCandidate,
    run_sensitivity_analysis,
    simultaneous_clopper_pearson_box,
    three_cycle_eta_alpha_candidates,
)


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def load_candidate_manifest(path: Path, scenario) -> tuple[ChannelCandidate, ...]:
    """Load an arbitrary channel family from one long-form CSV manifest.

    Required columns are ``candidate_id``, ``context``, ``outcome``, and
    ``retention``. Optional columns beginning with ``parameter_`` are copied to
    the candidate parameter dictionary and must be constant within a candidate.
    """

    frame = pd.read_csv(path)
    required = {"candidate_id", "context", "outcome", "retention"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"candidate manifest is missing columns: {sorted(missing)}")
    parameter_columns = [column for column in frame.columns if column.startswith("parameter_")]
    candidates: list[ChannelCandidate] = []
    for candidate_id, group in frame.groupby("candidate_id", sort=False, dropna=False):
        indexed: dict[tuple[str, str], pd.Series] = {}
        for _, row in group.iterrows():
            key = (str(row["context"]).strip(), _normalize_label(row["outcome"]))
            if key in indexed:
                raise ValueError(f"duplicate row for candidate {candidate_id!r}, cell {key}")
            indexed[key] = row
        blocks: list[np.ndarray] = []
        expected: set[tuple[str, str]] = set()
        for context in scenario.contexts:
            values: list[float] = []
            for outcome in context.outcomes:
                key = (context.name, _normalize_label(outcome_label(outcome)))
                expected.add(key)
                if key not in indexed:
                    raise ValueError(f"candidate {candidate_id!r} is missing cell {key}")
                retention = float(indexed[key]["retention"])
                if not 0.0 <= retention <= 1.0:
                    raise ValueError(
                        f"candidate {candidate_id!r} retention must lie in [0,1] for {key}"
                    )
                values.append(retention)
            blocks.append(np.asarray(values, dtype=float))
        extras = set(indexed) - expected
        if extras:
            raise ValueError(
                f"candidate {candidate_id!r} has unrecognized cells: {sorted(extras)}"
            )
        parameters: dict[str, float] = {}
        for column in parameter_columns:
            numeric = pd.to_numeric(group[column], errors="coerce").dropna().unique()
            if numeric.size > 1:
                raise ValueError(
                    f"parameter column {column!r} is not constant in candidate {candidate_id!r}"
                )
            if numeric.size == 1:
                parameters[column.removeprefix("parameter_")] = float(numeric[0])
        parameters.setdefault("candidate_index", float(len(candidates)))
        channel = Channel(
            name=f"candidate_{candidate_id}",
            retention_by_context=tuple(blocks),
            parameters=parameters,
        )
        channel.validate(scenario)
        candidates.append(ChannelCandidate(channel=channel, parameters=parameters))
    if not candidates:
        raise ValueError("candidate manifest contains no candidates")
    return tuple(candidates)


def _records_frame(envelope) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for record in envelope.records:
        row = {f"parameter_{key}": value for key, value in record.parameters.items()}
        row.update({key: value for key, value in asdict(record).items() if key != "parameters"})
        rows.append(row)
    return pd.DataFrame(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run a calibration-constrained MNAR sensitivity analysis."
    )
    parser.add_argument("--scenario", choices=list_scenarios(), required=True)
    parser.add_argument("--counts", type=Path, required=True)
    parser.add_argument("--calibration", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, required=True)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--candidates",
        type=Path,
        help="long-form arbitrary channel-candidate CSV manifest",
    )
    source.add_argument(
        "--eta-alpha",
        action="store_true",
        help="use the built-in three-cycle eta-alpha family",
    )
    parser.add_argument("--eta-min", type=float, default=0.0)
    parser.add_argument("--eta-max", type=float, default=1.0)
    parser.add_argument("--eta-points", type=int, default=21)
    parser.add_argument("--alpha-min", type=float, default=0.0)
    parser.add_argument("--alpha-max", type=float, default=1.0)
    parser.add_argument("--alpha-points", type=int, default=21)
    parser.add_argument("--conditional-confidence", type=float, default=0.975)
    parser.add_argument("--calibration-confidence", type=float, default=0.975)
    parser.add_argument("--tipping-threshold", type=float, default=0.5)
    parser.add_argument("--verify-randomized-contexts", action="store_true")
    parser.add_argument("--verify-context-unpredictability", action="store_true")
    parser.add_argument("--verify-independent-channel", action="store_true")
    parser.add_argument("--score-not-prespecified", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    scenario = get_scenario(args.scenario)
    counts = load_observed_counts(args.counts, scenario)
    calibration_box = None
    if args.calibration is not None:
        calibration = load_calibration_counts(args.calibration, scenario)
        calibration_box = simultaneous_clopper_pearson_box(
            scenario, calibration, confidence=args.calibration_confidence
        )
    if args.candidates is not None:
        candidates = load_candidate_manifest(args.candidates, scenario)
        family_metadata: dict[str, Any] = {
            "type": "candidate_manifest",
            "path": str(args.candidates),
        }
    else:
        if scenario.key != "three_cycle":
            raise ValueError("the eta-alpha family is available only for three_cycle")
        if args.eta_points < 2 or args.alpha_points < 2:
            raise ValueError("eta-points and alpha-points must be at least two")
        if not 0.0 <= args.eta_min <= args.eta_max <= 1.0:
            raise ValueError("eta bounds must satisfy 0 <= min <= max <= 1")
        if not 0.0 <= args.alpha_min <= args.alpha_max <= 1.0:
            raise ValueError("alpha bounds must satisfy 0 <= min <= max <= 1")
        eta_values = np.linspace(args.eta_min, args.eta_max, args.eta_points)
        alpha_values = np.linspace(args.alpha_min, args.alpha_max, args.alpha_points)
        candidates = three_cycle_eta_alpha_candidates(
            scenario, eta_values=eta_values, alpha_values=alpha_values
        )
        family_metadata = {
            "type": "three_cycle_eta_alpha",
            "eta_values": eta_values.tolist(),
            "alpha_values": alpha_values.tolist(),
        }
    envelope = run_sensitivity_analysis(
        scenario,
        counts,
        candidates,
        calibration_box=calibration_box,
        conditional_confidence=args.conditional_confidence,
        calibration_confidence=(
            args.calibration_confidence if calibration_box is not None else None
        ),
        fmci_tipping_threshold=args.tipping_threshold,
        randomized_contexts_verified=args.verify_randomized_contexts,
        context_unpredictability_verified=args.verify_context_unpredictability,
        channel_independently_fixed=args.verify_independent_channel,
        score_prespecified=not args.score_not_prespecified,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame = _records_frame(envelope)
    frame.to_csv(args.output_dir / "sensitivity_scan.csv", index=False)
    summary = {
        "scenario": scenario.key,
        "attempted_trials": counts.total_trials,
        "family": family_metadata,
        "candidate_count": len(envelope.records),
        "calibration_compatible_identified_count": envelope.compatible_records,
        "point_fmci_range": envelope.point_fmci_range,
        "union_fmci_interval": envelope.union_fmci_interval,
        "full_divergence_range": envelope.full_divergence_range,
        "observed_divergence_range": envelope.observed_divergence_range,
        "pvalue_range": envelope.pvalue_range,
        "conservative_witness_pvalue": envelope.conservative_witness_pvalue,
        "calibration_adjusted_witness_pvalue": envelope.calibration_adjusted_witness_pvalue,
        "combined_coverage_lower_bound": envelope.combined_coverage_lower_bound,
        "tipping_parameters": envelope.tipping_parameters,
        "assumptions": {
            "randomized_contexts_verified": args.verify_randomized_contexts,
            "context_unpredictability_verified": args.verify_context_unpredictability,
            "channel_independently_fixed": args.verify_independent_channel,
            "score_prespecified": not args.score_not_prespecified,
            "family_inclusion_required": True,
            "finite_grid_coverage_must_be_justified": True,
        },
    }
    (args.output_dir / "sensitivity_summary.json").write_text(
        json.dumps(_jsonable(summary), indent=2, sort_keys=True) + "\n"
    )
    print(f"wrote {args.output_dir / 'sensitivity_scan.csv'}")
    print(f"wrote {args.output_dir / 'sensitivity_summary.json'}")


if __name__ == "__main__":
    main()
