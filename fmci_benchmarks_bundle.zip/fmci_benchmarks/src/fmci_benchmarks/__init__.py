"""Unified benchmark code for KL contextuality, FMCI, and Contextual Fraction."""

from .channels import (
    Channel,
    context_mar_channel,
    design_subcover_channel,
    identity_channel,
    mcar_channel,
    three_cycle_eta_alpha_channel,
)
from .metrics import ContextualFractionResult, contextual_fraction
from .scenarios import get_scenario, list_scenarios
from .solvers import SolveResult, solve_kl

__all__ = [
    "Channel",
    "ContextualFractionResult",
    "SolveResult",
    "context_mar_channel",
    "contextual_fraction",
    "design_subcover_channel",
    "get_scenario",
    "identity_channel",
    "list_scenarios",
    "mcar_channel",
    "solve_kl",
    "three_cycle_eta_alpha_channel",
]

__version__ = "0.2.0"
