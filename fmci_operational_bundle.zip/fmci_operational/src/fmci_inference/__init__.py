"""Operational estimation and finite-sample inference for FMCI."""

from .data import CalibrationCounts, ObservedCounts
from .estimands import FMCIEstimate, estimate_fmci
from .identification import IdentificationReport, identification_report
from .inference import FiellerSet, RegularInference, regular_inference
from .sensitivity import SensitivityEnvelope, run_sensitivity_analysis
from .testing import WitnessTestResult, witness_test

__all__ = [
    "CalibrationCounts",
    "ObservedCounts",
    "FMCIEstimate",
    "estimate_fmci",
    "IdentificationReport",
    "identification_report",
    "FiellerSet",
    "RegularInference",
    "regular_inference",
    "SensitivityEnvelope",
    "run_sensitivity_analysis",
    "WitnessTestResult",
    "witness_test",
]
__version__ = "0.3.0"
