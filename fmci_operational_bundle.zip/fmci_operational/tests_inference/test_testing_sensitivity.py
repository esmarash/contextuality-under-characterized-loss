from __future__ import annotations

import numpy as np
from scipy.stats import binom

from fmci_benchmarks.channels import mcar_channel, three_cycle_eta_alpha_channel
from fmci_benchmarks.scenarios import get_scenario
from fmci_inference.data import simulate_calibration_counts, simulate_observed_counts
from fmci_inference.sensitivity import (
    run_sensitivity_analysis,
    simultaneous_clopper_pearson_box,
    three_cycle_eta_alpha_candidates,
)
from fmci_inference.testing import (
    binomial_tail_pvalue,
    target_win_probability,
    transported_noncontextual_win_bound,
    witness_test,
)


def test_transported_game_bound_and_target_rate_under_mcar() -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = mcar_channel(scenario, 0.8)
    np.testing.assert_allclose(
        transported_noncontextual_win_bound(scenario, channel), 0.8 * 2 / 3
    )
    np.testing.assert_allclose(
        target_win_probability(scenario, target, channel), 0.7
    )


def test_binomial_tail_is_superuniform_at_the_boundary_null() -> None:
    n = 25
    bound = 0.6
    pvalues = np.asarray([binomial_tail_pvalue(k, n, bound) for k in range(n + 1)])
    probabilities = binom.pmf(np.arange(n + 1), n, bound)
    for alpha in (0.10, 0.05, 0.01):
        rejection_probability = float(np.sum(probabilities[pvalues <= alpha]))
        assert rejection_probability <= alpha + 1e-12


def test_memory_robust_label_requires_explicit_design_verification() -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    counts = simulate_observed_counts(
        scenario,
        target,
        channel,
        1000,
        np.random.default_rng(9),
        randomized_contexts=True,
    ).counts
    unchecked = witness_test(scenario, counts, channel)
    assert unchecked.memory_robust_winlose_pvalue is None
    assert unchecked.unverified_assumptions
    checked = witness_test(
        scenario,
        counts,
        channel,
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    assert checked.assumptions_verified
    assert checked.memory_robust_winlose_pvalue is not None


def test_sensitivity_union_and_calibration_adjusted_pvalue() -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    true_channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    rng = np.random.default_rng(27)
    counts = simulate_observed_counts(
        scenario,
        target,
        true_channel,
        2500,
        rng,
        randomized_contexts=True,
    ).counts
    calibration = simulate_calibration_counts(scenario, true_channel, 400, rng)
    box = simultaneous_clopper_pearson_box(scenario, calibration, confidence=0.95)
    candidates = three_cycle_eta_alpha_candidates(
        scenario,
        eta_values=[0.78, 0.8, 0.82],
        alpha_values=[0.65, 0.7, 0.75],
    )
    envelope = run_sensitivity_analysis(
        scenario,
        counts,
        candidates,
        calibration_box=box,
        conditional_confidence=0.95,
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    assert envelope.compatible_records >= 1
    assert envelope.union_fmci_interval[0] <= envelope.point_fmci_range[0]
    assert envelope.union_fmci_interval[1] >= envelope.point_fmci_range[1]
    assert envelope.calibration_adjusted_witness_pvalue >= envelope.conservative_witness_pvalue
