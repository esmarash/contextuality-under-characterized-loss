# Validation record

Reference artifacts were generated on **2026-07-13** with Python 3.13.5,
NumPy 2.3.5, SciPy 1.17.0, pandas 2.2.3, Matplotlib 3.10.8,
PyYAML 6.0.3, and pytest 9.0.2.  The seed and simulation configuration are
recorded in `outputs_operational/run_metadata.json`.

## Commands exercised

```bash
python -m pip install -e . --no-deps
PYTHONPATH=src python -m compileall -q src tests tests_inference scripts
PYTHONPATH=src pytest -q

fmci-benchmarks --quick --output /tmp/fmci_benchmark_quick
fmci-operational --config configs/operational_quick.yaml \
  --output /tmp/fmci_operational_quick

fmci-analyze \
  --scenario three_cycle \
  --counts examples/three_cycle/counts.csv \
  --channel examples/three_cycle/channel.csv \
  --calibration examples/three_cycle/calibration.csv \
  --output /tmp/fmci_analyze_smoke.json \
  --alternative-win-rate 0.581 \
  --verify-randomized-contexts \
  --verify-context-unpredictability \
  --verify-independent-channel

fmci-sensitivity \
  --scenario three_cycle \
  --counts examples/three_cycle/counts.csv \
  --calibration examples/three_cycle/calibration.csv \
  --candidates /tmp/fmci_one_candidate.csv \
  --output-dir /tmp/fmci_sensitivity_smoke \
  --verify-randomized-contexts \
  --verify-context-unpredictability \
  --verify-independent-channel
```

The full reference configuration uses 250 Monte Carlo replications per
finite-sample cell, 20,000 replications per p-value cell, 2,000 calibration
replications, 399 regular parametric-bootstrap draws, and a 567-candidate
MNAR grid.  See `configs/operational.yaml` and the metadata file for the exact
settings.

## Automated checks

- **24 tests passed**, covering both the inherited benchmark layer and the new
  identification, estimation, inference, sensitivity, CSV, and reporting
  layer.
- Analytic envelope gradients agree with central finite differences.
- Exact MCAR scaling and numerical data processing are checked.
- Channel tangent-rank identification is checked, including the one-zero-cell
  identified case and multi-zero-cell nonidentification.
- Fieller weak-denominator behavior is tested; an unbounded physical set is
  retained rather than replaced by a finite interval.
- A simplex-boundary regression test confirms that available KL point
  projections and absolute loss are preserved while regular ratio inference
  is withheld.
- Calibration-box compatibility, union intervals, adjusted p-values, and both
  sensitivity command-line pathways are tested.
- The benchmark quick run retained hidden-versus-facet and analytic KL
  agreement below `1.0e-12` nats.

## Regular identified alternative

For the reference three-cycle alternative (visibility 0.75, `eta=0.8`,
`alpha=0.7`), the population values are:

- full divergence: `0.11533834442199437` nats;
- observed divergence: `0.07733878159869041` nats;
- absolute information loss: `0.03799956282330395` nats;
- FMCI: `0.32946166354073014`.

Across sample sizes 300, 1,000, 3,000, and 10,000, FMCI RMSE had log-log slope
`-0.5808538029309362`, consistent with root-N behavior on this separated
regular alternative.  FMCI delta coverage ranged from 0.960 to 0.996 and
Fieller coverage from 0.960 to 0.992.  The minimum successful smooth-analysis
fraction was 0.952.  Individual KL delta intervals had coverage as low as
0.916 at N=1,000, so the package makes no claim of uniform small-sample
accuracy.

## Boundary and weak-denominator behavior

At visibility 0.36 the true full divergence is only
`0.0004027483158921515` nats.  FMCI RMSE had log-log slope
`-0.21266110079706585`, and only 0.012 of N=1,000 replications produced a
bounded Fieller set (0.136 even at N=10,000).  The regularity classifier marked
all reference replications in this regime nonregular.  This is the intended
behavior: the software does not force a stable scalar ratio when the
contextual-divergence denominator is weak.

## Bias and bootstrap scope

The outputs report N times the bias separately for full divergence, observed
divergence, absolute loss, and FMCI.  The coefficients vary by estimand,
sample size, visibility, and active projection geometry; the simulation does
not support a universal `d/(2N)` or Miller--Madow correction.  The supplied
parametric bootstrap is explicitly conditional on the identified regular
regime.  In its reference example all 399 draws succeeded; its FMCI percentile
interval was `[0.3233066098, 0.3323060303]`, alongside the delta interval and
Fieller set.

## Finite-sample contextuality evidence

The attempted-trial binary-game test was evaluated under IID null simulations,
a conservative adaptive-memory null, and a fixed alternative.  No evaluated
type-I rejection rate exceeded its nominal level; the maximum excess above
level was 0.0 (largest signed difference `-0.00115`).  At N=2,000, power was
0.99845, 0.99590, and 0.97495 at nominal levels 0.10, 0.05, and 0.01,
respectively.  The memory-robust label is emitted only when randomized
contexts, context unpredictability, independent channel fixing/calibration,
and score pre-specification are affirmatively recorded.

## Calibration and MNAR sensitivity

The simultaneous Bonferroni/Clopper--Pearson calibration box achieved empirical
familywise coverage 0.982 at nominal confidence 0.975.  The reference
sensitivity analysis evaluated 567 `(eta, alpha)` candidates, of which 16 were
both calibration compatible and identified.  It reported:

- point FMCI range `[0.3050310439883347, 0.354984049264614]`;
- union FMCI interval `[0.3021864841468159, 0.35848220434438927]`;
- conservative fixed-channel supremum p-value
  `3.8756697173459245e-08`;
- calibration-adjusted p-value `0.025000038756697197`.

The true parameter was explicitly injected into the validation candidate set,
and the output records that it lay in the calibration box.  The nominal
combined-coverage lower bound of 0.95 remains conditional on fixed-channel
interval validity, family inclusion, and adequate computational coverage of
the declared channel domain.

## Joint report example

For 5,000 attempted trials, the generated two-axis report contains:

- FMCI `0.32827778407874786`;
- Fieller FMCI interval
  `[0.32492275377957325, 0.33166633770396514]`;
- memory-robust win/lose p-value `3.4871346124729873e-09`;
- pre-specified likelihood-ratio e-value `13018064.592197014`.

The p-value/e-value addresses evidence against the transported noncontextual
null.  The FMCI interval addresses channel-conditional information
attenuation.  The software reports them together but never combines them into
one scalar.

## Artifact checks

- The nine-page statistical note compiled without undefined references and was
  rendered and visually inspected.
- Reference figures were rendered and inspected for clipping and legibility.
- `outputs_operational/SHA256SUMS` covers every reference-run output.
- The distributable archives and top-level files are covered by the external
  artifact checksum manifest supplied with the release bundle.
