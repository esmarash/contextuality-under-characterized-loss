from __future__ import annotations

import itertools
import math
from functools import lru_cache

import numpy as np

from .model import Context, Scenario, Witness


def _build_incidence(
    assignments: np.ndarray,
    contexts: tuple[Context, ...],
) -> np.ndarray:
    n_events = sum(len(context.outcomes) for context in contexts)
    incidence = np.zeros((n_events, len(assignments)), dtype=float)
    row = 0
    for context in contexts:
        outcome_to_index = {outcome: i for i, outcome in enumerate(context.outcomes)}
        for assignment_index, assignment in enumerate(assignments):
            restriction = tuple(
                int(assignment[index]) for index in context.observable_indices
            )
            if restriction not in outcome_to_index:
                raise ValueError(
                    f"assignment {assignment.tolist()} has invalid restriction "
                    f"{restriction} in context {context.name}"
                )
            incidence[row + outcome_to_index[restriction], assignment_index] = 1.0
        row += len(context.outcomes)
    return incidence


def _three_cycle() -> Scenario:
    observables = ("X1", "X2", "X3")
    pair_outcomes = tuple(itertools.product((1, -1), repeat=2))
    contexts = (
        Context("C12", (0, 1), pair_outcomes),
        Context("C23", (1, 2), pair_outcomes),
        Context("C13", (0, 2), pair_outcomes),
    )
    assignments = np.asarray(
        list(itertools.product((1, -1), repeat=3)), dtype=int
    )
    target_blocks = tuple(
        np.asarray([0.5 if x * y == -1 else 0.0 for x, y in pair_outcomes])
        for _ in contexts
    )
    incidence = _build_incidence(assignments, contexts)

    n_events = 3 * len(pair_outcomes)
    base = np.zeros(n_events, dtype=float)
    matrix = np.zeros((n_events, 3), dtype=float)
    for c, context in enumerate(contexts):
        for o, outcome in enumerate(context.outcomes):
            row = c * len(pair_outcomes) + o
            good = int(outcome[0] * outcome[1] == -1)
            base[row] = 0.0 if good else 0.5
            matrix[row, c] = 0.5 if good else -0.5

    raw_vertices = np.zeros((len(assignments), 3), dtype=float)
    for a, assignment in enumerate(assignments):
        for c, context in enumerate(contexts):
            i, j = context.observable_indices
            raw_vertices[a, c] = float(assignment[i] * assignment[j] == -1)
    vertices = np.unique(raw_vertices, axis=0)

    return Scenario(
        key="three_cycle",
        title="Perfect-anticorrelation 3-cycle",
        observable_names=observables,
        contexts=contexts,
        assignments=assignments,
        target_by_context=target_blocks,
        context_weights=np.full(3, 1.0 / 3.0),
        incidence=incidence,
        affine_base=base,
        affine_matrix=matrix,
        reduced_vertices=vertices,
        raw_reduced_vertices=raw_vertices,
        reduced_labels=("Pr[anti|C12]", "Pr[anti|C23]", "Pr[anti|C13]"),
        target_reduced=np.ones(3),
        noise_reduced=np.full(3, 0.5),
        witness=Witness(
            label="sum of anticorrelation probabilities",
            coefficients=np.ones(3),
            noncontextual_bound=2.0,
            algebraic_bound=3.0,
        ),
        visibility_threshold=1.0 / 3.0,
        reduction_scope=(
            "Exact for targets and observation kernels invariant under permutations "
            "within the correlated and anticorrelated parity sectors."
        ),
    )


def _kcbs() -> Scenario:
    observables = tuple(f"P{i + 1}" for i in range(5))
    # Keep the full binary joint-outcome alphabet. The target has zero mass on
    # (1,1), but the noncontextual reference class is the ordinary global
    # marginal polytope rather than a hard-coded independent-set face. This
    # matters under context removal: deleting an edge also deletes its observed
    # exclusivity constraint.
    local_outcomes = ((0, 0), (1, 0), (0, 1), (1, 1))
    contexts = tuple(
        Context(f"E{i + 1}{(i + 1) % 5 + 1}", (i, (i + 1) % 5), local_outcomes)
        for i in range(5)
    )
    assignments = np.asarray(
        list(itertools.product((0, 1), repeat=5)), dtype=int
    )
    incidence = _build_incidence(assignments, contexts)

    quantum_probability = 1.0 / math.sqrt(5.0)
    target_context = np.asarray(
        [
            1.0 - 2.0 * quantum_probability,
            quantum_probability,
            quantum_probability,
            0.0,
        ]
    )
    target_blocks = tuple(target_context.copy() for _ in contexts)

    # Reduced coordinates are r_i = Pr(P_i=1) and
    # t_i = Pr(P_i=1,P_{i+1}=1). Each context distribution is
    # [1-r_i-r_j+t_i, r_i-t_i, r_j-t_i, t_i].
    n_events = 5 * len(local_outcomes)
    base = np.zeros(n_events, dtype=float)
    matrix = np.zeros((n_events, 10), dtype=float)
    for c, context in enumerate(contexts):
        i, j = context.observable_indices
        start = c * len(local_outcomes)
        t_index = 5 + c
        base[start] = 1.0
        matrix[start, i] = -1.0
        matrix[start, j] = -1.0
        matrix[start, t_index] = 1.0
        matrix[start + 1, i] = 1.0
        matrix[start + 1, t_index] = -1.0
        matrix[start + 2, j] = 1.0
        matrix[start + 2, t_index] = -1.0
        matrix[start + 3, t_index] = 1.0

    raw_vertices = np.zeros((len(assignments), 10), dtype=float)
    raw_vertices[:, :5] = assignments
    for c, (i, j) in enumerate(
        (context.observable_indices for context in contexts)
    ):
        raw_vertices[:, 5 + c] = assignments[:, i] * assignments[:, j]
    vertices = np.unique(raw_vertices, axis=0)
    target_reduced = np.concatenate(
        (np.full(5, quantum_probability), np.zeros(5))
    )
    # Qutrit maximally mixed noise preserves orthogonality: r_i=1/3, t_i=0.
    noise_reduced = np.concatenate((np.full(5, 1.0 / 3.0), np.zeros(5)))
    threshold = (0.4 - 1.0 / 3.0) / (quantum_probability - 1.0 / 3.0)

    return Scenario(
        key="kcbs",
        title="KCBS pentagon at the symmetric quantum maximum",
        observable_names=observables,
        contexts=contexts,
        assignments=assignments,
        target_by_context=target_blocks,
        context_weights=np.full(5, 1.0 / 5.0),
        incidence=incidence,
        affine_base=base,
        affine_matrix=matrix,
        reduced_vertices=vertices,
        raw_reduced_vertices=raw_vertices,
        reduced_labels=(
            *(f"Pr[P{i + 1}=1]" for i in range(5)),
            *(f"Pr[P{i + 1}=1,P{(i + 1) % 5 + 1}=1]" for i in range(5)),
        ),
        target_reduced=target_reduced,
        noise_reduced=noise_reduced,
        witness=Witness(
            label="robust KCBS probability sum",
            coefficients=np.concatenate((np.ones(5), -np.ones(5))),
            noncontextual_bound=2.0,
            algebraic_bound=2.5,
        ),
        visibility_threshold=threshold,
        reduction_scope=(
            "Exact full marginal-polytope H-representation in five singleton "
            "probabilities and five adjacent joint probabilities."
        ),
    )


def _magic_square() -> Scenario:
    observables = ("A", "B", "C", "D", "E", "F", "G", "H", "I")
    triple_outcomes = tuple(itertools.product((1, -1), repeat=3))
    contexts = (
        Context("R1", (0, 1, 2), triple_outcomes),
        Context("R2", (3, 4, 5), triple_outcomes),
        Context("R3", (6, 7, 8), triple_outcomes),
        Context("C1", (0, 3, 6), triple_outcomes),
        Context("C2", (1, 4, 7), triple_outcomes),
        Context("C3", (2, 5, 8), triple_outcomes),
    )
    target_signs = (1, 1, 1, 1, 1, -1)
    assignments = np.asarray(
        list(itertools.product((1, -1), repeat=9)), dtype=int
    )
    incidence = _build_incidence(assignments, contexts)
    target_blocks = tuple(
        np.asarray(
            [0.25 if int(np.prod(outcome)) == sign else 0.0 for outcome in triple_outcomes]
        )
        for sign in target_signs
    )

    n_events = 6 * len(triple_outcomes)
    base = np.zeros(n_events, dtype=float)
    matrix = np.zeros((n_events, 6), dtype=float)
    for c, (context, sign) in enumerate(zip(contexts, target_signs, strict=True)):
        for o, outcome in enumerate(context.outcomes):
            row = c * len(triple_outcomes) + o
            good = int(int(np.prod(outcome)) == sign)
            base[row] = 0.0 if good else 0.25
            matrix[row, c] = 0.25 if good else -0.25

    raw_vertices = np.zeros((len(assignments), 6), dtype=float)
    for a, assignment in enumerate(assignments):
        for c, (context, sign) in enumerate(zip(contexts, target_signs, strict=True)):
            product = int(np.prod(assignment[list(context.observable_indices)]))
            raw_vertices[a, c] = float(product == sign)
    vertices = np.unique(raw_vertices, axis=0)

    return Scenario(
        key="magic_square",
        title="Peres-Mermin magic square parity model",
        observable_names=observables,
        contexts=contexts,
        assignments=assignments,
        target_by_context=target_blocks,
        context_weights=np.full(6, 1.0 / 6.0),
        incidence=incidence,
        affine_base=base,
        affine_matrix=matrix,
        reduced_vertices=vertices,
        raw_reduced_vertices=raw_vertices,
        reduced_labels=tuple(f"Pr[target parity|{context.name}]" for context in contexts),
        target_reduced=np.ones(6),
        noise_reduced=np.full(6, 0.5),
        witness=Witness(
            label="number of target parity constraints satisfied",
            coefficients=np.ones(6),
            noncontextual_bound=5.0,
            algebraic_bound=6.0,
        ),
        visibility_threshold=2.0 / 3.0,
        reduction_scope=(
            "Exact for targets and observation kernels invariant under permutations "
            "within each target-parity and opposite-parity sector. The raw hidden "
            "model retains all 512 deterministic assignments."
        ),
    )


_BUILDERS = {
    "three_cycle": _three_cycle,
    "kcbs": _kcbs,
    "magic_square": _magic_square,
}


@lru_cache(maxsize=None)
def get_scenario(key: str) -> Scenario:
    try:
        return _BUILDERS[key]()
    except KeyError as exc:
        valid = ", ".join(sorted(_BUILDERS))
        raise KeyError(f"unknown scenario {key!r}; choose from {valid}") from exc


def list_scenarios() -> tuple[str, ...]:
    return tuple(_BUILDERS)
