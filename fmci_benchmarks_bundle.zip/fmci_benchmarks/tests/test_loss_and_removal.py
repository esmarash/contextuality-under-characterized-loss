import itertools

import numpy as np

from fmci_benchmarks.channels import (
    design_subcover_channel,
    mcar_channel,
    three_cycle_eta_alpha_channel,
)
from fmci_benchmarks.geometry import facet_representation
from fmci_benchmarks.scenarios import get_scenario, list_scenarios
from fmci_benchmarks.solvers import solve_facets, solve_hidden


def test_mcar_exact_scaling() -> None:
    for key in list_scenarios():
        scenario = get_scenario(key)
        full = solve_hidden(scenario)
        for eta in (0.0, 0.2, 0.73, 1.0):
            channel = mcar_channel(scenario, eta)
            observed = solve_hidden(scenario, channel=channel)
            assert observed.success, observed.message
            np.testing.assert_allclose(
                observed.divergence,
                eta * full.divergence,
                atol=3.0e-9,
                rtol=0.0,
            )


def test_all_proper_subcovers_extend_noncontextually() -> None:
    for key in list_scenarios():
        scenario = get_scenario(key)
        for bits in itertools.product((False, True), repeat=scenario.n_contexts):
            active = np.asarray(bits, dtype=bool)
            if np.all(active):
                continue
            result = solve_hidden(scenario, active_contexts=active)
            assert result.success, result.message
            assert result.divergence <= 3.0e-9


def test_facet_formulation_accepts_zero_kl_subcovers() -> None:
    """Regression test for flat, exactly extendable retained subcovers."""

    for key in list_scenarios():
        scenario = get_scenario(key)
        facets = facet_representation(scenario.reduced_vertices)
        for bits in itertools.product((False, True), repeat=scenario.n_contexts):
            active = np.asarray(bits, dtype=bool)
            if np.all(active):
                continue
            channel = design_subcover_channel(scenario, active)
            result = solve_facets(scenario, channel=channel, facets=facets)
            assert result.success, f"{key} {bits}: {result.message}"
            assert result.divergence <= 3.0e-9


def test_eta_alpha_formulations_and_sandwich() -> None:
    scenario = get_scenario("three_cycle")
    full = solve_hidden(scenario).divergence
    for eta, alpha in (
        (0.0, 0.6),
        (0.7, 0.0),
        (0.02, 0.02),
        (0.3, 0.4),
        (0.8, 0.9),
        (1.0, 1.0),
    ):
        channel = three_cycle_eta_alpha_channel(scenario, eta, alpha)
        hidden = solve_hidden(scenario, channel=channel)
        facets = solve_facets(scenario, channel=channel)
        assert hidden.success, hidden.message
        assert facets.success, facets.message
        np.testing.assert_allclose(
            hidden.divergence, facets.divergence, atol=3.0e-9, rtol=0.0
        )
        assert hidden.divergence >= eta * alpha**2 * full - 3.0e-9
        assert hidden.divergence <= eta * full + 3.0e-9
        if eta > 0.0 and alpha > 0.0:
            assert hidden.divergence > 0.0
