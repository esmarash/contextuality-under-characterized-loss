# Operational protocol for an FMCI analysis

This protocol is intended to be copied into an experimental analysis plan. It
separates design, detector characterization, contextuality testing, estimation,
and MNAR sensitivity so that assumptions are visible before data are examined.

## 1. Freeze the target experiment

Record before data collection:

- measurement contexts and complete outcome alphabets;
- intended context-selection probabilities;
- the contextuality score or inequality and the attempted-trial scoring rule;
- which events count as no-click, invalid, aborted, or missing-by-design;
- whether no-click events remain context labelled;
- the target noncontextual reference class;
- the primary complete-data and observed-data KL estimands.

Do not redefine the context distribution after seeing which settings were easy
to implement. A design omission should be represented as a channel relative to
the intended design when the goal is to quantify information lost from that
design.

## 2. State the channel-transportability assumption

Specify the physical variables on which retention may depend. The primary
analysis assumes one conditional retention law is transported across the target
behavior and every noncontextual comparator after conditioning on the declared
complete-data cell. List plausible violations, such as unobserved intensity,
time drift, detector saturation, or state-dependent apparatus response.

When additional variables are recorded and scientifically meaningful, augment
the complete-data cell rather than hiding their effect inside an undefined
“state-dependent” channel.

## 3. Preserve attempted-trial accounting

For every attempted trial retain:

- selected context;
- detected complete outcome, or a context-labelled star/no-click event;
- trial order or block identifier when drift or memory is plausible;
- random-setting generation and timing metadata;
- prespecified exclusions with reason codes.

The primary observed-data analysis must not silently condition on detection.

## 4. Obtain independent calibration data

For each context/outcome cell, collect calibration successes and totals under a
procedure that is independent of the tested experimental counts. Record how
calibration stimuli map to the complete-data cells and why the calibration
response law is transportable to the experiment.

The default software construction is a simultaneous Bonferroni-adjusted
Clopper–Pearson box. Alternatives may be substituted, but their simultaneous
coverage and independence assumptions must be documented.

## 5. Check identification before estimating FMCI

Run the tangent-rank diagnostic for every candidate channel. For whole-outcome
erasure in one context, the complete distribution is point identified exactly
when at most one complete-outcome cell has zero retention. Strong positivity is
not logically necessary for identification, but small positive retentions make
reconstruction ill conditioned.

Report:

- point-identification status by context;
- number of zero-retention cells;
- smallest positive retention;
- smallest tangent singular value and condition number.

When point identification fails, do not report a unique complete-data KL or
FMCI. Use bounds or a sensitivity/partial-identification analysis.

## 6. Fit the complete behavior under each declared channel

For a known or candidate channel, fit each context distribution by maximum
likelihood using detected and star counts. The supplied EM routine treats the
star count as arising from latent complete outcomes with weights proportional
to `(1 - retention_i) * p_i`.

Check convergence, score residuals, compatibility of positive detected counts
with zero-retention cells, and numerical conditioning.

## 7. Compute the magnitude layer

From the same fitted complete behavior, compute:

- `D_full`: KL distance to the complete-data noncontextual set;
- `D_observed`: KL distance after applying the same channel to target and
  comparator models;
- `Delta = D_full - D_observed`;
- `FMCI = 1 - D_observed / D_full`, only when the denominator is reportable.

The same latent fit is used for both divergences so a numerical DPI violation is
a solver diagnostic rather than a mismatch between estimators.

## 8. Classify the inferential regime

Treat a scalar FMCI interval as regular only when all of the following hold:

- point identification;
- retention away from the declared nonidentification floor;
- latent probabilities away from relevant simplex boundaries;
- locally stable, numerically certified KL projections;
- full contextual divergence separated from zero;
- one bounded Fieller interval after physical intersection.

In the regular regime, report delta intervals and the Fieller interval. Outside
it, report `D_full`, `D_observed`, `Delta`, the Fieller set as returned, and the
failure reason. An unbounded or disconnected Fieller set is substantive
information about a weak denominator.

## 9. Test contextuality on a separate evidence axis

Use a score fixed before inspecting the tested data. Include no-clicks as losses
unless the test protocol proves another treatment valid. Compute the transported
noncontextual attempted-trial win bound under the declared channel.

A binomial upper-tail p-value can be described as robust to arbitrary device
memory only when the analyst verifies that context choices were randomized with
the declared probabilities and unpredictable to the device before each trial,
the channel was independently fixed or calibrated, and the score was
prespecified.

A pre-specified e-value may be reported when its alternative win rate was fixed
independently of the test data or learned on a disjoint training block.

## 10. Conduct MNAR sensitivity analysis

1. Choose a low-dimensional family tied to detector physics, not to the desired
   conclusion.
2. Set domains from engineering tolerances, calibration, prior validation, and
   physical positivity constraints.
3. Intersect candidates with the simultaneous calibration set.
4. Check identification and conditioning for every candidate.
5. Use a dense grid for one or two dimensions; for higher dimensions use a
   scrambled Sobol design plus local refinement.
6. Refine near extrema, transitions in identification, and tipping contours.
7. At each compatible identified candidate, refit the latent behavior and
   recompute both KL projections.
8. Report the point range, conditional interval at each candidate, union
   interval, nonidentified region, calibration-incompatible region, and tipping
   parameters.
9. For contextuality evidence, report the supremum valid p-value over compatible
   channels; when calibration has error probability `alpha_cal`, an unconditional
   conservative construction is `min(1, sup_p + alpha_cal)` under family
   inclusion and randomized-setting assumptions.
10. State whether the true channel is represented exactly by the numerical grid
    in a validation study; for experimental use, justify mesh coverage or use
    optimization/verified enclosure.

## 11. Recommended final table

| Quantity | Interpretation |
|---|---|
| Contextuality p-value/e-value | Evidence against the transported noncontextual null under the declared randomized-setting and channel assumptions |
| `D_full` with interval/status | Complete-experiment contextual distinguishability |
| `D_observed` with interval/status | Attempted-trial contextual distinguishability after the declared channel |
| `Delta` with interval/status | Absolute contextual information removed |
| FMCI Fieller set | Fractional attenuation, only summarized as a scalar interval when regular |
| Sensitivity envelope | Range and union interval over calibration-compatible declared MNAR mechanisms |
| Identification diagnostics | Whether the complete behavior is determined and how ill conditioned reconstruction is |

The evidence and attenuation axes must remain separate.
