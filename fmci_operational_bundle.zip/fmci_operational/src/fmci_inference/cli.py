from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from .experiments import load_config, run_operational_suite


QUICK_OVERRIDES = {
    "regular_replicates": 12,
    "near_boundary_replicates": 12,
    "bootstrap_replicates": 31,
    "pvalue_replicates": 750,
    "calibration_replicates": 80,
    "regular_sample_sizes": [300, 1000],
    "near_boundary_sample_sizes": [1000],
    "pvalue_sample_sizes": [100, 500],
    "calibration_attempts_per_cell": 150,
    "sensitivity_eta_points": 7,
    "sensitivity_alpha_points": 9,
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run the FMCI operational, sensitivity, and finite-sample validation suite."
        )
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=None,
        help="YAML configuration (defaults to built-in operational settings)",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="output directory; overrides the YAML output field",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="run a reduced smoke/CI configuration",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="random seed override",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    config = load_config(args.config) if args.config is not None else {}
    if args.quick:
        config.update(QUICK_OVERRIDES)
    if args.seed is not None:
        config["seed"] = args.seed
    output = args.output or Path(config.pop("output", "outputs_operational"))
    headline = run_operational_suite(config, output)
    compact = {
        "output": str(output),
        "regular_rmse_slope": headline["regular_rmse_slope"],
        "minimum_regular_fieller_coverage": headline[
            "minimum_regular_fieller_coverage"
        ],
        "calibration_empirical_coverage": headline[
            "calibration_empirical_coverage"
        ],
        "sensitivity_union_fmci_interval": headline["sensitivity"][
            "union_fmci_interval"
        ],
    }
    print(json.dumps(compact, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
