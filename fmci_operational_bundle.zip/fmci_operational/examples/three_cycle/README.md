# Three-cycle worked example

This directory contains a deterministic-seed synthetic dataset for the
visibility-0.75 three-cycle benchmark under the declared channel
`eta = 0.8`, `alpha = 0.7`.

- `counts.csv`: 5,000 randomized-context attempted trials, including star rows.
- `channel.csv`: cellwise retention probabilities.
- `calibration.csv`: 800 independent calibration challenges per complete cell.
- `DECLARED_ALTERNATIVE.txt`: benchmark alternative win probability fixed before
  analysis; it is used only for the optional e-value.
- `report.json`: output from the command below.

```bash
ALT=$(cat examples/three_cycle/DECLARED_ALTERNATIVE.txt)
fmci-analyze \
  --scenario three_cycle \
  --counts examples/three_cycle/counts.csv \
  --channel examples/three_cycle/channel.csv \
  --calibration examples/three_cycle/calibration.csv \
  --output examples/three_cycle/report.json \
  --alternative-win-rate "$ALT" \
  --verify-randomized-contexts \
  --verify-context-unpredictability \
  --verify-independent-channel
```

The data are synthetic validation data, not an experimental claim.
