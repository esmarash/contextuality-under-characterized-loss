import numpy as np

from fmci_benchmarks.geometry import facet_representation
from fmci_benchmarks.scenarios import get_scenario, list_scenarios


def test_scenario_dimensions_and_facets() -> None:
    expected = {
        "three_cycle": (8, 3, 4),
        "kcbs": (32, 10, 36),
        "magic_square": (512, 6, 44),
    }
    for key in list_scenarios():
        scenario = get_scenario(key)
        assignments, dimension, facets = expected[key]
        assert scenario.n_assignments == assignments
        assert scenario.reduced_dimension == dimension
        representation = facet_representation(scenario.reduced_vertices)
        assert representation.n_facets == facets
        assert representation.n_vertices == scenario.reduced_vertices.shape[0]
        assert representation.generation_seconds >= 0.0
        assert np.allclose(
            scenario.affine_base + scenario.affine_matrix @ scenario.target_reduced,
            scenario.target_flat,
        )
