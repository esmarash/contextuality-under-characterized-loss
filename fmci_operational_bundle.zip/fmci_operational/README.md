# FMCI operational, sensitivity, and finite-sample suite

This repository is the standalone computational layer for loss-conditioned
relative-entropy contextuality. It extends the unified 3-cycle, KCBS, and
Peres–Mermin benchmark code with an experiment-facing workflow for:

- checking whether a declared observation channel identifies the complete
  trial distribution;
- fitting the latent complete behavior from context-labelled detected and
  no-click counts;
- estimating full-data divergence, observed-data divergence, absolute
  information loss, and FMCI;
- issuing regular delta-method and Fieller uncertainty only when the required
  conditions pass;
- retaining nonregular or weak-denominator outcomes as explicit diagnostics
  rather than forcing a scalar FMCI interval;
- testing a predeclared binary contextuality game with a finite-sample
  attempted-trial p-value, with no-clicks scored as losses;
- propagating independent detector-calibration uncertainty through a
  simultaneous confidence set;
- scanning declared MNAR sensitivity families and reporting ranges, union
  intervals, tipping regions, nonidentified candidates, and conservative
  channel-adjusted p-values.

The manuscript source is intentionally not modified by this package.

## Inferential separation

The package keeps four questions distinct:

1. **Identification:** Does the declared observation channel determine the
   complete context distributions?
2. **Magnitude:** What are the full and observed KL contextual divergences and
   their absolute difference?
3. **Ratio stability:** Is `FMCI = 1 - D_observed / D_full` statistically
   reportable as a bounded scalar interval?
4. **Evidence:** Does a predeclared attempted-trial contextuality game reject
   the transported noncontextual null?

The contextuality p-value/e-value and the FMCI interval are reported side by
side. They are not multiplied, averaged, or converted into one significance
score.

## Installation

```bash
python -m pip install -e '.[dev]'
pytest -q
```

Python 3.11 or later is required.

## Analyze an experiment

The primary command accepts context-labelled CSV files:

```bash
fmci-analyze \
  --scenario three_cycle \
  --counts examples/three_cycle/counts.csv \
  --channel examples/three_cycle/channel.csv \
  --calibration examples/three_cycle/calibration.csv \
  --output examples/three_cycle/report.json \
  --confidence 0.95 \
  --calibration-confidence 0.975 \
  --alternative-win-rate 0.581 \
  --verify-randomized-contexts \
  --verify-context-unpredictability \
  --verify-independent-channel
```

The three verification switches are deliberately affirmative. Without them,
the software still reports the numerical binomial tail but does not label it
memory robust. The binary score is presumed predeclared unless
`--score-not-prespecified` is supplied.

CSV schemas and outcome labels are documented in
[`docs/DATA_FORMAT.md`](docs/DATA_FORMAT.md). A complete worked example is in
[`examples/three_cycle`](examples/three_cycle).

## Run an MNAR sensitivity analysis

For the built-in three-cycle `(eta, alpha)` family:

```bash
fmci-sensitivity \
  --scenario three_cycle \
  --counts examples/three_cycle/counts.csv \
  --calibration examples/three_cycle/calibration.csv \
  --eta-alpha \
  --eta-min 0.65 --eta-max 0.90 --eta-points 21 \
  --alpha-min 0.35 --alpha-max 1.00 --alpha-points 27 \
  --conditional-confidence 0.975 \
  --calibration-confidence 0.975 \
  --output-dir examples/three_cycle/sensitivity \
  --verify-randomized-contexts \
  --verify-context-unpredictability \
  --verify-independent-channel
```

For an arbitrary declared family, replace `--eta-alpha` with
`--candidates candidate_manifest.csv`. The candidate-manifest schema is
specified in [`docs/DATA_FORMAT.md`](docs/DATA_FORMAT.md). The output contains
candidate-level identification, conditioning, KL, FMCI, interval, and p-value
results plus a machine-readable envelope summary.

## Run the validation suite

```bash
fmci-operational --config configs/operational.yaml
```

A quick smoke run is available:

```bash
fmci-operational --config configs/operational_quick.yaml \
  --output outputs_operational_quick
```

The reference run writes:

- `finite_sample_replicates.csv` and `finite_sample_summary.csv`;
- `pvalue_validation.csv`;
- `calibration_coverage.csv`;
- `sensitivity_scan.csv`;
- `identification_scan.csv`;
- `bootstrap_replicates.csv` and `bootstrap_summary.json`;
- `joint_reporting_example.json`;
- `headline_results.json`, `REPORT.md`, figures, metadata, and SHA-256 checksums.

## Implemented statistical regimes

### Regular identified alternative

The latent MLE is fit under the known common erasure channel. When the channel
map has full tangent rank, all relevant probabilities and retention values are
away from their declared floors, the KL projection is numerically certified,
and the full divergence is separated from zero, the package computes:

- a joint delta-method covariance for `(D_observed, D_full)`;
- intervals for `D_full`, `D_observed`, and their absolute difference;
- a delta-method FMCI interval;
- a Fieller confidence set for the ratio `D_observed / D_full` and hence FMCI.

### Boundary and weak denominator

At the noncontextual boundary, near simplex faces, or when the full divergence
is weakly separated from zero, ordinary smooth ratio theory is not asserted.
An unbounded, disconnected, or non-singleton Fieller set is retained as the
substantive result. The recommended report then emphasizes the two divergences,
absolute loss, and the reason scalar FMCI is not stable.

The conditional parametric bootstrap is implemented only for the regular
identified regime. It is not described as universally boundary valid.

### Unknown MNAR mechanism

Unknown MNAR is not converted into an unidentified point estimate. The user
must declare a scientifically interpretable channel family and domain. An
independent calibration sample can restrict this family through simultaneous
Bonferroni-adjusted Clopper–Pearson intervals. The software evaluates compatible
identified candidates and reports a union interval and tipping region.

For a finite grid, coverage statements are conditional on the true mechanism
belonging to the declared family and being represented or conservatively
covered by the grid. The reference validation explicitly injects the true
parameter into the candidate set and records that fact.

## Finite-sample contextuality test

For each benchmark, the package defines a canonical binary win/loss score and
computes the maximum attempted-trial win probability over deterministic
noncontextual assignments after the declared channel. No-clicks are losses.
The exact binomial upper tail is used. It is labelled memory robust only when:

- contexts were generated with the declared randomized probabilities;
- the current context was unpredictable to the device before the trial;
- the channel was fixed or calibrated independently; and
- the score was fixed before inspecting the tested data.

A likelihood-ratio e-value is available only for an alternative win rate fixed
independently of the tested data or learned on a disjoint training block.

## Source map

### Operational and inference layer

- `fmci_inference/data.py`: count containers and simulation.
- `identification.py`: tangent-rank diagnostics, known-channel latent MLE, and
  Fisher information.
- `estimands.py`: coherent plug-in KL projections and envelope gradients.
- `inference.py`: delta, Fieller, regularity diagnostics, and regular-only
  parametric bootstrap.
- `testing.py`: attempted-trial contextuality games, exact tails, and
  pre-specified e-values.
- `sensitivity.py`: calibration boxes, channel families, Sobol designs, union
  intervals, tipping regions, and calibration-adjusted p-values.
- `io.py`, `reporting.py`, `analyze_cli.py`: experiment-facing CSV workflow and
  two-axis JSON report.
- `experiments.py`: Monte Carlo validation, figures, reports, and manifests.

### Benchmark layer

- `fmci_benchmarks/scenarios.py`: 3-cycle, KCBS, and magic-square models.
- `channels.py`: identity, MCAR, MAR, design, and MNAR channels.
- `solvers.py`: hidden-variable and reduced inequality KL solvers.
- `metrics.py`: Contextual Fraction and benchmark witnesses.

## Mathematical note and protocol

- [`docs/FMCI_OPERATIONAL_FINITE_SAMPLE_NOTE.pdf`](docs/FMCI_OPERATIONAL_FINITE_SAMPLE_NOTE.pdf): theorem-level statistical note.
- [`docs/OPERATIONAL_PROTOCOL.md`](docs/OPERATIONAL_PROTOCOL.md): step-by-step experimental workflow.
- [`docs/DATA_FORMAT.md`](docs/DATA_FORMAT.md): CSV contract.
- [`docs/STATISTICAL_SCOPE.md`](docs/STATISTICAL_SCOPE.md): claims, assumptions,
  nonregular cases, and minimax scope.
- [`VALIDATION.md`](VALIDATION.md): commands and reference-run checks.

## Important scope limits

- FMCI is conditional on a declared common channel; it is not a loophole-free
  contextuality certificate.
- A calibration-compatible sensitivity envelope is conditional on the declared
  family containing the true channel.
- A finite grid is not automatically exhaustive over a continuous family.
- The regular asymptotic theory is not asserted at the noncontextual boundary,
  at nonunique projections, under nonidentification, or with a weak FMCI
  denominator.
- The package does not claim a universal `d/(2N)` bias correction or a global
  minimax rate over unrestricted channels and behaviors.
