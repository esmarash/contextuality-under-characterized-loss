from __future__ import annotations

import json
from pathlib import Path

from fmci_inference.experiments import run_operational_suite


def test_operational_suite_smoke(tmp_path: Path) -> None:
    config = {
        "seed": 31,
        "regular_replicates": 3,
        "near_boundary_replicates": 3,
        "bootstrap_replicates": 21,
        "pvalue_replicates": 100,
        "calibration_replicates": 20,
        "regular_sample_sizes": [300],
        "near_boundary_sample_sizes": [1000],
        "pvalue_sample_sizes": [100],
        "calibration_attempts_per_cell": 100,
        "sensitivity_eta_points": 3,
        "sensitivity_alpha_points": 3,
    }
    headline = run_operational_suite(config, tmp_path)
    assert (tmp_path / "REPORT.md").is_file()
    assert (tmp_path / "finite_sample_summary.csv").is_file()
    assert (tmp_path / "joint_reporting_example.json").is_file()
    assert (tmp_path / "SHA256SUMS").is_file()
    payload = json.loads((tmp_path / "joint_reporting_example.json").read_text())
    assert payload["contextuality_test"]["assumptions_verified"]
    assert headline["sensitivity"]["true_parameter_represented_in_candidate_set"]
