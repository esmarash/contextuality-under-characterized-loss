from __future__ import annotations

import math
from dataclasses import asdict
from typing import Any

import numpy as np

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario

from .data import CalibrationCounts, ObservedCounts
from .estimands import estimate_fmci
from .identification import IdentificationError, identification_report
from .inference import regular_inference
from .sensitivity import simultaneous_clopper_pearson_box
from .testing import witness_test


def _jsonable(value: Any) -> Any:
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def analyze_known_channel(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    *,
    calibration: CalibrationCounts | None = None,
    calibration_confidence: float = 0.975,
    inference_confidence: float = 0.95,
    alternative_win_rate: float | None = None,
    randomized_contexts_verified: bool = False,
    context_unpredictability_verified: bool = False,
    channel_independently_fixed: bool = False,
    score_prespecified: bool = True,
) -> dict[str, Any]:
    """Create a machine-readable two-axis report for one declared channel.

    The output keeps contextuality evidence and FMCI magnitude separate. A
    scalar FMCI is marked recommended only when the complete behavior is point
    identified, the regularity diagnostics pass, and the Fieller set is one
    bounded interval.
    """

    counts.validate(scenario)
    channel.validate(scenario)
    identification = identification_report(scenario, channel)
    report: dict[str, Any] = {
        "scenario": scenario.key,
        "attempted_trials": counts.total_trials,
        "detected_trials": counts.detected_trials,
        "star_trials": counts.star_trials,
        "channel": {
            "name": channel.name,
            "parameters": dict(channel.parameters),
            "minimum_retention": identification.minimum_retention,
            "point_identified": identification.point_identified,
            "worst_condition_number": identification.worst_condition_number,
        },
        "calibration": None,
        "fmci_analysis": None,
        "contextuality_test": None,
        "status": "ok",
    }
    if calibration is not None:
        box = simultaneous_clopper_pearson_box(
            scenario, calibration, confidence=calibration_confidence
        )
        report["calibration"] = {
            "confidence_level": calibration_confidence,
            "familywise_method": box.familywise_method,
            "declared_channel_inside_box": box.contains(scenario, channel),
            "lower_by_context": [block.tolist() for block in box.lower_by_context],
            "upper_by_context": [block.tolist() for block in box.upper_by_context],
        }
    if not identification.point_identified:
        report["status"] = "not-identified"
        report["fmci_analysis"] = {
            "message": (
                "The declared channel does not point-identify the complete behavior. "
                "A scalar complete-data divergence or FMCI is not reported; use a "
                "partial-identification or sensitivity analysis."
            )
        }
    else:
        try:
            estimate = estimate_fmci(scenario, counts, channel)
        except (IdentificationError, RuntimeError, ValueError, FloatingPointError) as exc:
            report["status"] = "estimation-failed"
            report["fmci_analysis"] = {"message": str(exc)}
        else:
            point_payload: dict[str, Any] = {
                "full_divergence_nats": estimate.full_divergence,
                "observed_divergence_nats": estimate.observed_divergence,
                "absolute_information_loss_nats": estimate.absolute_loss,
                "fmci_point_estimate": estimate.fmci,
                "numerical_dpi_gap": estimate.numerical_dpi_gap,
            }
            try:
                inference = regular_inference(
                    scenario,
                    counts,
                    channel,
                    estimate,
                    confidence=inference_confidence,
                )
            except (IdentificationError, RuntimeError, ValueError, FloatingPointError) as exc:
                # Preserve the estimands even when smooth covariance or gradient
                # calculations fail at an empirical boundary.  The failure is a
                # reporting restriction, not evidence that the point projections
                # themselves were unavailable.
                report["status"] = "nonregular-inference-unavailable"
                report["fmci_analysis"] = {
                    **point_payload,
                    "fmci_scalar_reporting_recommended": False,
                    "delta_intervals": None,
                    "fieller": None,
                    "regularity": {
                        "classification": "nonregular/inference-unavailable",
                        "reasons": [str(exc)],
                    },
                    "interpretation": (
                        "The KL point estimates are retained, but regular delta/Fieller "
                        "inference is unavailable. Report the two divergences and "
                        "absolute loss, and do not treat the FMCI point ratio as a "
                        "stable inferential scalar."
                    ),
                }
            else:
                recommended = bool(
                    estimate.fmci_reportable
                    and inference.diagnostics.classification == "regular"
                    and inference.fieller.bounded
                )
                report["fmci_analysis"] = {
                    **point_payload,
                    "fmci_scalar_reporting_recommended": recommended,
                    "delta_intervals": {
                        "full": asdict(inference.full),
                        "observed": asdict(inference.observed),
                        "absolute_loss": asdict(inference.absolute_loss),
                        "fmci": (
                            asdict(inference.fmci_delta)
                            if inference.fmci_delta is not None
                            else None
                        ),
                    },
                    "fieller": asdict(inference.fieller),
                    "regularity": asdict(inference.diagnostics),
                    "interpretation": (
                        "FMCI is conditional on the declared common observation channel. "
                        "When the Fieller set is unbounded/disconnected or the regularity "
                        "diagnostics fail, report the two divergences and absolute loss but "
                        "do not summarize their ratio as a stable scalar."
                    ),
                }

    test = witness_test(
        scenario,
        counts,
        channel,
        alternative_win_rate=alternative_win_rate,
        randomized_contexts_verified=randomized_contexts_verified,
        context_unpredictability_verified=context_unpredictability_verified,
        channel_independently_fixed=channel_independently_fixed,
        score_prespecified=score_prespecified,
    )
    report["contextuality_test"] = asdict(test)
    report["joint_reporting_rule"] = (
        "Report the contextuality p-value/e-value and the FMCI interval side by side. "
        "They answer rejection and attenuation questions, respectively, and are not "
        "multiplied, averaged, or converted into one significance score."
    )
    return _jsonable(report)
