# Unified FMCI benchmark codebase

This repository reproduces the numerical benchmark package for loss-conditioned
relative-entropy contextuality. It evaluates the **same empirical probability
models** with three complementary quantities:

- contextual KL divergence to the noncontextual polytope;
- Fraction of Missing Contextual Information (FMCI) under a common erasure
  channel;
- Contextual Fraction (CF), including its transported-channel version.

The code deliberately remains separate from the manuscript source. Every table,
figure, and validation record is generated from this repository.

## Benchmarks

| Key | Canonical target | Full deterministic model | Reduced inequality model |
|---|---|---:|---:|
| `three_cycle` | perfect anticorrelation on all three edges | 8 assignments | 3 parity-sector coordinates |
| `kcbs` | symmetric KCBS point, `Pr(P_i=1)=1/sqrt(5)` | 32 assignments | exact 10-coordinate binary marginal polytope |
| `magic_square` | uniform Peres–Mermin target-parity model | 512 assignments | 6 parity-sector coordinates |

The hidden-variable formulation always uses every deterministic global
assignment. The 3-cycle and magic-square H-representations are symmetry
reductions and are exact only for the target/noise/channel families stated in
`Scenario.reduction_scope`. KCBS uses the full five-singleton/five-adjacent-joint
marginal representation.

## What a full run produces

- analytic and hidden-vs-facet validation for all three benchmarks;
- visibility scans comparing KL, CF, and normalized witness violation;
- exhaustive context-removal enumeration: 8, 32, and 64 subcovers;
- leave-one-out and Shapley context-criticality scores;
- a two-dimensional `(eta, alpha)` MNAR scan for the 3-cycle;
- contours for observed KL, FMCI, the signed rate-matched residual, and
  transported CF;
- cellwise erasure-sandwich checks and exact-hiding boundary checks;
- hidden-variable versus inequality-formulation timing and representation size;
- exact binary-cycle representation-growth tables;
- CSV tables, JSON validation records, a generated Markdown report, PDF/PNG
  figures, and SHA-256 checksums.

## Install and run

```bash
python -m pip install -e '.[dev]'
pytest
fmci-benchmarks --config configs/default.yaml
```

A fast smoke run is available:

```bash
fmci-benchmarks --quick --output outputs/quick
```

The direct script entry point is equivalent:

```bash
python scripts/run_all.py --config configs/default.yaml
```

## Mathematical objective

For context weights `w_C`, target context distributions `p_C`, and deterministic
incidence blocks `A_C`, the hidden formulation solves

```text
minimize_lambda  sum_C w_C KL(p_C || A_C lambda)
subject to       lambda >= 0, sum(lambda) = 1.
```

A common whole-outcome erasure channel is applied to the target and every
noncontextual component. Each context gains a context-labelled star outcome.
The multiplicative mixture solver returns a simplex Frank–Wolfe/KKT gap in nats.
The reduced constrained solver uses SLSQP for the candidate point and then
computes an independent polytope Frank–Wolfe gap over all known reduced
vertices. Exactly extendable zero-KL subcovers are certified by a HiGHS linear
feasibility refinement. The severe-loss three-cycle family also receives an
active-facet one-dimensional polish when its exchange symmetry is detected.
Consequently, a solver status flag is never the only numerical check.

Contextual Fraction is solved with SciPy/HiGHS using the standard
noncontextual-submodel linear program. For observed-data comparisons, the same
transported response matrix used by KL is passed to the CF program.

## Context omission

Omitted contexts are not deleted and the remaining context weights are not
renormalized. Instead, a design channel maps every outcome of an omitted context
to its star symbol. This evaluates information lost relative to the intended
full experiment.

## Three-cycle MNAR family

The scan implements

```text
C12, C23: retention = eta
C13 target-support anticorrelations: retention = eta * alpha^2
C13 correlated cells: retention = eta * alpha
```

It verifies

```text
eta * alpha^2 * D_full <= D_observed <= eta * D_full.
```

For this family, exact population-level hiding occurs on the boundary
`eta = 0` or `alpha = 0`; no positive interior threshold is inferred. A
finite-sample detectability boundary would require a separate inferential model
and is intentionally not fabricated here.

## Source map

- `scenarios.py`: exact benchmark probability tables and deterministic models.
- `channels.py`: identity, MCAR, context-conditional MAR, design, and MNAR
  channels.
- `solvers.py`: hidden V-representation and reduced H-representation KL solvers.
- `metrics.py`: Contextual Fraction and canonical witnesses.
- `experiments.py`: all scans, validation, figures, reports, and manifests.
- `tests/`: analytic identities, loss theorems, subcovers, solver agreement, and
  end-to-end smoke tests.

## Primary benchmark references

- A. A. Klyachko, M. A. Can, S. Binicioğlu, and A. S. Shumovsky, *Simple test
  for hidden variables in spin-1 systems*, Physical Review Letters 101, 020403
  (2008), DOI `10.1103/PhysRevLett.101.020403`.
- M. Araújo, M. T. Quintino, C. Budroni, M. T. Cunha, and A. Cabello, *All
  noncontextuality inequalities for the n-cycle scenario*, Physical Review A 88,
  022118 (2013), arXiv `1206.3212`.
- A. Peres, *Incompatible results of quantum measurements*, Physics Letters A
  151, 107–108 (1990), DOI `10.1016/0375-9601(90)90172-K`.
- N. D. Mermin, *Simple unified form for the major no-hidden-variables
  theorems*, Physical Review Letters 65, 3373–3376 (1990), DOI
  `10.1103/PhysRevLett.65.3373`.
- A. Grudka, K. Horodecki, M. Horodecki, P. Horodecki, R. Horodecki,
  P. Joshi, W. Kłobus, and A. Wójcik, *Quantifying Contextuality*, Physical
  Review Letters 112, 120401 (2014), arXiv `1209.3745`.
- S. Abramsky, R. S. Barbosa, and S. Mansfield, *The Contextual Fraction as a
  Measure of Contextuality*, Physical Review Letters 119, 050504 (2017), arXiv
  `1705.07918`.

## Numerical dependencies

The LP uses `scipy.optimize.linprog(method="highs")`; constrained KL uses
`scipy.optimize.minimize(method="SLSQP")`; facets are generated with Qhull via
`scipy.spatial.ConvexHull`; contours use Matplotlib `contourf`.
