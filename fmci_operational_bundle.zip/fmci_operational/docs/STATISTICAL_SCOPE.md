# Statistical claims and scope

## Identification

For one context with complete probabilities `p_i` and whole-outcome retention
`a_i`, the observed probabilities are

```text
q_i = a_i p_i,
q_star = 1 - sum_i a_i p_i.
```

On the probability simplex, this map is injective if and only if at most one
retention value is zero. With two zero-retention cells, only their sum is
observed through `q_star`. With no more than one zero cell, all positive-retention
probabilities are recovered from `q_i / a_i`, and a single zero-retention
probability is recovered by normalization.

Strong positivity is therefore sufficient but not necessary for point
identification. It is imposed for ordinary smooth Fisher-information theory,
and small retentions lead to poor conditioning even when rank is full.

## Regular asymptotic theory

On a compact regular class with:

- fixed finite alphabets and context weights;
- a known, point-identifying channel whose relevant singular values and
  retentions are bounded away from zero;
- complete and observed probabilities bounded away from zero on varying rows;
- a unique, locally stable KL projection to a fixed face of the noncontextual
  polytope; and
- `D_full` bounded away from zero,

the latent MLE is root-`N` asymptotically normal. Envelope gradients for the two
projected KL values produce a joint delta-method limit for
`(D_observed, D_full, Delta)`. FMCI is then an ordinary smooth ratio, and its
mean-squared error is of order `1/N` under the regular-class bounds.

The package supplies the corresponding plug-in covariance, delta intervals,
and Fieller confidence set. The latter is primary for diagnosing denominator
weakness.

## Bias

For a twice differentiable scalar functional of a regular MLE, the leading
bias is generally of order `1/N`, but its coefficient depends on the channel,
context design, active projection geometry, and derivatives of the estimand.
The validation suite reports `N * bias` separately for each estimand and design.
It does not use a universal Miller–Madow or `d/(2N)` correction for projected KL
or for FMCI.

## Boundary and singular cases

The regular result is not claimed when:

- the true behavior is noncontextual or approaches the noncontextual boundary;
- the KL projection is nonunique or changes active face;
- probabilities or fitted comparator cells vanish on varying rows;
- channel rank fails or retention approaches a nonidentification boundary;
- `D_full` is zero or weakly separated from zero.

Constrained likelihood and projection statistics can have tangent-cone or
other non-Gaussian limits in such cases. A generic ordinary percentile
bootstrap is not certified there. The software exposes boundary-risk and
weak-denominator classifications and retains unbounded/disconnected Fieller
sets.

## Minimax statement

A global minimax rate is not meaningful without specifying a parameter class,
loss, channel positivity margin, projection stability, and separation from the
noncontextual set. On the regular finite-dimensional class above, local
quadratic risk for smooth functionals has the usual parametric order `1/N`
(root mean-squared error `N^{-1/2}`). This does not extend uniformly to weak
identification or a vanishing FMCI denominator.

## Calibration and sensitivity coverage

Let `K` be an independent `(1 - alpha_cal)` confidence set for the true channel.
Suppose each fixed-channel interval has conditional coverage at least
`1 - alpha_exp`. The union of intervals over channels in `K` then has coverage
at least `1 - alpha_cal - alpha_exp`, conditional on the true mechanism being in
the declared family and, for a computational grid, represented or
conservatively enclosed by that grid.

The supplied default uses a Bonferroni simultaneous Clopper–Pearson box. The
method is conservative and transparent; sharper joint calibration procedures
may replace it if their guarantees are documented.

## Contextuality evidence

The canonical binary game scores no-clicks as losses. If, under every permitted
history, the next-trial conditional win probability is at most the transported
noncontextual bound `beta`, then the sum of wins is stochastically dominated by
`Binomial(N, beta)`. The upper binomial tail is therefore a valid finite-sample
p-value even with arbitrary device memory, provided current settings are
freshly randomized and unpredictable and the score/channel assumptions were
fixed independently as declared.

For calibration uncertainty, the package reports the supremum valid
fixed-channel p-value over the compatible set. Adding the calibration failure
probability yields a conservative unconditional p-value under the declared
family-inclusion assumptions.

## Joint reporting

FMCI is an attenuation estimand; a contextuality p-value is a null-rejection
quantity. No generally valid operation turns them into one scalar. The package
reports them in a two-axis table together with assumptions and sensitivity
results.

## Primary statistical references

- C. J. Geyer, “On the Asymptotics of Constrained M-Estimation,” *Annals of
  Statistics* 22 (1994), 1993–2010.
- S. G. Self and K.-Y. Liang, “Asymptotic Properties of Maximum Likelihood
  Estimators and Likelihood Ratio Tests under Nonstandard Conditions,” *JASA*
  82 (1987), 605–610.
- D. W. K. Andrews, “Inconsistency of the Bootstrap when a Parameter is on the
  Boundary of the Parameter Space,” *Econometrica* 68 (2000), 399–405.
- Z. Fang and A. Santos, “Inference on Directionally Differentiable Functions,”
  *Review of Economic Studies* 86 (2019), 377–412.
- E. C. Fieller, “Some Problems in Interval Estimation,” *JRSS B* 16 (1954),
  175–185.
- P. H. Clopper and E. S. Pearson, “The Use of Confidence or Fiducial Limits
  Illustrated in the Case of the Binomial,” *Biometrika* 26 (1934), 404–413.
- D. Elkouss and S. Wehner, “(Nearly) Optimal P Values for All Bell Inequalities,”
  *npj Quantum Information* 2, 16026 (2016).
- Y. Zhang, S. Glancy, and E. Knill, “Asymptotically Optimal Data Analysis for
  Rejecting Local Realism,” *Physical Review A* 84, 062118 (2011).
- J. M. Robins, A. Rotnitzky, and D. O. Scharfstein, “Sensitivity Analysis for
  Selection Bias and Unmeasured Confounding in Missing Data and Causal
  Inference Models,” in *Statistical Models in Epidemiology, the Environment,
  and Clinical Trials* (2000).
