from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy.stats import binom

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario

from .data import ObservedCounts
from .estimands import project_empirical_observed_distribution


@dataclass(frozen=True)
class WitnessTestResult:
    scenario: str
    successes: int
    attempts: int
    observed_win_rate: float
    transported_noncontextual_win_bound: float
    binomial_tail_pvalue: float
    memory_robust_winlose_pvalue: float | None
    prespecified_alternative_win_rate: float | None
    test_evalue: float | None
    evalue_pvalue_bound: float | None
    empirical_glr_statistic: float
    empirical_glr_divergence: float
    assumptions_verified: bool
    assumptions: tuple[str, ...]
    unverified_assumptions: tuple[str, ...]


def canonical_success_masks(scenario: Scenario) -> tuple[np.ndarray, ...]:
    """Binary win/lose representation of the benchmark inequality."""

    masks: list[np.ndarray] = []
    if scenario.key == "three_cycle":
        for context in scenario.contexts:
            masks.append(
                np.asarray(
                    [outcome[0] * outcome[1] == -1 for outcome in context.outcomes],
                    dtype=bool,
                )
            )
    elif scenario.key == "kcbs":
        for context in scenario.contexts:
            masks.append(
                np.asarray([sum(outcome) == 1 for outcome in context.outcomes], dtype=bool)
            )
    elif scenario.key == "magic_square":
        target_signs = (1, 1, 1, 1, 1, -1)
        for context, sign in zip(scenario.contexts, target_signs, strict=True):
            masks.append(
                np.asarray(
                    [int(np.prod(outcome)) == sign for outcome in context.outcomes],
                    dtype=bool,
                )
            )
    else:
        raise KeyError(f"no canonical binary game for {scenario.key}")
    return tuple(masks)


def transported_noncontextual_win_bound(
    scenario: Scenario,
    channel: Channel,
    *,
    success_masks: tuple[np.ndarray, ...] | None = None,
) -> float:
    """Maximum attempted-trial win probability over deterministic NC models."""

    channel.validate(scenario)
    masks = canonical_success_masks(scenario) if success_masks is None else success_masks
    if len(masks) != scenario.n_contexts:
        raise ValueError("success_masks has the wrong number of contexts")
    values = np.zeros(scenario.n_assignments, dtype=float)
    for weight, sl, retention, mask in zip(
        scenario.context_weights,
        scenario.context_slices,
        channel.retention_by_context,
        masks,
        strict=True,
    ):
        local_rewards = np.asarray(retention, dtype=float) * np.asarray(mask, dtype=float)
        values += float(weight) * (local_rewards @ scenario.incidence[sl])
    return float(np.max(values))


def target_win_probability(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
    *,
    success_masks: tuple[np.ndarray, ...] | None = None,
) -> float:
    masks = canonical_success_masks(scenario) if success_masks is None else success_masks
    target = np.asarray(target_flat, dtype=float)
    total = 0.0
    for weight, sl, retention, mask in zip(
        scenario.context_weights,
        scenario.context_slices,
        channel.retention_by_context,
        masks,
        strict=True,
    ):
        total += float(
            weight
            * np.dot(
                target[sl],
                np.asarray(retention, dtype=float) * np.asarray(mask, dtype=float),
            )
        )
    return total


def observed_wins(
    scenario: Scenario,
    counts: ObservedCounts,
    *,
    success_masks: tuple[np.ndarray, ...] | None = None,
) -> int:
    counts.validate(scenario)
    masks = canonical_success_masks(scenario) if success_masks is None else success_masks
    total = 0
    for block, mask in zip(counts.counts_by_context, masks, strict=True):
        total += int(np.dot(np.asarray(block[:-1], dtype=int), np.asarray(mask, dtype=int)))
    return total


def binomial_tail_pvalue(successes: int, attempts: int, null_bound: float) -> float:
    if attempts <= 0:
        raise ValueError("attempts must be positive")
    if not 0 <= successes <= attempts:
        raise ValueError("successes must lie between zero and attempts")
    if not 0.0 <= null_bound <= 1.0:
        raise ValueError("null_bound must lie in [0,1]")
    return float(binom.sf(successes - 1, attempts, null_bound))


def prespecified_bernoulli_evalue(
    successes: int,
    attempts: int,
    null_bound: float,
    alternative_win_rate: float,
) -> float:
    """Test-martingale e-value for a pre-specified Bernoulli alternative.

    The product is a nonnegative supermartingale whenever each trial's
    conditional win probability is at most ``null_bound``.  The alternative
    must be fixed independently of the tested data (or learned on a disjoint
    training block).
    """

    b = float(null_bound)
    r = float(alternative_win_rate)
    if not 0.0 < b < 1.0:
        raise ValueError("e-value implementation requires null bound in (0,1)")
    if not b < r < 1.0:
        raise ValueError("alternative_win_rate must lie strictly between bound and one")
    failures = attempts - successes
    log_e = successes * math.log(r / b) + failures * math.log((1.0 - r) / (1.0 - b))
    return float(math.exp(min(log_e, 700.0)))


def witness_test(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    *,
    alternative_win_rate: float | None = None,
    randomized_contexts_verified: bool = False,
    context_unpredictability_verified: bool = False,
    channel_independently_fixed: bool = False,
    score_prespecified: bool = True,
) -> WitnessTestResult:
    """Joint finite-sample contextuality evidence for the canonical game.

    The win/lose binomial tail is valid under arbitrary device memory provided
    the current context is generated independently with the declared
    ``scenario.context_weights`` and is unavailable to the hidden strategy
    before the trial.  It is conditional on the declared common observation
    channel because its null bound is computed over the transported NC set.
    """

    successes = observed_wins(scenario, counts)
    attempts = counts.total_trials
    bound = transported_noncontextual_win_bound(scenario, channel)
    pvalue = binomial_tail_pvalue(successes, attempts, bound)
    evalue: float | None = None
    evalue_bound: float | None = None
    if alternative_win_rate is not None and alternative_win_rate > bound:
        evalue = prespecified_bernoulli_evalue(
            successes,
            attempts,
            bound,
            alternative_win_rate,
        )
        evalue_bound = min(1.0, 1.0 / evalue)
    empirical = project_empirical_observed_distribution(scenario, counts, channel)
    statistic = 2.0 * attempts * empirical.divergence
    checks = {
        "contexts are generated independently with the declared probabilities": randomized_contexts_verified,
        "the current context is not predictable by the noncontextual strategy": context_unpredictability_verified,
        "the common observation channel is fixed or calibrated independently": channel_independently_fixed,
        "the binary score is fixed before inspecting the tested data": score_prespecified,
    }
    assumptions_verified = all(checks.values())
    memory_pvalue = pvalue if assumptions_verified else None
    return WitnessTestResult(
        scenario=scenario.key,
        successes=successes,
        attempts=attempts,
        observed_win_rate=float(successes / attempts),
        transported_noncontextual_win_bound=bound,
        binomial_tail_pvalue=pvalue,
        # For binary win/lose games, the same binomial upper tail remains valid
        # with arbitrary memory under the conditional-win bound, but only after
        # the design assumptions below have been affirmatively verified.
        memory_robust_winlose_pvalue=memory_pvalue,
        prespecified_alternative_win_rate=alternative_win_rate,
        test_evalue=evalue,
        evalue_pvalue_bound=evalue_bound,
        empirical_glr_statistic=float(statistic),
        empirical_glr_divergence=float(empirical.divergence),
        assumptions_verified=assumptions_verified,
        assumptions=tuple(checks),
        unverified_assumptions=tuple(key for key, value in checks.items() if not value),
    )
