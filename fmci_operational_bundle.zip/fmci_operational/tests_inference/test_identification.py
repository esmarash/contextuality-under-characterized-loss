from __future__ import annotations

import numpy as np

from fmci_benchmarks.channels import Channel, three_cycle_eta_alpha_channel
from fmci_benchmarks.scenarios import get_scenario
from fmci_inference.data import CalibrationCounts
from fmci_inference.identification import (
    fit_latent_context_em,
    identification_report,
)
from fmci_inference.sensitivity import simultaneous_clopper_pearson_box


def test_mcar_latent_mle_equals_detected_composition() -> None:
    counts = np.asarray([20, 30, 10, 40, 100])
    fit = fit_latent_context_em(counts, np.full(4, 0.5))
    assert fit.converged
    np.testing.assert_allclose(fit.probabilities, [0.2, 0.3, 0.1, 0.4], atol=1e-10)


def test_erasure_identification_allows_one_but_not_two_zero_cells() -> None:
    scenario = get_scenario("three_cycle")
    one_zero = Channel(
        "one_zero",
        (
            np.asarray([0.0, 0.5, 0.5, 0.5]),
            np.ones(4),
            np.ones(4),
        ),
    )
    two_zero = Channel(
        "two_zero",
        (
            np.asarray([0.0, 0.0, 0.5, 0.5]),
            np.ones(4),
            np.ones(4),
        ),
    )
    assert identification_report(scenario, one_zero).point_identified
    assert not identification_report(scenario, two_zero).point_identified
    assert not identification_report(
        scenario, three_cycle_eta_alpha_channel(scenario, 0.8, 0.0)
    ).point_identified


def test_simultaneous_calibration_box_contains_nominal_channel() -> None:
    scenario = get_scenario("three_cycle")
    successes = tuple(np.full(4, 800, dtype=int) for _ in scenario.contexts)
    totals = tuple(np.full(4, 1000, dtype=int) for _ in scenario.contexts)
    calibration = CalibrationCounts(successes, totals)
    box = simultaneous_clopper_pearson_box(scenario, calibration, confidence=0.95)
    channel = Channel(
        "eta_0.8",
        tuple(np.full(4, 0.8) for _ in scenario.contexts),
    )
    assert box.contains(scenario, channel)
