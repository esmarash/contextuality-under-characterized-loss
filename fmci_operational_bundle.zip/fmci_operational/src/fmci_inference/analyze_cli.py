from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from fmci_benchmarks.scenarios import get_scenario, list_scenarios

from .io import load_calibration_counts, load_channel, load_observed_counts
from .reporting import analyze_known_channel


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Analyze context-labelled counts under a declared common channel."
    )
    parser.add_argument("--scenario", choices=list_scenarios(), required=True)
    parser.add_argument("--counts", type=Path, required=True)
    parser.add_argument("--channel", type=Path, required=True)
    parser.add_argument("--calibration", type=Path, default=None)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--confidence", type=float, default=0.95)
    parser.add_argument("--calibration-confidence", type=float, default=0.975)
    parser.add_argument("--alternative-win-rate", type=float, default=None)
    parser.add_argument("--verify-randomized-contexts", action="store_true")
    parser.add_argument("--verify-context-unpredictability", action="store_true")
    parser.add_argument("--verify-independent-channel", action="store_true")
    parser.add_argument(
        "--score-not-prespecified",
        action="store_true",
        help="declare that the score was selected after inspecting tested data",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    scenario = get_scenario(args.scenario)
    counts = load_observed_counts(args.counts, scenario)
    channel = load_channel(args.channel, scenario)
    calibration = (
        None
        if args.calibration is None
        else load_calibration_counts(args.calibration, scenario)
    )
    report = analyze_known_channel(
        scenario,
        counts,
        channel,
        calibration=calibration,
        calibration_confidence=args.calibration_confidence,
        inference_confidence=args.confidence,
        alternative_win_rate=args.alternative_win_rate,
        randomized_contexts_verified=args.verify_randomized_contexts,
        context_unpredictability_verified=args.verify_context_unpredictability,
        channel_independently_fixed=args.verify_independent_channel,
        score_prespecified=not args.score_not_prespecified,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(f"wrote {args.output}")


if __name__ == "__main__":
    main()
