from fmci_inference.cli import main

if __name__ == "__main__":
    main()
