import math

import numpy as np

from fmci_benchmarks.metrics import contextual_fraction
from fmci_benchmarks.scenarios import get_scenario
from fmci_benchmarks.solvers import solve_facets, solve_hidden


def _analytic_kcbs() -> float:
    q = 1.0 / math.sqrt(5.0)
    return (1.0 - 2.0 * q) * math.log((1.0 - 2.0 * q) / 0.2) + 2.0 * q * math.log(q / 0.4)


def test_full_divergence_analytic_values() -> None:
    expected = {
        "three_cycle": math.log(3.0 / 2.0),
        "kcbs": _analytic_kcbs(),
        "magic_square": math.log(6.0 / 5.0),
    }
    for key, value in expected.items():
        scenario = get_scenario(key)
        hidden = solve_hidden(scenario)
        facets = solve_facets(scenario)
        assert hidden.success, hidden.message
        assert facets.success, facets.message
        np.testing.assert_allclose(hidden.divergence, value, atol=2.0e-9, rtol=0.0)
        np.testing.assert_allclose(facets.divergence, value, atol=2.0e-9, rtol=0.0)
        np.testing.assert_allclose(
            hidden.divergence, facets.divergence, atol=2.0e-9, rtol=0.0
        )


def test_contextual_fraction_analytic_values() -> None:
    expected = {
        "three_cycle": 1.0,
        "kcbs": 2.0 * (math.sqrt(5.0) - 2.0),
        "magic_square": 1.0,
    }
    for key, value in expected.items():
        result = contextual_fraction(get_scenario(key))
        assert result.success, result.message
        np.testing.assert_allclose(
            result.contextual_fraction, value, atol=2.0e-9, rtol=0.0
        )
