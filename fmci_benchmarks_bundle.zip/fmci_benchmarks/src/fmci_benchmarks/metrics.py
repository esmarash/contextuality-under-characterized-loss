from __future__ import annotations

import time
from dataclasses import dataclass

import numpy as np
from scipy.optimize import linprog

from .channels import Channel, identity_channel
from .model import Scenario
from .solvers import observed_target_and_components


@dataclass(frozen=True)
class ContextualFractionResult:
    contextual_fraction: float
    noncontextual_fraction: float
    success: bool
    message: str
    subprobability_weights: np.ndarray
    runtime_seconds: float
    iterations: int
    constraint_violation: float


@dataclass(frozen=True)
class WitnessResult:
    value: float
    noncontextual_bound: float
    algebraic_bound: float
    normalized_violation: float


def contextual_fraction(
    scenario: Scenario,
    *,
    target_flat: np.ndarray | None = None,
    channel: Channel | None = None,
    active_contexts: np.ndarray | None = None,
) -> ContextualFractionResult:
    """Compute Contextual Fraction by the noncontextual-submodel LP.

    When ``channel`` is supplied, the LP is evaluated relative to the common
    transported deterministic response set. This is the channel-adapted CF
    used for direct comparisons with observed-data KL/FMCI.
    """

    target = scenario.target_flat if target_flat is None else np.asarray(target_flat)
    if target.shape != (scenario.n_events,):
        raise ValueError("target_flat has the wrong shape")
    observation = identity_channel(scenario) if channel is None else channel
    target_obs, components, row_contexts = observed_target_and_components(
        scenario, target, observation
    )

    if active_contexts is None:
        active = np.ones(scenario.n_contexts, dtype=bool)
    else:
        active = np.asarray(active_contexts, dtype=bool)
        if active.shape != (scenario.n_contexts,):
            raise ValueError("active_contexts has the wrong shape")
    if not np.any(active):
        return ContextualFractionResult(
            contextual_fraction=0.0,
            noncontextual_fraction=1.0,
            success=True,
            message="empty subcover",
            subprobability_weights=np.zeros(scenario.n_assignments),
            runtime_seconds=0.0,
            iterations=0,
            constraint_violation=0.0,
        )

    rows = active[row_contexts]
    started = time.perf_counter()
    result = linprog(
        c=-np.ones(scenario.n_assignments),
        A_ub=components[rows],
        b_ub=np.maximum(target_obs[rows], 0.0),
        bounds=(0.0, None),
        method="highs",
    )
    runtime = time.perf_counter() - started
    if not result.success or result.x is None:
        return ContextualFractionResult(
            contextual_fraction=float("nan"),
            noncontextual_fraction=float("nan"),
            success=False,
            message=str(result.message),
            subprobability_weights=np.full(scenario.n_assignments, np.nan),
            runtime_seconds=runtime,
            iterations=int(getattr(result, "nit", 0)),
            constraint_violation=float("inf"),
        )

    weights = np.maximum(np.asarray(result.x, dtype=float), 0.0)
    violation = float(max(0.0, np.max(components[rows] @ weights - target_obs[rows])))
    noncontextual_fraction = float(np.clip(np.sum(weights), 0.0, 1.0))
    return ContextualFractionResult(
        contextual_fraction=float(np.clip(1.0 - noncontextual_fraction, 0.0, 1.0)),
        noncontextual_fraction=noncontextual_fraction,
        success=bool(violation <= 1.0e-8),
        message=str(result.message),
        subprobability_weights=weights,
        runtime_seconds=runtime,
        iterations=int(getattr(result, "nit", 0)),
        constraint_violation=violation,
    )


def witness_result(scenario: Scenario, reduced_behavior: np.ndarray) -> WitnessResult:
    x = np.asarray(reduced_behavior, dtype=float)
    if x.shape != (scenario.reduced_dimension,):
        raise ValueError("reduced_behavior has the wrong shape")
    witness = scenario.witness
    value = float(np.dot(witness.coefficients, x))
    denominator = witness.algebraic_bound - witness.noncontextual_bound
    normalized = max(0.0, (value - witness.noncontextual_bound) / denominator)
    return WitnessResult(
        value=value,
        noncontextual_bound=witness.noncontextual_bound,
        algebraic_bound=witness.algebraic_bound,
        normalized_violation=float(min(1.0, normalized)),
    )
