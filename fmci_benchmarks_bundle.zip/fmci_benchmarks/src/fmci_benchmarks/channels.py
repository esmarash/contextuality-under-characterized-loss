from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

import numpy as np

from .model import Scenario


@dataclass(frozen=True)
class Channel:
    """Common whole-outcome erasure channel.

    ``retention_by_context[c][i]`` is the probability that complete outcome
    ``i`` in context ``c`` is retained. Rejected outcomes are merged into one
    context-labelled star outcome. The same channel is applied to the target
    behavior and every deterministic noncontextual component.
    """

    name: str
    retention_by_context: tuple[np.ndarray, ...]
    parameters: Mapping[str, float] = field(default_factory=dict)

    def validate(self, scenario: Scenario) -> None:
        if len(self.retention_by_context) != scenario.n_contexts:
            raise ValueError("channel has the wrong number of contexts")
        for context, rates in zip(
            scenario.contexts, self.retention_by_context, strict=True
        ):
            values = np.asarray(rates, dtype=float)
            if values.shape != (len(context.outcomes),):
                raise ValueError(f"retention shape mismatch in {context.name}")
            if np.any(~np.isfinite(values)):
                raise ValueError("retention probabilities must be finite")
            if np.any(values < 0.0) or np.any(values > 1.0):
                raise ValueError("retention probabilities must lie in [0, 1]")

    def flat_retention(self, scenario: Scenario) -> np.ndarray:
        self.validate(scenario)
        return np.concatenate(self.retention_by_context).astype(float, copy=False)

    def minimum_retention(self, scenario: Scenario) -> float:
        return float(np.min(self.flat_retention(scenario)))

    def maximum_retention(self, scenario: Scenario) -> float:
        return float(np.max(self.flat_retention(scenario)))

    def target_mean_retention(
        self,
        scenario: Scenario,
        target_flat: np.ndarray | None = None,
    ) -> float:
        target = scenario.target_flat if target_flat is None else np.asarray(target_flat)
        if target.shape != (scenario.n_events,):
            raise ValueError("target_flat has the wrong shape")
        total = 0.0
        for weight, sl, rates in zip(
            scenario.context_weights,
            scenario.context_slices,
            self.retention_by_context,
            strict=True,
        ):
            total += float(weight * np.dot(target[sl], rates))
        return total


def identity_channel(scenario: Scenario) -> Channel:
    return Channel(
        name="identity",
        retention_by_context=tuple(
            np.ones(len(context.outcomes), dtype=float) for context in scenario.contexts
        ),
    )


def mcar_channel(scenario: Scenario, efficiency: float) -> Channel:
    if not 0.0 <= efficiency <= 1.0:
        raise ValueError("efficiency must lie in [0, 1]")
    return Channel(
        name=f"mcar_eta_{efficiency:g}",
        retention_by_context=tuple(
            np.full(len(context.outcomes), efficiency, dtype=float)
            for context in scenario.contexts
        ),
        parameters={"eta": float(efficiency)},
    )


def context_mar_channel(
    scenario: Scenario,
    efficiencies: Mapping[str, float],
    *,
    default: float = 1.0,
) -> Channel:
    """Context-conditional, outcome-ignorable retention channel."""

    if not 0.0 <= default <= 1.0:
        raise ValueError("default efficiency must lie in [0, 1]")
    blocks: list[np.ndarray] = []
    for context in scenario.contexts:
        efficiency = float(efficiencies.get(context.name, default))
        if not 0.0 <= efficiency <= 1.0:
            raise ValueError(f"invalid efficiency for {context.name}")
        blocks.append(np.full(len(context.outcomes), efficiency, dtype=float))
    return Channel(
        name="context_mar",
        retention_by_context=tuple(blocks),
        parameters={name: float(value) for name, value in efficiencies.items()},
    )


# Backward-compatible spelling retained for code written against v0.1.
context_mcar_channel = context_mar_channel


def design_subcover_channel(
    scenario: Scenario,
    retained_contexts: Sequence[str] | np.ndarray,
) -> Channel:
    """Map omitted contexts to a deterministic star outcome.

    Original context weights are preserved. Therefore this represents design
    loss relative to the full intended experiment rather than a new,
    renormalized context-selection distribution.
    """

    if isinstance(retained_contexts, np.ndarray):
        mask = np.asarray(retained_contexts, dtype=bool)
        if mask.shape != (scenario.n_contexts,):
            raise ValueError("retained context mask has the wrong shape")
    else:
        names = set(retained_contexts)
        known = {context.name for context in scenario.contexts}
        unknown = names - known
        if unknown:
            raise ValueError(f"unknown contexts: {sorted(unknown)}")
        mask = np.asarray(
            [context.name in names for context in scenario.contexts], dtype=bool
        )
    blocks = tuple(
        np.full(len(context.outcomes), 1.0 if keep else 0.0, dtype=float)
        for context, keep in zip(scenario.contexts, mask, strict=True)
    )
    return Channel(
        name="design_subcover",
        retention_by_context=blocks,
        parameters={
            f"retain_{context.name}": float(keep)
            for context, keep in zip(scenario.contexts, mask, strict=True)
        },
    )


def three_cycle_eta_alpha_channel(
    scenario: Scenario,
    eta: float,
    alpha: float,
) -> Channel:
    """The manuscript's two-parameter MNAR family for the 3-cycle.

    ``C12`` and ``C23`` retain every outcome at ``eta``. In ``C13``,
    anticorrelated target-support outcomes are retained at ``eta * alpha**2``
    and correlated outcomes at ``eta * alpha``.
    """

    if scenario.key != "three_cycle":
        raise ValueError("the eta-alpha channel is defined only for three_cycle")
    if not 0.0 <= eta <= 1.0 or not 0.0 <= alpha <= 1.0:
        raise ValueError("eta and alpha must lie in [0, 1]")
    blocks: list[np.ndarray] = []
    for context in scenario.contexts:
        if context.name != "C13":
            blocks.append(np.full(len(context.outcomes), eta, dtype=float))
            continue
        rates = np.asarray(
            [
                eta * alpha**2 if outcome[0] * outcome[1] == -1 else eta * alpha
                for outcome in context.outcomes
            ],
            dtype=float,
        )
        blocks.append(rates)
    return Channel(
        name="three_cycle_eta_alpha",
        retention_by_context=tuple(blocks),
        parameters={"eta": float(eta), "alpha": float(alpha)},
    )
