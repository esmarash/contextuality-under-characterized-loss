from __future__ import annotations

import numpy as np

from fmci_benchmarks.channels import mcar_channel, three_cycle_eta_alpha_channel
from fmci_benchmarks.scenarios import get_scenario
from fmci_benchmarks.solvers import solve_hidden
from fmci_inference.data import simulate_observed_counts
from fmci_inference.estimands import estimate_fmci, full_and_observed_gradients
from fmci_inference.inference import fieller_fmci_set, regular_inference


def _regular_estimate(seed: int = 11):
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    counts = simulate_observed_counts(
        scenario, target, channel, 20_000, np.random.default_rng(seed)
    ).counts
    estimate = estimate_fmci(scenario, counts, channel)
    return scenario, channel, counts, estimate


def test_coherent_estimator_obeys_dpi_and_mcar_scaling() -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = mcar_channel(scenario, 0.8)
    counts = simulate_observed_counts(
        scenario, target, channel, 20_000, np.random.default_rng(4)
    ).counts
    estimate = estimate_fmci(scenario, counts, channel)
    assert estimate.observed_divergence <= estimate.full_divergence + 1e-10
    np.testing.assert_allclose(
        estimate.observed_divergence,
        0.8 * estimate.full_divergence,
        rtol=0,
        atol=2e-10,
    )
    np.testing.assert_allclose(estimate.fmci, 0.2, atol=2e-9)


def test_envelope_gradients_match_finite_differences() -> None:
    scenario, channel, _, estimate = _regular_estimate()
    full_gradient, observed_gradient = full_and_observed_gradients(
        scenario, estimate, channel
    )
    target = estimate.latent_fit.target_flat.copy()
    epsilon = 2e-6
    numerical_full: list[float] = []
    numerical_observed: list[float] = []
    for context_slice in scenario.context_slices:
        for j in range(context_slice.stop - context_slice.start - 1):
            plus = target.copy()
            minus = target.copy()
            plus[context_slice.start + j] += epsilon
            plus[context_slice.stop - 1] -= epsilon
            minus[context_slice.start + j] -= epsilon
            minus[context_slice.stop - 1] += epsilon
            full_plus = solve_hidden(
                scenario,
                target_flat=plus,
                initial_weights=estimate.full_projection.optimizer,
                tolerance=1e-10,
            ).divergence
            full_minus = solve_hidden(
                scenario,
                target_flat=minus,
                initial_weights=estimate.full_projection.optimizer,
                tolerance=1e-10,
            ).divergence
            observed_plus = solve_hidden(
                scenario,
                target_flat=plus,
                channel=channel,
                initial_weights=estimate.observed_projection.optimizer,
                tolerance=1e-10,
            ).divergence
            observed_minus = solve_hidden(
                scenario,
                target_flat=minus,
                channel=channel,
                initial_weights=estimate.observed_projection.optimizer,
                tolerance=1e-10,
            ).divergence
            numerical_full.append((full_plus - full_minus) / (2 * epsilon))
            numerical_observed.append(
                (observed_plus - observed_minus) / (2 * epsilon)
            )
    np.testing.assert_allclose(numerical_full, full_gradient, atol=5e-7, rtol=0)
    np.testing.assert_allclose(
        numerical_observed, observed_gradient, atol=5e-7, rtol=0
    )


def test_fieller_reports_weak_denominator_instead_of_fake_finite_interval() -> None:
    bounded = fieller_fmci_set(
        0.8, 1.0, np.asarray([[0.001, 0.0], [0.0, 0.001]])
    )
    assert bounded.bounded
    assert bounded.fmci_intervals
    weak = fieller_fmci_set(
        0.008, 0.01, np.asarray([[0.001, 0.0], [0.0, 0.001]])
    )
    assert not weak.bounded
    assert weak.fmci_intervals == ((0.0, 1.0),)


def test_regular_inference_returns_joint_covariance_and_bounded_fieller_set() -> None:
    scenario, channel, counts, estimate = _regular_estimate(seed=15)
    result = regular_inference(scenario, counts, channel, estimate)
    assert result.covariance_observed_full.shape == (2, 2)
    assert np.all(np.linalg.eigvalsh(result.covariance_observed_full) >= -1e-12)
    assert result.fieller.bounded
    assert result.diagnostics.classification == "regular"
