from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Literal

import numpy as np
from scipy.optimize import Bounds, brentq, linprog, minimize, minimize_scalar

from .channels import Channel, identity_channel
from .geometry import FacetRepresentation, facet_representation
from .model import Scenario

Formulation = Literal["hidden", "facets"]


@dataclass(frozen=True)
class SolveResult:
    formulation: str
    divergence: float
    runtime_seconds: float
    iterations: int
    success: bool
    message: str
    optimizer: np.ndarray
    observed_target: np.ndarray
    observed_fit: np.ndarray
    optimality_gap: float
    certificate_kind: str
    constraint_violation: float


def _validate_target(scenario: Scenario, target_flat: np.ndarray) -> np.ndarray:
    target = np.asarray(target_flat, dtype=float)
    if target.shape != (scenario.n_events,):
        raise ValueError("target_flat has the wrong shape")
    if np.any(~np.isfinite(target)):
        raise ValueError("target probabilities must be finite")
    if np.any(target < -1.0e-12):
        raise ValueError("target probabilities must be nonnegative")
    for context, sl in zip(scenario.contexts, scenario.context_slices, strict=True):
        if not np.isclose(np.sum(target[sl]), 1.0, atol=1.0e-10):
            raise ValueError(f"target is not normalized in {context.name}")
    return np.maximum(target, 0.0)


def _validate_active_mask(
    scenario: Scenario,
    active_contexts: np.ndarray | None,
) -> np.ndarray:
    if active_contexts is None:
        return np.ones(scenario.n_contexts, dtype=bool)
    active = np.asarray(active_contexts, dtype=bool)
    if active.shape != (scenario.n_contexts,):
        raise ValueError("active_contexts has the wrong shape")
    return active


def observed_target_and_components(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return transported target, deterministic responses, and row contexts.

    Each complete context block gains one final star row. Every deterministic
    response column is normalized separately inside every context block.
    """

    channel.validate(scenario)
    target = _validate_target(scenario, target_flat)
    target_rows: list[np.ndarray] = []
    component_rows: list[np.ndarray] = []
    context_rows: list[int] = []
    for c, (context, sl, rates) in enumerate(
        zip(
            scenario.contexts,
            scenario.context_slices,
            channel.retention_by_context,
            strict=True,
        )
    ):
        p = target[sl]
        incidence = scenario.incidence[sl]
        target_rows.append(rates * p)
        target_rows.append(np.asarray([1.0 - float(np.dot(rates, p))]))
        component_rows.append(rates[:, None] * incidence)
        star = 1.0 - np.sum(rates[:, None] * incidence, axis=0)
        component_rows.append(star[None, :])
        context_rows.extend([c] * (len(context.outcomes) + 1))
    return (
        np.concatenate(target_rows),
        np.vstack(component_rows),
        np.asarray(context_rows, dtype=int),
    )


def observed_target_and_affine(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return transported target and the affine fit ``q(x)=base+matrix@x``."""

    channel.validate(scenario)
    target = _validate_target(scenario, target_flat)
    target_rows: list[np.ndarray] = []
    base_rows: list[np.ndarray] = []
    matrix_rows: list[np.ndarray] = []
    context_rows: list[int] = []
    for c, (context, sl, rates) in enumerate(
        zip(
            scenario.contexts,
            scenario.context_slices,
            channel.retention_by_context,
            strict=True,
        )
    ):
        p = target[sl]
        base = scenario.affine_base[sl]
        matrix = scenario.affine_matrix[sl]
        target_rows.append(rates * p)
        target_rows.append(np.asarray([1.0 - float(np.dot(rates, p))]))
        base_rows.append(rates * base)
        matrix_rows.append(rates[:, None] * matrix)
        base_rows.append(np.asarray([1.0 - float(np.dot(rates, base))]))
        matrix_rows.append((-np.sum(rates[:, None] * matrix, axis=0))[None, :])
        context_rows.extend([c] * (len(context.outcomes) + 1))
    return (
        np.concatenate(target_rows),
        np.concatenate(base_rows),
        np.vstack(matrix_rows),
        np.asarray(context_rows, dtype=int),
    )


def weighted_kl(
    p: np.ndarray,
    q: np.ndarray,
    row_weights: np.ndarray,
) -> float:
    """Weighted KL sum with the convention ``0 log(0/q)=0``."""

    positive = (row_weights > 0.0) & (p > 0.0)
    if np.any(q[positive] <= 0.0):
        return math.inf
    return float(
        np.sum(row_weights[positive] * p[positive] * np.log(p[positive] / q[positive]))
    )


def solve_hidden(
    scenario: Scenario,
    *,
    target_flat: np.ndarray | None = None,
    channel: Channel | None = None,
    active_contexts: np.ndarray | None = None,
    initial_weights: np.ndarray | None = None,
    tolerance: float = 1.0e-12,
    max_iterations: int = 100_000,
) -> SolveResult:
    """KL projection using one weight per deterministic global assignment.

    The multiplicative update is the EM update for a finite mixture with known
    components. ``optimality_gap`` is the Frank--Wolfe/KKT gap in the same nats
    scale as the reported objective. It is therefore an a posteriori upper
    bound on primal suboptimality for this convex problem.
    """

    target = _validate_target(
        scenario, scenario.target_flat if target_flat is None else target_flat
    )
    active = _validate_active_mask(scenario, active_contexts)
    observation = identity_channel(scenario) if channel is None else channel
    p_obs, components, row_contexts = observed_target_and_components(
        scenario, target, observation
    )
    row_weights = scenario.context_weights[row_contexts] * active[row_contexts]
    weighted_mass = row_weights * p_obs
    active_mass = float(np.sum(weighted_mass))

    if initial_weights is None:
        hidden = np.full(scenario.n_assignments, 1.0 / scenario.n_assignments)
    else:
        hidden = np.asarray(initial_weights, dtype=float).copy()
        if hidden.shape != (scenario.n_assignments,):
            raise ValueError("initial_weights has the wrong shape")
        if np.any(~np.isfinite(hidden)):
            raise ValueError("initial_weights must be finite")
        if np.any(hidden < 0.0) or np.sum(hidden) <= 0.0:
            raise ValueError("initial_weights must be nonnegative with positive sum")
        # Keep all columns reachable under multiplicative updates.
        hidden = np.maximum(hidden, 1.0e-15)
        hidden /= np.sum(hidden)

    started = time.perf_counter()
    if active_mass == 0.0:
        q_obs = components @ hidden
        return SolveResult(
            formulation="hidden",
            divergence=0.0,
            runtime_seconds=time.perf_counter() - started,
            iterations=0,
            success=True,
            message="no weighted context mass",
            optimizer=hidden,
            observed_target=p_obs,
            observed_fit=q_obs,
            optimality_gap=0.0,
            certificate_kind="simplex Frank-Wolfe gap (nats)",
            constraint_violation=0.0,
        )

    normalized_counts = weighted_mass / active_mass
    positive = normalized_counts > 0.0
    previous_divergence = math.inf
    normalized_gap = math.inf
    q_obs = components @ hidden

    for iteration in range(1, max_iterations + 1):
        if np.any(q_obs[positive] <= 0.0):
            raise RuntimeError("hidden solver reached zero fitted mass on target support")
        score = components[positive].T @ (
            normalized_counts[positive] / q_obs[positive]
        )
        normalized_gap = max(0.0, float(np.max(score) - 1.0))
        divergence = weighted_kl(p_obs, q_obs, row_weights)
        if (
            normalized_gap <= tolerance
            and abs(previous_divergence - divergence)
            <= tolerance * max(1.0, abs(divergence))
        ):
            runtime = time.perf_counter() - started
            return SolveResult(
                formulation="hidden",
                divergence=divergence,
                runtime_seconds=runtime,
                iterations=iteration,
                success=True,
                message="EM/KKT convergence",
                optimizer=hidden,
                observed_target=p_obs,
                observed_fit=q_obs,
                optimality_gap=active_mass * normalized_gap,
                certificate_kind="simplex Frank-Wolfe gap (nats)",
                constraint_violation=abs(float(np.sum(hidden)) - 1.0),
            )
        updated = hidden * score
        total = float(np.sum(updated))
        if not math.isfinite(total) or total <= 0.0:
            raise RuntimeError("hidden EM update became degenerate")
        hidden = updated / total
        previous_divergence = divergence
        q_obs = components @ hidden

    runtime = time.perf_counter() - started
    divergence = weighted_kl(p_obs, q_obs, row_weights)
    return SolveResult(
        formulation="hidden",
        divergence=divergence,
        runtime_seconds=runtime,
        iterations=max_iterations,
        success=False,
        message=f"maximum iterations reached; normalized KKT gap={normalized_gap:.3e}",
        optimizer=hidden,
        observed_target=p_obs,
        observed_fit=q_obs,
        optimality_gap=active_mass * normalized_gap,
        certificate_kind="simplex Frank-Wolfe gap (nats)",
        constraint_violation=abs(float(np.sum(hidden)) - 1.0),
    )


def solve_facets(
    scenario: Scenario,
    *,
    target_flat: np.ndarray | None = None,
    channel: Channel | None = None,
    active_contexts: np.ndarray | None = None,
    target_reduced_hint: np.ndarray | None = None,
    initial_reduced: np.ndarray | None = None,
    facets: FacetRepresentation | None = None,
    tolerance: float = 1.0e-12,
    max_iterations: int = 4_000,
) -> SolveResult:
    """KL projection in reduced behavior coordinates with facet constraints.

    SLSQP supplies the candidate point. A formulation-independent
    Frank--Wolfe gap over the known reduced vertices then certifies convex
    optimality; unlike an unconstrained gradient norm, this certificate is
    meaningful at a boundary optimum.
    """

    target = _validate_target(
        scenario, scenario.target_flat if target_flat is None else target_flat
    )
    active = _validate_active_mask(scenario, active_contexts)
    observation = identity_channel(scenario) if channel is None else channel
    p_obs, base, matrix, row_contexts = observed_target_and_affine(
        scenario, target, observation
    )
    row_weights = scenario.context_weights[row_contexts] * active[row_contexts]
    polytope = (
        facet_representation(scenario.reduced_vertices)
        if facets is None
        else facets
    )

    if initial_reduced is not None:
        x0 = np.asarray(initial_reduced, dtype=float).copy()
    elif target_reduced_hint is not None and polytope.contains(
        np.asarray(target_reduced_hint, dtype=float), tolerance=1.0e-9
    ):
        x0 = np.asarray(target_reduced_hint, dtype=float).copy()
    else:
        x0 = np.mean(scenario.reduced_vertices, axis=0)
    if x0.shape != (scenario.reduced_dimension,):
        raise ValueError("initial reduced point has the wrong shape")
    if not polytope.contains(x0, tolerance=1.0e-7):
        x0 = np.mean(scenario.reduced_vertices, axis=0)

    preliminary_positive = (row_weights > 0.0) & (p_obs > 0.0)
    q0 = base + matrix @ x0
    if np.any(q0[preliminary_positive] <= 1.0e-14):
        x0 = np.mean(scenario.reduced_vertices, axis=0)

    started = time.perf_counter()
    if not np.any(active):
        q_obs = base + matrix @ x0
        return SolveResult(
            formulation="facets",
            divergence=0.0,
            runtime_seconds=time.perf_counter() - started,
            iterations=0,
            success=True,
            message="no retained contexts",
            optimizer=x0,
            observed_target=p_obs,
            observed_fit=q_obs,
            optimality_gap=0.0,
            certificate_kind="polytope Frank-Wolfe gap (nats)",
            constraint_violation=polytope.max_violation(x0),
        )

    positive = (row_weights > 0.0) & (p_obs > 0.0)

    def objective(x: np.ndarray) -> float:
        q = base + matrix @ x
        if np.any(q[positive] <= 0.0):
            return 1.0e100
        return weighted_kl(p_obs, q, row_weights)

    def gradient(x: np.ndarray) -> np.ndarray:
        q = base + matrix @ x
        safe_q = np.maximum(q[positive], 1.0e-300)
        coefficients = row_weights[positive] * p_obs[positive] / safe_q
        return -(matrix[positive].T @ coefficients)

    constraints = {
        "type": "ineq",
        "fun": lambda x: polytope.b - polytope.A @ x,
        "jac": lambda x: -polytope.A,
    }
    bounds = Bounds(polytope.lower_bounds, polytope.upper_bounds)
    result = minimize(
        objective,
        x0,
        jac=gradient,
        method="SLSQP",
        bounds=bounds,
        constraints=constraints,
        options={"ftol": tolerance, "maxiter": max_iterations, "disp": False},
    )
    x = np.asarray(result.x, dtype=float)
    q_obs = base + matrix @ x
    divergence = weighted_kl(p_obs, q_obs, row_weights)

    # If the numerical optimum is essentially zero, solve an exact linear
    # feasibility problem for q(x)=p on the weighted rows. This removes the
    # small stationarity artefact that SLSQP can leave on a flat zero-KL face.
    exact_fit_used = False
    if divergence <= 1.0e-10:
        equality_rows = row_weights > 0.0
        feasibility = linprog(
            c=np.zeros(scenario.reduced_dimension),
            A_ub=polytope.A,
            b_ub=polytope.b,
            A_eq=matrix[equality_rows],
            b_eq=p_obs[equality_rows] - base[equality_rows],
            bounds=list(
                zip(
                    polytope.lower_bounds,
                    polytope.upper_bounds,
                    strict=True,
                )
            ),
            method="highs",
        )
        if feasibility.success and feasibility.x is not None:
            x = np.asarray(feasibility.x, dtype=float)
            q_obs = base + matrix @ x
            divergence = weighted_kl(p_obs, q_obs, row_weights)
            exact_fit_used = True

    # The manuscript's 3-cycle target families are invariant under exchange of
    # C12 and C23. When SLSQP identifies the contextual facet
    # q12+q23+q13=2, polish the one-dimensional symmetric face. This does not
    # replace the generic solve: it is accepted only when the candidate already
    # lies on that face and the polished point does not increase the objective.
    symmetry_polished = False
    if (
        scenario.key == "three_cycle"
        and divergence > 1.0e-10
        and active[0] == active[1]
        and np.isclose(scenario.context_weights[0], scenario.context_weights[1])
        and np.allclose(
            target[scenario.context_slices[0]],
            target[scenario.context_slices[1]],
        )
        and np.allclose(
            observation.retention_by_context[0],
            observation.retention_by_context[1],
        )
        and abs(x[0] - x[1]) <= 1.0e-5
        and abs(float(np.sum(x)) - 2.0) <= 1.0e-5
    ):
        direction = np.asarray([1.0, 1.0, -2.0])

        def symmetric_face_point(q_value: float) -> np.ndarray:
            return np.asarray([q_value, q_value, 2.0 - 2.0 * q_value])

        def symmetric_face_objective(q_value: float) -> float:
            return objective(symmetric_face_point(q_value))

        def symmetric_face_derivative(q_value: float) -> float:
            return float(np.dot(gradient(symmetric_face_point(q_value)), direction))

        lower = 0.5 + 1.0e-12
        upper = 1.0 - 1.0e-12
        derivative_lower = symmetric_face_derivative(lower)
        derivative_upper = symmetric_face_derivative(upper)
        polish_success = False
        polished_q = float(x[0])
        if derivative_lower == 0.0:
            polished_q = lower
            polish_success = True
        elif derivative_upper == 0.0:
            polished_q = upper
            polish_success = True
        elif derivative_lower * derivative_upper < 0.0:
            polished_q = float(
                brentq(
                    symmetric_face_derivative,
                    lower,
                    upper,
                    xtol=5.0e-15,
                    rtol=1.0e-15,
                    maxiter=1_000,
                )
            )
            polish_success = True
        else:
            polish = minimize_scalar(
                symmetric_face_objective,
                bounds=(0.5, 1.0),
                method="bounded",
                options={"xatol": 1.0e-15, "maxiter": 1_000},
            )
            polished_q = float(polish.x)
            polish_success = bool(polish.success)

        candidate = symmetric_face_point(polished_q)
        candidate_divergence = objective(candidate)
        if (
            polish_success
            and polytope.contains(candidate, tolerance=1.0e-9)
            and candidate_divergence <= divergence + 1.0e-11
        ):
            x = candidate
            q_obs = base + matrix @ x
            divergence = candidate_divergence
            symmetry_polished = True

    runtime = time.perf_counter() - started
    violation = max(
        polytope.max_violation(x),
        float(np.max(polytope.lower_bounds - x)),
        float(np.max(x - polytope.upper_bounds)),
        0.0,
    )
    grad = gradient(x)
    vertex_linear_values = scenario.reduced_vertices @ grad
    fw_gap = max(0.0, float(np.dot(grad, x) - np.min(vertex_linear_values)))
    optimizer_success = bool(result.success or exact_fit_used)
    success = bool(
        optimizer_success
        and math.isfinite(divergence)
        and violation <= 1.0e-7
        and fw_gap <= 2.0e-7
    )
    message = str(result.message)
    if exact_fit_used:
        message += "; exact zero-KL feasibility refinement"
    if symmetry_polished:
        message += "; symmetric active-face polishing"
    if optimizer_success and not success:
        message += f"; post-check FW gap={fw_gap:.3e}, violation={violation:.3e}"
    return SolveResult(
        formulation="facets",
        divergence=divergence,
        runtime_seconds=runtime,
        iterations=int(getattr(result, "nit", 0)),
        success=success,
        message=message,
        optimizer=x,
        observed_target=p_obs,
        observed_fit=q_obs,
        optimality_gap=fw_gap,
        certificate_kind="polytope Frank-Wolfe gap (nats)",
        constraint_violation=violation,
    )


def solve_kl(
    scenario: Scenario,
    formulation: Formulation,
    **kwargs: object,
) -> SolveResult:
    if formulation == "hidden":
        return solve_hidden(scenario, **kwargs)
    if formulation == "facets":
        return solve_facets(scenario, **kwargs)
    raise ValueError("formulation must be 'hidden' or 'facets'")
