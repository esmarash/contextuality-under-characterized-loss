# Computational notes

## 1. Hidden-variable KL solver

Let `B` be the context-labelled observed component matrix after applying the
chosen erasure channel to every deterministic assignment. Let
`c_e = w_C p_e` be the weighted observed target mass and normalize the active
masses so that `sum_e c_e = 1`. Minimizing KL is equivalent to maximizing

\[
L(\lambda)=\sum_e c_e\log (B\lambda)_e
\]

on the simplex. The update

\[
\lambda_j^{\rm new}=\lambda_j
\sum_e c_e\frac{B_{ej}}{(B\lambda)_e}
\]

preserves normalization and is the ordinary finite-mixture EM update. The code
checks the KKT gap

\[
\max_j\sum_e c_e B_{ej}/(B\lambda)_e-1.
\]

This avoids a generic 512-variable constrained nonlinear solve for the magic
square while retaining the full assignment parameterization.

## 2. Facet solver

For each scenario, the reduced deterministic behaviors form a full-dimensional
small polytope. `scipy.spatial.ConvexHull` returns outward half-spaces, and
numerically duplicate equations caused by simplicial triangulation are removed
by converting Qhull normals to canonical small-integer equations whenever the
ratios are numerically unambiguous; a rounded-normal fallback is retained only
for non-rational numerical hulls. SLSQP minimizes the convex observed-data KL
objective using an analytic gradient and the resulting linear half-space
constraints. Every candidate is independently checked with the Frank--Wolfe
linearization gap over the known reduced vertices. If the candidate KL is
numerically zero, a HiGHS feasibility LP enforces the exact equations
`q(x)=p` on all weighted observed rows. For the symmetric three-cycle MNAR
family, a detected active contextual facet is additionally polished by a
one-dimensional root solve; the result is accepted only when it is feasible
and does not increase the objective.

The reduction is not presented as a generic projection of arbitrary data:

- in the three-cycle and magic square it relies on averaging within parity
  sectors and is used only with parity-sector-invariant targets and channels;
- in KCBS the ten marginal coordinates represent the full binary edge model.

## 3. Context-removal enumeration

For `m` contexts the driver evaluates all `2^m` masks, including the empty and
full covers. The original context weights are multiplied by the mask and are
not renormalized. Each row records both formulations, Contextual Fraction,
FMCI relative to the full design, and whether the retained empirical model has
an exact noncontextual extension.

A subset is labelled *minimal contextual* when it is contextual and every
one-context deletion is noncontextual. It is *maximal noncontextual* when it is
noncontextual and every one-context addition is contextual.

## 4. Contextual Fraction

The LP uses one nonnegative subprobability weight per global assignment and the
componentwise domination constraints `A b <= p`. For any nonempty retained
cover, summing the rows of one context implies `sum b <= 1` automatically.

## 5. Visibility families

The noise points are noncontextual and preserve the benchmark symmetries:

- three-cycle: uniform four-outcome edge distributions;
- KCBS: the qutrit maximally mixed point `r_i=1/3`, `t_i=0`;
- magic square: uniform eight-outcome context distributions.

The analytic contextuality thresholds are `1/3`, approximately
`0.5854101966`, and `2/3`, respectively.

## 6. Complexity interpretation

The hidden representation grows with the number of deterministic assignments,
which is exponential in the number of measurements in unconstrained binary
scenarios. A full H-representation can also have exponentially many facets and
facet enumeration itself can dominate the computation. The favorable facet
counts in this package come from deliberately small or symmetry-reduced
benchmarks and must not be extrapolated to large hypergraphs.

For larger instances, natural extensions are column generation for the hidden
formulation, cutting planes for violated inequalities, warm starts across
nearby channel parameters, and certified lower/upper bounds from restricted
column or constraint sets. These are not silently treated as exact in the
current outputs.

## 7. Numerical standards

- Probabilities and KL values use double precision and natural logarithms.
- Hidden EM stops at a default KKT tolerance of `1e-12`.
- SLSQP uses an objective tolerance of `1e-12`.
- Analytic tests permit errors of a few `1e-9`; the reference run records a
  maximum hidden-versus-facet gap below `1.0e-12`.
- Every output run records package versions and grid sizes.
