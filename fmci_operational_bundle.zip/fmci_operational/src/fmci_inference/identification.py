from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario

from .data import ObservedCounts, observed_probabilities


class IdentificationError(RuntimeError):
    """Raised when the declared observation model does not point-identify the target."""


@dataclass(frozen=True)
class ContextIdentification:
    context: str
    outcome_count: int
    tangent_rank: int
    tangent_dimension: int
    point_identified: bool
    zero_retention_cells: int
    minimum_positive_retention: float
    smallest_tangent_singular_value: float
    tangent_condition_number: float


@dataclass(frozen=True)
class IdentificationReport:
    contexts: tuple[ContextIdentification, ...]
    point_identified: bool
    strongly_positive: bool
    minimum_retention: float
    worst_condition_number: float


@dataclass(frozen=True)
class ContextMLE:
    probabilities: np.ndarray
    log_likelihood: float
    iterations: int
    converged: bool
    score_residual: float


@dataclass(frozen=True)
class LatentBehaviorFit:
    target_flat: np.ndarray
    contexts: tuple[ContextMLE, ...]
    identification: IdentificationReport
    log_likelihood: float
    converged: bool


def channel_tangent_jacobian(retention: np.ndarray) -> np.ndarray:
    """Jacobian of ``p -> (a*p, 1-a'p)`` in simplex coordinates.

    Coordinates are ``theta=(p_1,...,p_{m-1})`` with
    ``p_m=1-sum(theta)``.
    """

    a = np.asarray(retention, dtype=float)
    if a.ndim != 1 or a.size < 2:
        raise ValueError("retention must be a one-dimensional vector of length >=2")
    m = a.size
    jacobian = np.zeros((m + 1, m - 1), dtype=float)
    jacobian[: m - 1, :] = np.diag(a[: m - 1])
    jacobian[m - 1, :] = -a[m - 1]
    jacobian[m, :] = a[m - 1] - a[: m - 1]
    return jacobian


def identification_report(
    scenario: Scenario,
    channel: Channel,
    *,
    rank_tolerance: float = 1.0e-12,
) -> IdentificationReport:
    channel.validate(scenario)
    rows: list[ContextIdentification] = []
    for context, retention in zip(
        scenario.contexts, channel.retention_by_context, strict=True
    ):
        a = np.asarray(retention, dtype=float)
        jacobian = channel_tangent_jacobian(a)
        singular = np.linalg.svd(jacobian, compute_uv=False)
        rank = int(np.sum(singular > rank_tolerance))
        tangent_dimension = a.size - 1
        positive = a[a > 0]
        minimum_positive = float(np.min(positive)) if positive.size else 0.0
        smallest = float(singular[-1]) if singular.size else 0.0
        condition = (
            float(singular[0] / singular[-1])
            if singular.size and singular[-1] > rank_tolerance
            else math.inf
        )
        rows.append(
            ContextIdentification(
                context=context.name,
                outcome_count=int(a.size),
                tangent_rank=rank,
                tangent_dimension=tangent_dimension,
                point_identified=rank == tangent_dimension,
                zero_retention_cells=int(np.sum(a <= rank_tolerance)),
                minimum_positive_retention=minimum_positive,
                smallest_tangent_singular_value=smallest,
                tangent_condition_number=condition,
            )
        )
    return IdentificationReport(
        contexts=tuple(rows),
        point_identified=all(row.point_identified for row in rows),
        strongly_positive=all(
            np.all(np.asarray(block) > rank_tolerance)
            for block in channel.retention_by_context
        ),
        minimum_retention=float(
            min(float(np.min(block)) for block in channel.retention_by_context)
        ),
        worst_condition_number=float(max(row.tangent_condition_number for row in rows)),
    )


def _context_log_likelihood(
    counts: np.ndarray,
    probabilities: np.ndarray,
    retention: np.ndarray,
) -> float:
    p = np.asarray(probabilities, dtype=float)
    a = np.asarray(retention, dtype=float)
    detected = a * p
    star = 1.0 - float(np.dot(a, p))
    q = np.concatenate((detected, np.asarray([star])))
    positive = counts > 0
    if np.any(q[positive] <= 0):
        return -math.inf
    return float(np.sum(counts[positive] * np.log(q[positive])))


def fit_latent_context_em(
    counts: np.ndarray,
    retention: np.ndarray,
    *,
    initial: np.ndarray | None = None,
    tolerance: float = 1.0e-11,
    max_iterations: int = 100_000,
) -> ContextMLE:
    """Maximum likelihood for one context under a known erasure channel.

    The final count is the star count.  EM allocates each missing trial to a
    latent complete outcome in proportion to ``(1-a_i)p_i``.
    """

    values = np.asarray(counts, dtype=float)
    a = np.asarray(retention, dtype=float)
    if values.shape != (a.size + 1,):
        raise ValueError("counts and retention have incompatible shapes")
    if np.any(values < 0) or np.any(values != np.floor(values)):
        raise ValueError("counts must be nonnegative integers")
    if np.any(a < 0) or np.any(a > 1):
        raise ValueError("retention must lie in [0,1]")
    n = float(np.sum(values))
    if n <= 0:
        raise ValueError("at least one attempted trial is required")
    detected_counts = values[:-1]
    star_count = float(values[-1])
    if np.any((a <= 0) & (detected_counts > 0)):
        raise ValueError("positive detected count in a zero-retention cell")

    if initial is None:
        adjusted = (detected_counts + 0.5) / np.maximum(a, 1.0e-6)
        p = adjusted / np.sum(adjusted)
    else:
        p = np.asarray(initial, dtype=float).copy()
        if p.shape != a.shape or np.any(p < 0) or np.sum(p) <= 0:
            raise ValueError("invalid initial probability vector")
        p /= np.sum(p)
    p = np.maximum(p, 1.0e-15)
    p /= np.sum(p)

    previous_ll = _context_log_likelihood(values, p, a)
    converged = False
    iteration = 0
    for iteration in range(1, max_iterations + 1):
        missing_mass = (1.0 - a) * p
        star_probability = float(np.sum(missing_mass))
        if star_count > 0 and star_probability <= 0:
            raise ValueError("star counts are incompatible with unit retention")
        if star_count > 0:
            expected_missing = star_count * missing_mass / star_probability
        else:
            expected_missing = np.zeros_like(p)
        updated = detected_counts + expected_missing
        total = float(np.sum(updated))
        if total <= 0:
            # All attempts are missing under a completely uninformative channel.
            updated = p.copy()
            total = float(np.sum(updated))
        updated /= total
        updated = np.maximum(updated, 0.0)
        updated /= np.sum(updated)
        ll = _context_log_likelihood(values, updated, a)
        change = float(np.max(np.abs(updated - p)))
        ll_change = abs(ll - previous_ll)
        p = updated
        previous_ll = ll
        if change <= tolerance and ll_change <= tolerance * max(1.0, abs(ll)):
            converged = True
            break

    # The constrained score is constant across positive-probability cells at
    # an interior optimum.  Its spread is a useful numerical diagnostic.
    detected_q = np.maximum(a * p, 1.0e-300)
    star_q = max(1.0 - float(np.dot(a, p)), 1.0e-300)
    raw_score = detected_counts * a / detected_q - star_count * a / star_q
    positive_p = p > 1.0e-10
    score_residual = (
        float(np.max(raw_score[positive_p]) - np.min(raw_score[positive_p]))
        if np.sum(positive_p) >= 2
        else 0.0
    )
    return ContextMLE(
        probabilities=p,
        log_likelihood=previous_ll,
        iterations=iteration,
        converged=converged,
        score_residual=score_residual,
    )


def fit_latent_behavior(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    *,
    require_point_identified: bool = True,
    tolerance: float = 1.0e-11,
    max_iterations: int = 100_000,
) -> LatentBehaviorFit:
    counts.validate(scenario)
    channel.validate(scenario)
    report = identification_report(scenario, channel)
    if require_point_identified and not report.point_identified:
        bad = [row.context for row in report.contexts if not row.point_identified]
        raise IdentificationError(
            "the declared channel does not point-identify complete outcomes in "
            + ", ".join(bad)
        )
    fits: list[ContextMLE] = []
    for block, retention in zip(
        counts.counts_by_context, channel.retention_by_context, strict=True
    ):
        fits.append(
            fit_latent_context_em(
                block,
                retention,
                tolerance=tolerance,
                max_iterations=max_iterations,
            )
        )
    target = np.concatenate([fit.probabilities for fit in fits])
    return LatentBehaviorFit(
        target_flat=target,
        contexts=tuple(fits),
        identification=report,
        log_likelihood=float(sum(fit.log_likelihood for fit in fits)),
        converged=all(fit.converged for fit in fits),
    )


def context_fisher_information(
    probabilities: np.ndarray,
    retention: np.ndarray,
) -> np.ndarray:
    """Per-attempt Fisher information in simplex coordinates."""

    p = np.asarray(probabilities, dtype=float)
    a = np.asarray(retention, dtype=float)
    if p.shape != a.shape:
        raise ValueError("probabilities and retention must have the same shape")
    q = np.concatenate((a * p, np.asarray([1.0 - float(np.dot(a, p))])))
    jacobian = channel_tangent_jacobian(a)
    active = np.linalg.norm(jacobian, axis=1) > 1.0e-15
    if np.any(q[active] <= 0):
        raise IdentificationError(
            "Fisher information is nonregular because a varying observed cell has zero probability"
        )
    return jacobian[active].T @ ((1.0 / q[active])[:, None] * jacobian[active])


def asymptotic_latent_covariance(
    scenario: Scenario,
    fit: LatentBehaviorFit,
    channel: Channel,
    context_trials: np.ndarray,
) -> np.ndarray:
    """Block covariance of latent simplex coordinates conditional on context totals."""

    n_by_context = np.asarray(context_trials, dtype=int)
    if n_by_context.shape != (scenario.n_contexts,):
        raise ValueError("context_trials has the wrong shape")
    dimensions = [len(context.outcomes) - 1 for context in scenario.contexts]
    total_dimension = int(sum(dimensions))
    covariance = np.zeros((total_dimension, total_dimension), dtype=float)
    start = 0
    for context, context_fit, retention, n in zip(
        scenario.contexts,
        fit.contexts,
        channel.retention_by_context,
        n_by_context,
        strict=True,
    ):
        if n <= 0:
            raise IdentificationError(f"context {context.name} has no trials")
        information = context_fisher_information(
            context_fit.probabilities, retention
        )
        if np.linalg.matrix_rank(information) < information.shape[0]:
            raise IdentificationError(
                f"singular Fisher information in context {context.name}"
            )
        block = np.linalg.inv(information) / float(n)
        stop = start + block.shape[0]
        covariance[start:stop, start:stop] = block
        start = stop
    return covariance


def fitted_observed_probabilities(
    scenario: Scenario,
    fit: LatentBehaviorFit,
    channel: Channel,
) -> tuple[np.ndarray, ...]:
    return observed_probabilities(scenario, fit.target_flat, channel)
