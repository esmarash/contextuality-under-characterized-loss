from __future__ import annotations

import json

from fmci_benchmarks.experiments import run_all


def test_quick_end_to_end_run(tmp_path) -> None:
    headline = run_all(
        tmp_path,
        visibility_points=5,
        eta_points=5,
        alpha_points=5,
        runtime_repetitions=1,
    )
    assert headline["any_off_boundary_exact_hiding"] is False
    assert headline["maximum_hidden_facet_gap"] < 3.0e-9
    assert (tmp_path / "REPORT.md").is_file()
    assert (tmp_path / "SHA256SUMS").is_file()
    assert (tmp_path / "figures" / "eta_alpha_fmci.png").is_file()
    metadata = json.loads((tmp_path / "run_metadata.json").read_text())
    assert metadata["eta_points"] == 5
    assert isinstance(metadata["fmci_benchmarks_version"], str)
    assert metadata["scenario_metadata"]["magic_square"]["facets"] == 44
