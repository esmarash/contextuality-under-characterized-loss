from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from fmci_benchmarks.channels import three_cycle_eta_alpha_channel
from fmci_benchmarks.scenarios import get_scenario
from fmci_inference.data import simulate_calibration_counts, simulate_observed_counts
from fmci_inference.io import (
    calibration_to_frame,
    channel_to_frame,
    load_calibration_counts,
    load_channel,
    load_observed_counts,
    observed_counts_to_frame,
)
from fmci_inference.reporting import analyze_known_channel
from fmci_inference.testing import target_win_probability


def test_csv_round_trip_and_joint_report(tmp_path: Path) -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    rng = np.random.default_rng(812)
    counts = simulate_observed_counts(
        scenario, target, channel, 2500, rng, randomized_contexts=True
    ).counts
    calibration = simulate_calibration_counts(scenario, channel, 300, rng)
    counts_path = tmp_path / "counts.csv"
    channel_path = tmp_path / "channel.csv"
    calibration_path = tmp_path / "calibration.csv"
    observed_counts_to_frame(scenario, counts).to_csv(counts_path, index=False)
    channel_to_frame(scenario, channel).to_csv(channel_path, index=False)
    calibration_to_frame(scenario, calibration).to_csv(calibration_path, index=False)
    loaded_counts = load_observed_counts(counts_path, scenario)
    loaded_channel = load_channel(channel_path, scenario)
    loaded_calibration = load_calibration_counts(calibration_path, scenario)
    report = analyze_known_channel(
        scenario,
        loaded_counts,
        loaded_channel,
        calibration=loaded_calibration,
        alternative_win_rate=target_win_probability(scenario, target, channel),
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    assert report["status"] == "ok"
    assert report["contextuality_test"]["assumptions_verified"]
    assert report["fmci_analysis"]["fmci_scalar_reporting_recommended"]
    json.dumps(report)


def test_boundary_report_retains_kl_points_but_refuses_regular_ratio_inference() -> None:
    """Empirical simplex boundaries must not erase available point projections."""

    from fmci_benchmarks.channels import identity_channel
    from fmci_inference.data import ObservedCounts

    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(1.0)
    blocks: list[np.ndarray] = []
    for context_slice in scenario.context_slices:
        detected = np.rint(200 * target[context_slice]).astype(int)
        detected[0] += 200 - int(np.sum(detected))
        blocks.append(np.concatenate((detected, np.asarray([0], dtype=int))))
    report = analyze_known_channel(
        scenario,
        ObservedCounts(tuple(blocks)),
        identity_channel(scenario),
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    assert report["status"] == "nonregular-inference-unavailable"
    analysis = report["fmci_analysis"]
    assert analysis["full_divergence_nats"] > 0
    assert analysis["observed_divergence_nats"] > 0
    assert analysis["fmci_scalar_reporting_recommended"] is False
    assert analysis["delta_intervals"] is None
    assert analysis["regularity"]["classification"] == "nonregular/inference-unavailable"
