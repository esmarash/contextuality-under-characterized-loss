from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from fmci_benchmarks.channels import three_cycle_eta_alpha_channel
from fmci_benchmarks.scenarios import get_scenario
from fmci_inference.data import simulate_calibration_counts, simulate_observed_counts
from fmci_inference.io import calibration_to_frame, observed_counts_to_frame, outcome_label
from fmci_inference.sensitivity_cli import load_candidate_manifest, main


def _candidate_manifest(scenario, channels):
    rows = []
    for candidate_id, channel in enumerate(channels):
        for context, retention in zip(
            scenario.contexts, channel.retention_by_context, strict=True
        ):
            for outcome, value in zip(context.outcomes, retention, strict=True):
                rows.append(
                    {
                        "candidate_id": candidate_id,
                        "context": context.name,
                        "outcome": outcome_label(outcome),
                        "retention": float(value),
                        "parameter_eta": float(channel.parameters["eta"]),
                        "parameter_alpha": float(channel.parameters["alpha"]),
                    }
                )
    return pd.DataFrame(rows)


def test_candidate_manifest_and_cli(tmp_path: Path) -> None:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    true_channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    channels = (
        true_channel,
        three_cycle_eta_alpha_channel(scenario, 0.82, 0.7),
    )
    rng = np.random.default_rng(12345)
    counts = simulate_observed_counts(
        scenario, target, true_channel, 1200, rng, randomized_contexts=True
    ).counts
    calibration = simulate_calibration_counts(scenario, true_channel, 300, rng)
    counts_path = tmp_path / "counts.csv"
    calibration_path = tmp_path / "calibration.csv"
    candidates_path = tmp_path / "candidates.csv"
    observed_counts_to_frame(scenario, counts).to_csv(counts_path, index=False)
    calibration_to_frame(scenario, calibration).to_csv(calibration_path, index=False)
    _candidate_manifest(scenario, channels).to_csv(candidates_path, index=False)

    loaded = load_candidate_manifest(candidates_path, scenario)
    assert len(loaded) == 2
    assert loaded[0].parameters["eta"] == 0.8

    output = tmp_path / "sensitivity"
    main(
        [
            "--scenario",
            "three_cycle",
            "--counts",
            str(counts_path),
            "--calibration",
            str(calibration_path),
            "--candidates",
            str(candidates_path),
            "--output-dir",
            str(output),
            "--verify-randomized-contexts",
            "--verify-context-unpredictability",
            "--verify-independent-channel",
        ]
    )
    frame = pd.read_csv(output / "sensitivity_scan.csv")
    summary = json.loads((output / "sensitivity_summary.json").read_text())
    assert len(frame) == 2
    assert summary["candidate_count"] == 2
    assert summary["assumptions"]["randomized_contexts_verified"] is True
