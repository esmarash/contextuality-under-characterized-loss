# Mathematical specification

## Complete-data KL contextuality

For context weights `w_C`, target context distributions `p_C`, and a
noncontextual model induced by global-assignment weights `lambda`, the code
computes

\[
D_{\rm ctx}(p)=\min_{\lambda\in\Delta}\sum_C w_C
D_{\rm KL}(p_C\|A_C\lambda).
\]

The hidden-variable solver uses the full deterministic-assignment incidence
matrix `A`. It solves the convex mixture maximum-likelihood problem with a
multiplicative EM update and checks the simplex KKT gap.

## Observation channels

A whole-outcome erasure channel supplies one retention probability for every
context-outcome cell. Detected cells retain their label, and all rejected cells
inside a context are merged into a context-labelled star outcome. The same
channel is applied to the target and every deterministic component.

## Facet formulation

The inequality solver minimizes the same observed-data KL objective over a
small behavior vector `x` constrained by the facets of the convex hull of the
reduced deterministic behaviors.

- **3-cycle:** `x_C` is the anticorrelation probability in each edge. The
  reduction is exact for distributions and channels invariant within the two
  parity sectors.
- **KCBS:** the ten coordinates are the five singleton probabilities
  `r_i = Pr(P_i=1)` and five adjacent joint probabilities
  `t_i = Pr(P_i=1,P_{i+1}=1)`. This is the full binary marginal-polytope
  representation; the target lies on the exclusivity face `t_i=0`.
- **Magic square:** `x_C` is the probability of satisfying the target parity in
  each row or column. The reduction is exact for parity-sector-invariant
  distributions and channels. The hidden solver nevertheless retains all 512
  deterministic assignments.

The convex-hull facets are generated once with Qhull. Duplicate simplicial
facets are collapsed by canonicalizing the small rational normals to integer
half-spaces, with a rounded-normal fallback for future non-rational hulls. The
resulting counts are 4, 36, and 44.

## Contextual Fraction

The noncontextual fraction is computed by the LP

\[
\max_{b\ge0}\sum_g b_g\quad\text{s.t.}\quad Ab\le p,
\]

and `CF = 1 - NCF`.

## Benchmark targets

- Perfect anticorrelation in all three edges of the 3-cycle.
- Symmetric KCBS qutrit point with `Pr(P_i=1)=1/sqrt(5)` and adjacent
  exclusivity.
- Uniform target-parity distributions for the six Peres-Mermin contexts, with
  five positive parities and one negative parity.
