from __future__ import annotations

import hashlib
import json
import math
import platform
import sys
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Mapping

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import yaml

from fmci_benchmarks.channels import (
    Channel,
    identity_channel,
    mcar_channel,
    three_cycle_eta_alpha_channel,
)
from fmci_benchmarks.scenarios import get_scenario
from fmci_benchmarks.solvers import solve_hidden

from .data import simulate_calibration_counts, simulate_observed_counts
from .estimands import estimate_fmci
from .identification import identification_report
from .inference import parametric_bootstrap, regular_inference
from .sensitivity import (
    run_sensitivity_analysis,
    simultaneous_clopper_pearson_box,
    three_cycle_eta_alpha_candidates,
)
from .testing import (
    binomial_tail_pvalue,
    target_win_probability,
    transported_noncontextual_win_bound,
    witness_test,
)


def _require_success(result: Any) -> None:
    if not result.success:
        raise RuntimeError(f"solver failed: {result.message}")


def _population_values(scenario, target_flat: np.ndarray, channel: Channel) -> dict[str, float]:
    full = solve_hidden(scenario, target_flat=target_flat)
    observed = solve_hidden(scenario, target_flat=target_flat, channel=channel)
    _require_success(full)
    _require_success(observed)
    d_full = float(full.divergence)
    d_obs = float(observed.divergence)
    return {
        "full_divergence": d_full,
        "observed_divergence": d_obs,
        "absolute_loss": d_full - d_obs,
        "fmci": (1.0 - d_obs / d_full) if d_full > 0 else math.nan,
    }


def _contains(intervals: Iterable[tuple[float, float]], value: float) -> bool:
    return any(left <= value <= right for left, right in intervals)


def monte_carlo_inference(
    *,
    visibility: float,
    channel: Channel,
    sample_sizes: list[int],
    replicates: int,
    seed: int,
    label: str,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, float]]:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(visibility)
    truth = _population_values(scenario, target, channel)
    rng = np.random.default_rng(seed)
    raw_rows: list[dict[str, Any]] = []
    for n in sample_sizes:
        for replicate in range(replicates):
            counts = simulate_observed_counts(
                scenario,
                target,
                channel,
                n,
                rng,
                randomized_contexts=False,
            ).counts
            row: dict[str, Any] = {
                "regime": label,
                "visibility": visibility,
                "sample_size": n,
                "replicate": replicate,
                "true_full": truth["full_divergence"],
                "true_observed": truth["observed_divergence"],
                "true_absolute_loss": truth["absolute_loss"],
                "true_fmci": truth["fmci"],
            }
            try:
                estimate = estimate_fmci(scenario, counts, channel)
                row.update(
                    {
                        "estimated_full": estimate.full_divergence,
                        "estimated_observed": estimate.observed_divergence,
                        "estimated_absolute_loss": estimate.absolute_loss,
                        "estimated_fmci": estimate.fmci,
                        "fmci_reportable": estimate.fmci_reportable,
                    }
                )
                infer = regular_inference(scenario, counts, channel, estimate)
                row.update(
                    {
                        "regularity": infer.diagnostics.classification,
                        "denominator_z": infer.diagnostics.denominator_z_score,
                        "fieller_kind": infer.fieller.kind,
                        "fieller_bounded": infer.fieller.bounded,
                        "full_ci_cover": infer.full.lower
                        <= truth["full_divergence"]
                        <= infer.full.upper,
                        "observed_ci_cover": infer.observed.lower
                        <= truth["observed_divergence"]
                        <= infer.observed.upper,
                        "absolute_ci_cover": infer.absolute_loss.lower
                        <= truth["absolute_loss"]
                        <= infer.absolute_loss.upper,
                        "fmci_delta_ci_cover": (
                            bool(
                                infer.fmci_delta is not None
                                and infer.fmci_delta.lower
                                <= truth["fmci"]
                                <= infer.fmci_delta.upper
                            )
                            if np.isfinite(truth["fmci"])
                            else False
                        ),
                        "fmci_fieller_ci_cover": (
                            _contains(infer.fieller.fmci_intervals, truth["fmci"])
                            if np.isfinite(truth["fmci"])
                            else False
                        ),
                        "fmci_delta_width": (
                            infer.fmci_delta.upper - infer.fmci_delta.lower
                            if infer.fmci_delta is not None
                            else math.nan
                        ),
                        "fmci_fieller_hull_width": (
                            max(x[1] for x in infer.fieller.fmci_intervals)
                            - min(x[0] for x in infer.fieller.fmci_intervals)
                            if infer.fieller.fmci_intervals
                            else math.nan
                        ),
                    }
                )
            except Exception as exc:  # recorded, not silently discarded
                row.update(
                    {
                        "estimated_full": math.nan,
                        "estimated_observed": math.nan,
                        "estimated_absolute_loss": math.nan,
                        "estimated_fmci": math.nan,
                        "fmci_reportable": False,
                        "regularity": "failed",
                        "denominator_z": math.nan,
                        "fieller_kind": "failed",
                        "fieller_bounded": False,
                        "full_ci_cover": False,
                        "observed_ci_cover": False,
                        "absolute_ci_cover": False,
                        "fmci_delta_ci_cover": False,
                        "fmci_fieller_ci_cover": False,
                        "fmci_delta_width": math.nan,
                        "fmci_fieller_hull_width": math.nan,
                        "error": str(exc),
                    }
                )
            raw_rows.append(row)
    raw = pd.DataFrame(raw_rows)
    summaries: list[dict[str, Any]] = []
    for n, group in raw.groupby("sample_size", sort=True):
        valid = group[np.isfinite(group["estimated_full"])]
        finite_lambda = valid[np.isfinite(valid["estimated_fmci"])]
        summary: dict[str, Any] = {
            "regime": label,
            "visibility": visibility,
            "sample_size": int(n),
            "replicates": int(len(group)),
            "successful_replicates": int(len(valid)),
            "true_full": truth["full_divergence"],
            "true_observed": truth["observed_divergence"],
            "true_absolute_loss": truth["absolute_loss"],
            "true_fmci": truth["fmci"],
            "mean_full": float(valid["estimated_full"].mean()),
            "bias_full": float(valid["estimated_full"].mean() - truth["full_divergence"]),
            "rmse_full": float(
                np.sqrt(np.mean((valid["estimated_full"] - truth["full_divergence"]) ** 2))
            ),
            "mean_observed": float(valid["estimated_observed"].mean()),
            "bias_observed": float(
                valid["estimated_observed"].mean() - truth["observed_divergence"]
            ),
            "rmse_observed": float(
                np.sqrt(
                    np.mean(
                        (valid["estimated_observed"] - truth["observed_divergence"]) ** 2
                    )
                )
            ),
            "mean_absolute_loss": float(valid["estimated_absolute_loss"].mean()),
            "bias_absolute_loss": float(
                valid["estimated_absolute_loss"].mean() - truth["absolute_loss"]
            ),
            "rmse_absolute_loss": float(
                np.sqrt(
                    np.mean(
                        (valid["estimated_absolute_loss"] - truth["absolute_loss"]) ** 2
                    )
                )
            ),
            "mean_fmci": float(finite_lambda["estimated_fmci"].mean())
            if len(finite_lambda)
            else math.nan,
            "bias_fmci": float(finite_lambda["estimated_fmci"].mean() - truth["fmci"])
            if len(finite_lambda)
            else math.nan,
            "rmse_fmci": float(
                np.sqrt(np.mean((finite_lambda["estimated_fmci"] - truth["fmci"]) ** 2))
            )
            if len(finite_lambda)
            else math.nan,
            "full_delta_coverage": float(valid["full_ci_cover"].mean()),
            "observed_delta_coverage": float(valid["observed_ci_cover"].mean()),
            "absolute_delta_coverage": float(valid["absolute_ci_cover"].mean()),
            "fmci_delta_coverage": float(valid["fmci_delta_ci_cover"].mean()),
            "fmci_fieller_coverage": float(valid["fmci_fieller_ci_cover"].mean()),
            "fmci_reportable_fraction": float(valid["fmci_reportable"].mean()),
            "fieller_bounded_fraction": float(valid["fieller_bounded"].mean()),
            "regular_fraction": float((valid["regularity"] == "regular").mean()),
            "median_denominator_z": float(valid["denominator_z"].median()),
            "n_times_bias_full": float(n * (valid["estimated_full"].mean() - truth["full_divergence"])),
            "n_times_bias_observed": float(
                n * (valid["estimated_observed"].mean() - truth["observed_divergence"])
            ),
            "n_times_bias_fmci": float(
                n * (finite_lambda["estimated_fmci"].mean() - truth["fmci"])
            )
            if len(finite_lambda)
            else math.nan,
        }
        summaries.append(summary)
    summary = pd.DataFrame(summaries)
    if len(summary) >= 2 and np.all(summary["rmse_fmci"] > 0):
        slope = float(
            np.polyfit(np.log(summary["sample_size"]), np.log(summary["rmse_fmci"]), 1)[0]
        )
    else:
        slope = math.nan
    truth["rmse_fmci_loglog_slope"] = slope
    return raw, summary, truth


def pvalue_validation(
    *,
    channel: Channel,
    sample_sizes: list[int],
    replicates: int,
    seed: int,
) -> pd.DataFrame:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    null_bound = transported_noncontextual_win_bound(scenario, channel)
    alternative = target_win_probability(scenario, target, channel)
    rng = np.random.default_rng(seed)
    rows: list[dict[str, Any]] = []
    for n in sample_sizes:
        iid_null_counts = rng.binomial(n, null_bound, size=replicates)
        # A simple history-dependent null: after an unusually successful
        # prefix, the device lowers its next-trial win probability. Every
        # conditional probability remains at most the same null bound.
        adaptive_counts = np.zeros(replicates, dtype=int)
        for trial in range(n):
            conditional = np.where(
                adaptive_counts <= null_bound * trial,
                null_bound,
                0.5 * null_bound,
            )
            adaptive_counts += (rng.random(replicates) < conditional).astype(int)
        alt_counts = rng.binomial(n, alternative, size=replicates)
        # Vectorized exact upper tails.  Calling scipy.stats.binom separately
        # for every Monte Carlo draw is orders of magnitude slower and does
        # not change the calculation.
        iid_null_p = np.asarray(
            scipy.stats.binom.sf(iid_null_counts - 1, n, null_bound), dtype=float
        )
        adaptive_null_p = np.asarray(
            scipy.stats.binom.sf(adaptive_counts - 1, n, null_bound), dtype=float
        )
        alt_p = np.asarray(
            scipy.stats.binom.sf(alt_counts - 1, n, null_bound), dtype=float
        )
        for alpha in (0.10, 0.05, 0.01):
            rows.append(
                {
                    "sample_size": n,
                    "alpha": alpha,
                    "replicates": replicates,
                    "null_bound": null_bound,
                    "alternative_win_rate": alternative,
                    "iid_type_i_rejection_rate": float(np.mean(iid_null_p <= alpha)),
                    "adaptive_memory_type_i_rejection_rate": float(
                        np.mean(adaptive_null_p <= alpha)
                    ),
                    "power": float(np.mean(alt_p <= alpha)),
                    "median_iid_null_pvalue": float(np.median(iid_null_p)),
                    "median_adaptive_null_pvalue": float(np.median(adaptive_null_p)),
                    "median_alternative_pvalue": float(np.median(alt_p)),
                }
            )
    return pd.DataFrame(rows)


def calibration_coverage(
    *,
    true_channel: Channel,
    attempts_per_cell: int,
    confidence: float,
    replicates: int,
    seed: int,
) -> pd.DataFrame:
    scenario = get_scenario("three_cycle")
    rng = np.random.default_rng(seed)
    contains = []
    widths = []
    for _ in range(replicates):
        calibration = simulate_calibration_counts(
            scenario, true_channel, attempts_per_cell, rng
        )
        box = simultaneous_clopper_pearson_box(
            scenario, calibration, confidence=confidence
        )
        contains.append(box.contains(scenario, true_channel))
        widths.extend(
            (upper - lower).tolist()
            for lower, upper in zip(
                box.lower_by_context, box.upper_by_context, strict=True
            )
        )
    flattened_widths = np.concatenate([np.asarray(x) for x in widths])
    return pd.DataFrame(
        [
            {
                "replicates": replicates,
                "attempts_per_cell": attempts_per_cell,
                "nominal_familywise_confidence": confidence,
                "empirical_familywise_coverage": float(np.mean(contains)),
                "mean_cell_interval_width": float(np.mean(flattened_widths)),
                "max_cell_interval_width": float(np.max(flattened_widths)),
            }
        ]
    )


def sensitivity_demo(
    *,
    output: Path,
    seed: int,
    eta_points: int,
    alpha_points: int,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    true_eta = 0.80
    true_alpha = 0.70
    true_channel = three_cycle_eta_alpha_channel(scenario, true_eta, true_alpha)
    rng = np.random.default_rng(seed)
    counts = simulate_observed_counts(
        scenario,
        target,
        true_channel,
        6000,
        rng,
        randomized_contexts=True,
    ).counts
    calibration = simulate_calibration_counts(scenario, true_channel, 800, rng)
    calibration_box = simultaneous_clopper_pearson_box(
        scenario, calibration, confidence=0.975
    )
    eta_values = np.unique(
        np.concatenate((np.linspace(0.65, 0.90, eta_points), np.asarray([true_eta])))
    )
    alpha_values = np.unique(
        np.concatenate((np.linspace(0.35, 1.00, alpha_points), np.asarray([true_alpha])))
    )
    candidates = three_cycle_eta_alpha_candidates(
        scenario, eta_values=eta_values, alpha_values=alpha_values
    )
    envelope = run_sensitivity_analysis(
        scenario,
        counts,
        candidates,
        calibration_box=calibration_box,
        conditional_confidence=0.975,
        fmci_tipping_threshold=0.4,
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    rows: list[dict[str, Any]] = []
    for record in envelope.records:
        row = dict(record.parameters)
        row.update(
            {
                key: value
                for key, value in asdict(record).items()
                if key != "parameters"
            }
        )
        rows.append(row)
    frame = pd.DataFrame(rows)
    compatible = frame[frame["calibration_compatible"] & np.isfinite(frame["fmci"])]
    summary = {
        "true_eta": true_eta,
        "true_alpha": true_alpha,
        "experimental_trials": counts.total_trials,
        "calibration_attempts_per_cell": 800,
        "candidate_count": len(frame),
        "calibration_compatible_count": envelope.compatible_records,
        "point_fmci_range": list(envelope.point_fmci_range),
        "union_fmci_interval": list(envelope.union_fmci_interval),
        "full_divergence_range": list(envelope.full_divergence_range),
        "observed_divergence_range": list(envelope.observed_divergence_range),
        "pvalue_range": list(envelope.pvalue_range),
        "conservative_witness_pvalue": envelope.conservative_witness_pvalue,
        "calibration_adjusted_witness_pvalue": envelope.calibration_adjusted_witness_pvalue,
        "combined_coverage_lower_bound": envelope.combined_coverage_lower_bound,
        "tipping_candidate_count": len(envelope.tipping_parameters),
        "true_channel_inside_calibration_box": calibration_box.contains(
            scenario, true_channel
        ),
        "true_parameter_represented_in_candidate_set": bool(
            np.any(
                np.isclose(frame["eta"].to_numpy(float), true_eta)
                & np.isclose(frame["alpha"].to_numpy(float), true_alpha)
            )
        ),
    }
    if len(compatible):
        fig = plt.figure(figsize=(7.2, 4.8))
        ax = fig.add_subplot(111)
        for eta, group in compatible.groupby("eta"):
            group = group.sort_values("alpha")
            ax.plot(group["alpha"], group["fmci"], marker="o", markersize=2.5, label=f"eta={eta:.3f}")
        ax.axhline(0.4, linestyle="--", linewidth=1.0, label="tipping threshold")
        ax.set_xlabel("MNAR bias parameter alpha")
        ax.set_ylabel("FMCI")
        ax.set_title("Calibration-compatible FMCI sensitivity paths")
        if compatible["eta"].nunique() <= 8:
            ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(output / "figures" / "sensitivity_fmci_paths.pdf")
        fig.savefig(output / "figures" / "sensitivity_fmci_paths.png", dpi=180)
        plt.close(fig)

        fig = plt.figure(figsize=(7.2, 4.8))
        ax = fig.add_subplot(111)
        pvalues = np.maximum(compatible["witness_pvalue"].to_numpy(float), 1e-300)
        scatter = ax.scatter(compatible["fmci"], -np.log10(pvalues), s=16)
        ax.set_xlabel("FMCI")
        ax.set_ylabel("-log10 conditional contextuality p-value")
        ax.set_title("Two-axis reporting across the sensitivity family")
        fig.tight_layout()
        fig.savefig(output / "figures" / "joint_evidence_sensitivity.pdf")
        fig.savefig(output / "figures" / "joint_evidence_sensitivity.png", dpi=180)
        plt.close(fig)
    return frame, summary


def identification_scan(output: Path) -> pd.DataFrame:
    scenario = get_scenario("three_cycle")
    rows: list[dict[str, Any]] = []
    for alpha in np.concatenate(([0.0], np.geomspace(1e-4, 1.0, 121))):
        channel = three_cycle_eta_alpha_channel(scenario, 0.8, float(alpha))
        report = identification_report(scenario, channel)
        rows.append(
            {
                "alpha": float(alpha),
                "point_identified": report.point_identified,
                "minimum_retention": report.minimum_retention,
                "worst_condition_number": report.worst_condition_number,
            }
        )
    frame = pd.DataFrame(rows)
    positive = frame[(frame["alpha"] > 0) & np.isfinite(frame["worst_condition_number"])]
    fig = plt.figure(figsize=(7.2, 4.8))
    ax = fig.add_subplot(111)
    ax.loglog(positive["alpha"], positive["worst_condition_number"])
    ax.set_xlabel("alpha")
    ax.set_ylabel("worst tangent-map condition number")
    ax.set_title("Ill-conditioning as the MNAR family approaches non-identification")
    fig.tight_layout()
    fig.savefig(output / "figures" / "identification_conditioning.pdf")
    fig.savefig(output / "figures" / "identification_conditioning.png", dpi=180)
    plt.close(fig)
    return frame


def bootstrap_demo(output: Path, seed: int, replicates: int) -> dict[str, Any]:
    scenario = get_scenario("three_cycle")
    target, _ = scenario.target_at_visibility(0.75)
    channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    rng = np.random.default_rng(seed)
    counts = simulate_observed_counts(scenario, target, channel, 3000, rng).counts
    estimate = estimate_fmci(scenario, counts, channel)
    inference = regular_inference(scenario, counts, channel, estimate)
    bootstrap = parametric_bootstrap(
        scenario,
        counts,
        channel,
        estimate,
        replicates=replicates,
        seed=seed + 1,
    )
    values = bootstrap.replicate_values
    frame = pd.DataFrame(
        values,
        columns=["full_divergence", "observed_divergence", "absolute_loss", "fmci"],
    )
    frame.to_csv(output / "bootstrap_replicates.csv", index=False)
    fig = plt.figure(figsize=(7.2, 4.8))
    ax = fig.add_subplot(111)
    ax.hist(frame["fmci"].dropna(), bins=35)
    ax.axvline(estimate.fmci, linestyle="--", linewidth=1.2, label="plug-in estimate")
    ax.set_xlabel("bootstrap FMCI")
    ax.set_ylabel("replicates")
    ax.set_title("Regular-regime conditional parametric bootstrap")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "figures" / "bootstrap_fmci_regular.pdf")
    fig.savefig(output / "figures" / "bootstrap_fmci_regular.png", dpi=180)
    plt.close(fig)
    return {
        "estimate": {
            "full": estimate.full_divergence,
            "observed": estimate.observed_divergence,
            "absolute_loss": estimate.absolute_loss,
            "fmci": estimate.fmci,
        },
        "regularity": asdict(inference.diagnostics),
        "delta_fmci_interval": (
            [inference.fmci_delta.lower, inference.fmci_delta.upper]
            if inference.fmci_delta is not None
            else None
        ),
        "fieller_fmci_intervals": [list(x) for x in inference.fieller.fmci_intervals],
        "bootstrap": {
            key: value
            for key, value in asdict(bootstrap).items()
            if key != "replicate_values"
        },
    }


def _plot_mc_summaries(summary: pd.DataFrame, output: Path) -> None:
    fig = plt.figure(figsize=(7.2, 4.8))
    ax = fig.add_subplot(111)
    for regime, group in summary.groupby("regime"):
        ax.loglog(group["sample_size"], group["rmse_fmci"], marker="o", label=regime)
    ax.set_xlabel("attempted trials")
    ax.set_ylabel("FMCI root mean squared error")
    ax.set_title("Finite-sample FMCI error and the regular root-N regime")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "figures" / "fmci_rmse_scaling.pdf")
    fig.savefig(output / "figures" / "fmci_rmse_scaling.png", dpi=180)
    plt.close(fig)

    fig = plt.figure(figsize=(7.2, 4.8))
    ax = fig.add_subplot(111)
    for regime, group in summary.groupby("regime"):
        ax.plot(group["sample_size"], group["fmci_delta_coverage"], marker="o", label=f"delta: {regime}")
        ax.plot(group["sample_size"], group["fmci_fieller_coverage"], marker="s", label=f"Fieller: {regime}")
    ax.axhline(0.95, linestyle="--", linewidth=1.0, label="nominal 0.95")
    ax.set_xscale("log")
    ax.set_ylim(0.0, 1.02)
    ax.set_xlabel("attempted trials")
    ax.set_ylabel("empirical coverage")
    ax.set_title("FMCI interval coverage")
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(output / "figures" / "fmci_interval_coverage.pdf")
    fig.savefig(output / "figures" / "fmci_interval_coverage.png", dpi=180)
    plt.close(fig)

    fig = plt.figure(figsize=(7.2, 4.8))
    ax = fig.add_subplot(111)
    for regime, group in summary.groupby("regime"):
        ax.plot(group["sample_size"], group["fieller_bounded_fraction"], marker="o", label=regime)
    ax.set_xscale("log")
    ax.set_ylim(0.0, 1.02)
    ax.set_xlabel("attempted trials")
    ax.set_ylabel("fraction with bounded Fieller set")
    ax.set_title("Weak-denominator diagnostic")
    ax.legend()
    fig.tight_layout()
    fig.savefig(output / "figures" / "fieller_reportability.pdf")
    fig.savefig(output / "figures" / "fieller_reportability.png", dpi=180)
    plt.close(fig)


def _write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True, default=float) + "\n")


def _write_checksums(root: Path) -> None:
    lines: list[str] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        lines.append(f"{digest}  {path.relative_to(root)}")
    (root / "SHA256SUMS").write_text("\n".join(lines) + "\n")


def run_operational_suite(config: Mapping[str, Any], output_dir: Path) -> dict[str, Any]:
    output = Path(output_dir)
    (output / "figures").mkdir(parents=True, exist_ok=True)
    seed = int(config.get("seed", 20260713))
    regular_reps = int(config.get("regular_replicates", 300))
    near_reps = int(config.get("near_boundary_replicates", 300))
    bootstrap_reps = int(config.get("bootstrap_replicates", 399))
    pvalue_reps = int(config.get("pvalue_replicates", 10000))
    calibration_reps = int(config.get("calibration_replicates", 1000))

    scenario = get_scenario("three_cycle")
    regular_channel = three_cycle_eta_alpha_channel(scenario, 0.8, 0.7)
    regular_raw, regular_summary, regular_truth = monte_carlo_inference(
        visibility=0.75,
        channel=regular_channel,
        sample_sizes=list(config.get("regular_sample_sizes", [300, 1000, 3000, 10000])),
        replicates=regular_reps,
        seed=seed,
        label="regular alternative",
    )
    near_raw, near_summary, near_truth = monte_carlo_inference(
        visibility=0.36,
        channel=regular_channel,
        sample_sizes=list(config.get("near_boundary_sample_sizes", [1000, 3000, 10000])),
        replicates=near_reps,
        seed=seed + 1,
        label="near contextual boundary",
    )
    raw = pd.concat((regular_raw, near_raw), ignore_index=True)
    summary = pd.concat((regular_summary, near_summary), ignore_index=True)
    raw.to_csv(output / "finite_sample_replicates.csv", index=False)
    summary.to_csv(output / "finite_sample_summary.csv", index=False)
    _plot_mc_summaries(summary, output)

    pvalues = pvalue_validation(
        channel=regular_channel,
        sample_sizes=list(config.get("pvalue_sample_sizes", [100, 500, 2000])),
        replicates=pvalue_reps,
        seed=seed + 2,
    )
    pvalues.to_csv(output / "pvalue_validation.csv", index=False)

    calibration = calibration_coverage(
        true_channel=regular_channel,
        attempts_per_cell=int(config.get("calibration_attempts_per_cell", 500)),
        confidence=0.975,
        replicates=calibration_reps,
        seed=seed + 3,
    )
    calibration.to_csv(output / "calibration_coverage.csv", index=False)

    sensitivity_frame, sensitivity_summary = sensitivity_demo(
        output=output,
        seed=seed + 4,
        eta_points=int(config.get("sensitivity_eta_points", 21)),
        alpha_points=int(config.get("sensitivity_alpha_points", 31)),
    )
    sensitivity_frame.to_csv(output / "sensitivity_scan.csv", index=False)

    identification = identification_scan(output)
    identification.to_csv(output / "identification_scan.csv", index=False)

    bootstrap = bootstrap_demo(output, seed + 5, bootstrap_reps)
    _write_json(output / "bootstrap_summary.json", bootstrap)

    # One explicit joint report on independently generated randomized-context data.
    target, _ = scenario.target_at_visibility(0.75)
    rng = np.random.default_rng(seed + 6)
    joint_counts = simulate_observed_counts(
        scenario,
        target,
        regular_channel,
        5000,
        rng,
        randomized_contexts=True,
    ).counts
    joint_estimate = estimate_fmci(scenario, joint_counts, regular_channel)
    joint_inference = regular_inference(
        scenario, joint_counts, regular_channel, joint_estimate
    )
    # The alternative is fixed from the pre-declared benchmark target, not
    # learned from the tested data.
    alternative = target_win_probability(scenario, target, regular_channel)
    joint_test = witness_test(
        scenario,
        joint_counts,
        regular_channel,
        alternative_win_rate=alternative,
        randomized_contexts_verified=True,
        context_unpredictability_verified=True,
        channel_independently_fixed=True,
        score_prespecified=True,
    )
    joint_report = {
        "attempted_trials": joint_counts.total_trials,
        "channel": dict(regular_channel.parameters),
        "fmci": joint_estimate.fmci,
        "full_divergence_nats": joint_estimate.full_divergence,
        "observed_divergence_nats": joint_estimate.observed_divergence,
        "absolute_loss_nats": joint_estimate.absolute_loss,
        "delta_fmci_interval": (
            [joint_inference.fmci_delta.lower, joint_inference.fmci_delta.upper]
            if joint_inference.fmci_delta is not None
            else None
        ),
        "fieller_fmci_intervals": [
            list(interval) for interval in joint_inference.fieller.fmci_intervals
        ],
        "regularity": asdict(joint_inference.diagnostics),
        "contextuality_test": asdict(joint_test),
        "interpretation": (
            "The p-value addresses rejection of the transported noncontextual null; "
            "the FMCI interval addresses conditional information attenuation. They are "
            "reported together and are not multiplied or converted into one scalar."
        ),
    }
    _write_json(output / "joint_reporting_example.json", joint_report)

    headline = {
        "regular_truth": regular_truth,
        "near_boundary_truth": near_truth,
        "regular_rmse_slope": regular_truth["rmse_fmci_loglog_slope"],
        "near_boundary_rmse_slope": near_truth["rmse_fmci_loglog_slope"],
        "minimum_regular_fieller_coverage": float(regular_summary["fmci_fieller_coverage"].min()),
        "minimum_regular_delta_coverage": float(regular_summary["fmci_delta_coverage"].min()),
        "near_boundary_bounded_fieller_fraction_at_smallest_n": float(
            near_summary.sort_values("sample_size").iloc[0]["fieller_bounded_fraction"]
        ),
        "max_type_i_rate_minus_level": float(
            max(
                np.max(pvalues["iid_type_i_rejection_rate"] - pvalues["alpha"]),
                np.max(
                    pvalues["adaptive_memory_type_i_rejection_rate"]
                    - pvalues["alpha"]
                ),
            )
        ),
        "max_type_i_excess_above_level": float(
            max(
                0.0,
                np.max(pvalues["iid_type_i_rejection_rate"] - pvalues["alpha"]),
                np.max(
                    pvalues["adaptive_memory_type_i_rejection_rate"]
                    - pvalues["alpha"]
                ),
            )
        ),
        "minimum_regular_success_fraction": float(
            np.min(regular_summary["successful_replicates"] / regular_summary["replicates"])
        ),
        "calibration_empirical_coverage": float(
            calibration.iloc[0]["empirical_familywise_coverage"]
        ),
        "sensitivity": sensitivity_summary,
        "joint_report": joint_report,
    }
    _write_json(output / "headline_results.json", headline)
    metadata = {
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pandas": pd.__version__,
        "config": dict(config),
    }
    _write_json(output / "run_metadata.json", metadata)
    _write_report(output, headline, summary, pvalues, calibration)
    _write_checksums(output)
    return headline


def _write_report(
    output: Path,
    headline: dict[str, Any],
    finite: pd.DataFrame,
    pvalues: pd.DataFrame,
    calibration: pd.DataFrame,
) -> None:
    regular = finite[finite["regime"] == "regular alternative"]
    near = finite[finite["regime"] == "near contextual boundary"]
    sensitivity = headline["sensitivity"]
    joint = headline["joint_report"]
    lines = [
        "# Operational and finite-sample validation report",
        "",
        "## Scope",
        "",
        "This package separates three inferential tasks: estimating latent complete behavior under a declared channel, quantifying FMCI in the regular identified regime, and testing a pre-specified contextuality game with a finite-sample p-value. Unknown MNAR mechanisms are handled by a declared sensitivity family and a union interval rather than by a single unidentified point estimate.",
        "",
        "## Regular alternative",
        "",
        f"The fitted log-log RMSE slope for FMCI is {headline['regular_rmse_slope']:.3f}; a root-N regime corresponds to -0.5.",
        f"Across the evaluated sample sizes, among replications for which the smooth calculation completed, delta-method FMCI coverage ranged from {regular['fmci_delta_coverage'].min():.3f} to {regular['fmci_delta_coverage'].max():.3f}, and Fieller coverage ranged from {regular['fmci_fieller_coverage'].min():.3f} to {regular['fmci_fieller_coverage'].max():.3f}.",
        f"The minimum successful smooth-calculation fraction was {headline.get('minimum_regular_success_fraction', float('nan')):.3f}. Individual KL delta intervals showed finite-sample coverage as low as {min(regular['full_delta_coverage'].min(), regular['observed_delta_coverage'].min(), regular['absolute_delta_coverage'].min()):.3f}; these results are retained rather than described as uniformly accurate small-sample intervals.",
        "",
        "## Near-boundary behavior",
        "",
        f"At the smallest near-boundary sample size, only {headline['near_boundary_bounded_fieller_fraction_at_smallest_n']:.3f} of replications produced a bounded Fieller set. This is the intended diagnostic: an FMCI ratio should not be reported as a stable scalar when the full contextual divergence is weakly separated from zero.",
        "",
        "## Bias",
        "",
        "The output table reports N times the bias separately for full divergence, observed divergence, and FMCI. The coefficients vary across visibility, sample size, and estimand; the simulations therefore do not support a universal d/(2N) correction for the projected KL or its ratio.",
        "",
        "## Contextuality p-values",
        "",
        f"No evaluated type-I rejection rate exceeded its nominal level; the maximum excess above level was {headline.get('max_type_i_excess_above_level', max(0.0, headline['max_type_i_rate_minus_level'])):.4f} (the largest signed difference was {headline['max_type_i_rate_minus_level']:.4f}). The binary-game tail bound is conditional on randomized, unpredictable context choices and on the declared transported noncontextual null.",
        "",
        "## Calibration and MNAR sensitivity",
        "",
        f"The simultaneous calibration box had empirical familywise coverage {calibration.iloc[0]['empirical_familywise_coverage']:.3f} at nominal level {calibration.iloc[0]['nominal_familywise_confidence']:.3f}.",
        f"The calibrated sensitivity scan retained {sensitivity['calibration_compatible_count']} of {sensitivity['candidate_count']} channel candidates. Its point FMCI range was {sensitivity['point_fmci_range']}; the union interval was {sensitivity['union_fmci_interval']}. The nominal Bonferroni combined-coverage lower bound is {sensitivity['combined_coverage_lower_bound']:.3f} provided the fixed-channel intervals attain their stated conditional coverage, the declared family contains the true mechanism, and the computational grid covers it.",
        "",
        "## Joint reporting example",
        "",
        f"FMCI = {joint['fmci']:.6f}; Fieller set = {joint['fieller_fmci_intervals']}; memory-robust win/lose p-value = {joint['contextuality_test']['memory_robust_winlose_pvalue']:.3e}.",
        "",
        "The p-value and FMCI answer different questions. They are displayed side by side and are not combined arithmetically.",
        "",
        "## Files",
        "",
        "- `finite_sample_replicates.csv`: replicate-level estimates and diagnostics.",
        "- `finite_sample_summary.csv`: bias, RMSE, coverage, and reportability by regime and sample size.",
        "- `pvalue_validation.csv`: type-I error and power for the binary contextuality game.",
        "- `calibration_coverage.csv`: simultaneous detector-calibration coverage.",
        "- `sensitivity_scan.csv`: candidate-level MNAR analysis.",
        "- `joint_reporting_example.json`: recommended two-axis experimental report.",
        "- `bootstrap_summary.json`: regular-regime conditional bootstrap only.",
        "- `identification_scan.csv`: rank and conditioning near the positivity boundary.",
    ]
    (output / "REPORT.md").write_text("\n".join(lines) + "\n")


def load_config(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text())
    if payload is None:
        return {}
    if not isinstance(payload, dict):
        raise ValueError("configuration must be a mapping")
    return payload
