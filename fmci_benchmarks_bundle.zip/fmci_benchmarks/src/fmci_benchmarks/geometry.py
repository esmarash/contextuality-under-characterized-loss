from __future__ import annotations

from dataclasses import dataclass
import time

import numpy as np
from scipy.spatial import ConvexHull


@dataclass(frozen=True)
class FacetRepresentation:
    """Half-space representation A x <= b."""

    A: np.ndarray
    b: np.ndarray
    lower_bounds: np.ndarray
    upper_bounds: np.ndarray
    n_vertices: int
    generation_seconds: float

    @property
    def n_facets(self) -> int:
        return int(self.A.shape[0])

    @property
    def dimension(self) -> int:
        return int(self.A.shape[1])

    def max_violation(self, x: np.ndarray) -> float:
        return float(max(0.0, np.max(self.A @ x - self.b)))

    def contains(self, x: np.ndarray, tolerance: float = 1.0e-9) -> bool:
        return bool(
            self.max_violation(x) <= tolerance
            and np.all(x >= self.lower_bounds - tolerance)
            and np.all(x <= self.upper_bounds + tolerance)
        )


def _canonical_equation(
    equation: np.ndarray,
    *,
    integer_tolerance: float,
    fallback_decimals: int,
) -> np.ndarray:
    """Convert a normalized Qhull equation to a canonical exact-looking row.

    All benchmark vertices are integral and every returned facet has rational
    coefficients with small integer ratios. Dividing by the smallest nonzero
    absolute coefficient therefore recovers an integer equation exactly to
    floating-point precision. A rounded normalized fallback remains available
    for future scenarios that do not have this property.
    """

    nonzero = np.abs(equation) > integer_tolerance
    if not np.any(nonzero):
        raise ValueError("degenerate zero facet equation")
    scale = float(np.min(np.abs(equation[nonzero])))
    scaled = equation / scale
    integer = np.rint(scaled)
    if np.max(np.abs(scaled - integer)) <= integer_tolerance:
        return integer.astype(float)
    return np.round(equation, decimals=fallback_decimals)


def facet_representation(
    vertices: np.ndarray,
    *,
    integer_tolerance: float = 1.0e-8,
    fallback_decimals: int = 12,
) -> FacetRepresentation:
    """Compute and deduplicate facets of a full-dimensional small polytope."""

    vertices = np.asarray(vertices, dtype=float)
    if vertices.ndim != 2:
        raise ValueError("vertices must be a two-dimensional array")
    if np.linalg.matrix_rank(vertices - np.mean(vertices, axis=0)) < vertices.shape[1]:
        raise ValueError("reduced vertices are not full-dimensional")
    started = time.perf_counter()
    hull = ConvexHull(vertices)
    canonical = np.vstack(
        [
            _canonical_equation(
                equation,
                integer_tolerance=integer_tolerance,
                fallback_decimals=fallback_decimals,
            )
            for equation in hull.equations
        ]
    )
    equations = np.unique(canonical, axis=0)
    A = equations[:, :-1]
    b = -equations[:, -1]
    return FacetRepresentation(
        A=A,
        b=b,
        lower_bounds=np.min(vertices, axis=0),
        upper_bounds=np.max(vertices, axis=0),
        n_vertices=int(vertices.shape[0]),
        generation_seconds=time.perf_counter() - started,
    )
