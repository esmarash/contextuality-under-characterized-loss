# Validation record

Reference run generated on 2026-07-13 with Python 3.13, NumPy 2.3.5, SciPy
1.17.0, pandas 2.2.3, Matplotlib 3.10.8, PyYAML 6.0.3, and pytest 9.0.2.

## Commands exercised

```bash
python -m pip install -e . --no-deps
PYTHONPATH=src pytest -q
PYTHONPATH=src python -m compileall -q src tests scripts
fmci-benchmarks --quick --output /tmp/fmci_cli_smoke
PYTHONPATH=src python -m fmci_benchmarks.cli \
  --output outputs \
  --visibility-points 101 \
  --eta-points 51 \
  --alpha-points 51 \
  --runtime-repetitions 25
```

## Outcomes

- 9 tests passed, including an end-to-end report-generation test.
- Maximum hidden-versus-facet KL gap: `9.996712659054996e-13` nats.
- Maximum analytic KL gap: `9.044917592682111e-13` nats.
- Maximum recorded hidden optimality gap: `9.99866855977416e-13` nats.
- Maximum recorded facet optimality gap: `1.45328193923433e-13` nats.
- All 101 proper subcovers across the three benchmarks extend
  noncontextually; only the three full covers are contextual.
- The 2,601-point `(eta, alpha)` scan has no off-boundary exact-hiding point.
- The erasure-sandwich and MCAR-line checks hold to at most
  `3.3306690738754696e-16` nats in the reference run.
- Every generated output is covered by `outputs/SHA256SUMS`.

Wall-clock timings in `outputs/formulation_runtime.csv` describe this runtime
environment only and are not asymptotic complexity claims.
