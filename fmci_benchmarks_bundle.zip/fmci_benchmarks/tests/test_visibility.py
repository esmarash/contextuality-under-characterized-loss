import numpy as np

from fmci_benchmarks.metrics import contextual_fraction, witness_result
from fmci_benchmarks.scenarios import get_scenario, list_scenarios
from fmci_benchmarks.solvers import solve_facets, solve_hidden


def test_visibility_thresholds() -> None:
    for key in list_scenarios():
        scenario = get_scenario(key)
        for offset, should_be_contextual in ((-1.0e-3, False), (1.0e-3, True)):
            visibility = float(np.clip(scenario.visibility_threshold + offset, 0.0, 1.0))
            target, reduced = scenario.target_at_visibility(visibility)
            hidden = solve_hidden(scenario, target_flat=target)
            facets = solve_facets(
                scenario,
                target_flat=target,
                target_reduced_hint=reduced,
            )
            cf = contextual_fraction(scenario, target_flat=target)
            witness = witness_result(scenario, reduced)
            assert hidden.success, hidden.message
            assert facets.success, facets.message
            np.testing.assert_allclose(
                hidden.divergence, facets.divergence, atol=5.0e-9, rtol=0.0
            )
            if should_be_contextual:
                assert hidden.divergence > 1.0e-10
                assert cf.contextual_fraction > 1.0e-10
                assert witness.normalized_violation > 0.0
            else:
                assert hidden.divergence <= 5.0e-9
                assert cf.contextual_fraction <= 5.0e-9
                assert witness.normalized_violation == 0.0
