from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from typing import Sequence

import numpy as np


@dataclass(frozen=True)
class Context:
    """One jointly measured context."""

    name: str
    observable_indices: tuple[int, ...]
    outcomes: tuple[tuple[int, ...], ...]


@dataclass(frozen=True)
class Witness:
    """A canonical linear witness in reduced coordinates."""

    label: str
    coefficients: np.ndarray
    noncontextual_bound: float
    algebraic_bound: float


@dataclass(frozen=True)
class Scenario:
    """Finite contextuality benchmark.

    The full hidden-variable representation uses ``assignments`` and ``incidence``.
    The inequality representation uses a reduced affine behavior
    ``q = affine_base + affine_matrix @ x`` together with the convex hull of
    ``reduced_vertices``. For parity benchmarks, this reduction is exact for
    parity-sector-invariant targets and channels; for KCBS it is the full
    exclusive-event behavior representation.
    """

    key: str
    title: str
    observable_names: tuple[str, ...]
    contexts: tuple[Context, ...]
    assignments: np.ndarray
    target_by_context: tuple[np.ndarray, ...]
    context_weights: np.ndarray
    incidence: np.ndarray
    affine_base: np.ndarray
    affine_matrix: np.ndarray
    reduced_vertices: np.ndarray
    raw_reduced_vertices: np.ndarray
    reduced_labels: tuple[str, ...]
    target_reduced: np.ndarray
    noise_reduced: np.ndarray
    witness: Witness
    visibility_threshold: float
    reduction_scope: str

    def __post_init__(self) -> None:
        n_contexts = len(self.contexts)
        if len(self.target_by_context) != n_contexts:
            raise ValueError("target_by_context must match contexts")
        if self.context_weights.shape != (n_contexts,):
            raise ValueError("context_weights has the wrong shape")
        if not np.isclose(np.sum(self.context_weights), 1.0):
            raise ValueError("context_weights must sum to one")
        if np.any(self.context_weights < 0):
            raise ValueError("context_weights must be nonnegative")
        if self.assignments.ndim != 2:
            raise ValueError("assignments must be a two-dimensional array")
        if self.assignments.shape[1] != len(self.observable_names):
            raise ValueError("assignment width must match observables")
        if self.incidence.shape != (self.n_events, self.n_assignments):
            raise ValueError("incidence has the wrong shape")
        if self.affine_base.shape != (self.n_events,):
            raise ValueError("affine_base has the wrong shape")
        if self.affine_matrix.shape != (self.n_events, self.reduced_dimension):
            raise ValueError("affine_matrix has the wrong shape")
        if self.target_reduced.shape != (self.reduced_dimension,):
            raise ValueError("target_reduced has the wrong shape")
        if self.noise_reduced.shape != (self.reduced_dimension,):
            raise ValueError("noise_reduced has the wrong shape")
        if self.raw_reduced_vertices.shape != (
            self.n_assignments,
            self.reduced_dimension,
        ):
            raise ValueError("raw_reduced_vertices has the wrong shape")
        reconstructed = self.affine_base + self.affine_matrix @ self.target_reduced
        if not np.allclose(reconstructed, self.target_flat, atol=1.0e-12):
            raise ValueError("target does not match the reduced affine model")
        for context_index, context in enumerate(self.contexts):
            sl = self.context_slices[context_index]
            block = self.incidence[sl]
            if not np.allclose(np.sum(block, axis=0), 1.0):
                raise ValueError(f"incidence is not deterministic in {context.name}")
            if not np.isclose(np.sum(self.target_by_context[context_index]), 1.0):
                raise ValueError(f"target is not normalized in {context.name}")

    @property
    def n_contexts(self) -> int:
        return len(self.contexts)

    @property
    def n_assignments(self) -> int:
        return int(self.assignments.shape[0])

    @property
    def reduced_dimension(self) -> int:
        return int(self.reduced_vertices.shape[1])

    @property
    def n_events(self) -> int:
        return int(sum(len(context.outcomes) for context in self.contexts))

    @cached_property
    def context_slices(self) -> tuple[slice, ...]:
        slices: list[slice] = []
        start = 0
        for context in self.contexts:
            stop = start + len(context.outcomes)
            slices.append(slice(start, stop))
            start = stop
        return tuple(slices)

    @cached_property
    def target_flat(self) -> np.ndarray:
        return np.concatenate(self.target_by_context).astype(float, copy=False)

    @cached_property
    def row_context_indices(self) -> np.ndarray:
        values: list[int] = []
        for c, context in enumerate(self.contexts):
            values.extend([c] * len(context.outcomes))
        return np.asarray(values, dtype=int)

    def target_at_visibility(self, visibility: float) -> tuple[np.ndarray, np.ndarray]:
        if not 0.0 <= visibility <= 1.0:
            raise ValueError("visibility must lie in [0, 1]")
        reduced = (
            visibility * self.target_reduced
            + (1.0 - visibility) * self.noise_reduced
        )
        flat = self.affine_base + self.affine_matrix @ reduced
        return flat, reduced

    def split_flat(self, values: Sequence[float]) -> tuple[np.ndarray, ...]:
        array = np.asarray(values, dtype=float)
        if array.shape != (self.n_events,):
            raise ValueError("flat vector has the wrong shape")
        return tuple(array[sl] for sl in self.context_slices)
