# FMCI benchmark report

This report is generated entirely by the code in this repository. The 
hidden-variable and reduced inequality formulations are solved independently.

## Canonical benchmark validation

| scenario | deterministic_assignments | reduced_dimension | facet_count | kl_hidden_nats | kl_analytic_nats | kl_formulation_gap | contextual_fraction |
| --- | --- | --- | --- | --- | --- | --- | --- |
| three_cycle | 8 | 3 | 4 | 0.40546511 | 0.40546511 | 1.110223e-16 | 1 |
| kcbs | 32 | 10 | 36 | 0.032340618 | 0.032340618 | 9.043738e-13 | 0.47213595 |
| magic_square | 512 | 6 | 44 | 0.18232156 | 0.18232156 | 8.3766327e-13 | 1 |

The canonical analytic values are log(3/2) for the perfect-anticorrelation 
3-cycle, the symmetric KCBS projection shown in the source, and log(6/5) 
for the Peres–Mermin parity model.

## Exhaustive context removal

| scenario | subcovers | contextual_subcovers | proper_contextual_subcovers |
| --- | --- | --- | --- |
| kcbs | 32 | 1 | 0 |
| magic_square | 64 | 1 | 0 |
| three_cycle | 8 | 1 | 0 |

The design channel preserves the original context weights and maps each 
omitted context to a deterministic star outcome. Thus these values quantify 
loss relative to the intended full design rather than a renormalized experiment.

### Context criticality

| scenario | context | leave_one_out_fraction_lost | shapley_information_nats | shapley_share |
| --- | --- | --- | --- | --- |
| kcbs | E12 | 1 | 0.0064681237 | 0.2 |
| kcbs | E23 | 1 | 0.0064681237 | 0.2 |
| kcbs | E34 | 1 | 0.0064681237 | 0.2 |
| kcbs | E45 | 1 | 0.0064681237 | 0.2 |
| kcbs | E51 | 1 | 0.0064681237 | 0.2 |
| magic_square | R1 | 1 | 0.030386926 | 0.16666667 |
| magic_square | R2 | 1 | 0.030386926 | 0.16666667 |
| magic_square | R3 | 1 | 0.030386926 | 0.16666667 |
| magic_square | C1 | 1 | 0.030386926 | 0.16666667 |
| magic_square | C2 | 1 | 0.030386926 | 0.16666667 |
| magic_square | C3 | 1 | 0.030386926 | 0.16666667 |
| three_cycle | C12 | 1 | 0.13515504 | 0.33333333 |
| three_cycle | C23 | 1 | 0.13515504 | 0.33333333 |
| three_cycle | C13 | 1 | 0.13515504 | 0.33333333 |

## Three-cycle MNAR scan

Grid points: 2,601.
 Smallest positive off-boundary observed divergence: 0.00015417054 nats.
 Off-boundary numerical hiding count: 0.
 Exact population hiding occurs only on the eta=0 or alpha=0 boundary for this family.

The scan exports observed KL, FMCI, the signed rate-matched residual, 
transported Contextual Fraction, cellwise erasure-sandwich bounds, and solver certificates.

## Formulation comparison

| scenario | formulation | decision_variables | polytope_inequalities | setup_seconds | median_runtime_seconds | absolute_gap_to_other |
| --- | --- | --- | --- | --- | --- | --- |
| three_cycle | hidden_V_representation | 8 | 8 | 0 | 0.000318148 | 1.110223e-16 |
| three_cycle | inequality_H_representation | 3 | 10 | 0.001015826 | 0.000777307 | 1.110223e-16 |
| kcbs | hidden_V_representation | 32 | 32 | 0 | 0.006540846 | 9.043738e-13 |
| kcbs | inequality_H_representation | 10 | 56 | 0.18123792 | 0.000970328 | 9.043738e-13 |
| magic_square | hidden_V_representation | 512 | 512 | 0 | 0.002508949 | 8.3766327e-13 |
| magic_square | inequality_H_representation | 6 | 56 | 0.010263048 | 0.000868825 | 8.3766327e-13 |

Facet-generation time is reported separately from repeated solve time. The 
3-cycle and magic-square H-representations are symmetry reductions valid for 
the benchmark families declared in `reduction_scope`; the hidden formulation 
always retains the full deterministic assignment model.

## Numerical validation summary

```json
{
  "all_proper_subcovers_noncontextual": {
    "kcbs": true,
    "magic_square": true,
    "three_cycle": true
  },
  "eta_alpha_boundary_nonhiding_count": 0,
  "eta_alpha_maximum_lower_sandwich_violation_nats": 0.0,
  "eta_alpha_maximum_upper_sandwich_violation_nats": 3.3306690738754696e-16,
  "eta_alpha_mcar_line_maximum_gap_nats": 3.3306690738754696e-16,
  "eta_alpha_minimum_CF_increment_in_alpha": 0.0,
  "eta_alpha_minimum_CF_increment_in_eta": 0.0,
  "eta_alpha_minimum_KL_increment_in_alpha": 0.0,
  "eta_alpha_minimum_KL_increment_in_eta": 0.0,
  "eta_alpha_off_boundary_hiding_count": 0,
  "maximum_baseline_analytic_cf_gap": 3.3306690738754696e-16,
  "maximum_baseline_analytic_kl_gap": 9.044917592682111e-13,
  "maximum_facet_optimality_gap_nats": 1.45328193923433e-13,
  "maximum_hidden_facet_gap": 9.996712659054996e-13,
  "maximum_hidden_optimality_gap_nats": 9.99866855977416e-13,
  "maximum_shapley_efficiency_error_nats": 6.938893903907228e-18
}
```

## Reproduce

```bash
python -m pip install -e '.[dev]'
pytest
fmci-benchmarks --config configs/default.yaml
```
