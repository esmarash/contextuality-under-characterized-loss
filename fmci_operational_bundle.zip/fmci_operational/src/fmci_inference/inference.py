from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

import numpy as np
from scipy.stats import norm

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario

from .data import ObservedCounts, observed_probabilities
from .estimands import FMCIEstimate, estimate_fmci, full_and_observed_gradients
from .identification import IdentificationError, asymptotic_latent_covariance


@dataclass(frozen=True)
class ScalarInterval:
    estimate: float
    standard_error: float
    lower: float
    upper: float
    confidence_level: float
    method: str


@dataclass(frozen=True)
class FiellerSet:
    ratio_intervals: tuple[tuple[float, float], ...]
    fmci_intervals: tuple[tuple[float, float], ...]
    kind: str
    bounded: bool
    confidence_level: float
    denominator_excludes_zero: bool


@dataclass(frozen=True)
class RegularityDiagnostics:
    classification: str
    reasons: tuple[str, ...]
    minimum_latent_probability: float
    minimum_retention: float
    denominator_z_score: float
    fieller_kind: str
    maximum_solver_gap: float


@dataclass(frozen=True)
class RegularInference:
    full: ScalarInterval
    observed: ScalarInterval
    absolute_loss: ScalarInterval
    fmci_delta: ScalarInterval | None
    fieller: FiellerSet
    covariance_observed_full: np.ndarray
    diagnostics: RegularityDiagnostics


@dataclass(frozen=True)
class BootstrapSummary:
    replicates_requested: int
    replicates_successful: int
    confidence_level: float
    full_bias: float
    observed_bias: float
    absolute_loss_bias: float
    fmci_bias: float
    full_interval: tuple[float, float]
    observed_interval: tuple[float, float]
    absolute_loss_interval: tuple[float, float]
    fmci_interval: tuple[float, float]
    replicate_values: np.ndarray


def _normal_interval(
    estimate: float,
    variance: float,
    confidence: float,
    method: str,
    *,
    lower_bound: float | None = None,
    upper_bound: float | None = None,
) -> ScalarInterval:
    se = math.sqrt(max(0.0, float(variance)))
    z = float(norm.ppf(0.5 + confidence / 2.0))
    lower = estimate - z * se
    upper = estimate + z * se
    if lower_bound is not None:
        lower = max(lower_bound, lower)
    if upper_bound is not None:
        upper = min(upper_bound, upper)
    return ScalarInterval(
        estimate=float(estimate),
        standard_error=se,
        lower=float(lower),
        upper=float(upper),
        confidence_level=confidence,
        method=method,
    )


def _quadratic_nonpositive_set(
    a: float,
    b: float,
    c: float,
    *,
    tolerance: float = 1.0e-14,
) -> tuple[tuple[tuple[float, float], ...], str]:
    if abs(a) <= tolerance:
        if abs(b) <= tolerance:
            if c <= tolerance:
                return ((-math.inf, math.inf),), "all-real"
            return tuple(), "empty"
        threshold = -c / b
        if b > 0:
            return ((-math.inf, threshold),), "half-line"
        return ((threshold, math.inf),), "half-line"
    discriminant = b * b - 4.0 * a * c
    if discriminant < -tolerance:
        if a < 0:
            return ((-math.inf, math.inf),), "all-real"
        return tuple(), "empty"
    discriminant = max(0.0, discriminant)
    root = math.sqrt(discriminant)
    r1 = (-b - root) / (2.0 * a)
    r2 = (-b + root) / (2.0 * a)
    low, high = sorted((r1, r2))
    if a > 0:
        return ((low, high),), "bounded"
    return ((-math.inf, low), (high, math.inf)), "complement"


def _intersect_intervals(
    intervals: Iterable[tuple[float, float]],
    lower: float,
    upper: float,
) -> tuple[tuple[float, float], ...]:
    result: list[tuple[float, float]] = []
    for left, right in intervals:
        lo = max(lower, left)
        hi = min(upper, right)
        if lo <= hi:
            result.append((float(lo), float(hi)))
    return tuple(result)


def fieller_fmci_set(
    observed: float,
    full: float,
    covariance_observed_full: np.ndarray,
    *,
    confidence: float = 0.95,
    physical_intersection: bool = True,
) -> FiellerSet:
    """Fieller confidence set for ``lambda = 1 - observed/full``.

    An unbounded or disconnected set is a feature, not a numerical failure: it
    records that the denominator is too weakly separated from zero for a
    stable ratio statement.
    """

    covariance = np.asarray(covariance_observed_full, dtype=float)
    if covariance.shape != (2, 2):
        raise ValueError("covariance must have shape (2,2) in [observed, full] order")
    z = float(norm.ppf(0.5 + confidence / 2.0))
    va = float(covariance[0, 0])
    vb = float(covariance[1, 1])
    cab = float(covariance[0, 1])
    qa = full * full - z * z * vb
    qb = -2.0 * observed * full + 2.0 * z * z * cab
    qc = observed * observed - z * z * va
    ratio_intervals, kind = _quadratic_nonpositive_set(qa, qb, qc)
    denominator_excludes_zero = bool(full * full > z * z * vb)
    bounded = bool(kind == "bounded" and denominator_excludes_zero)
    if physical_intersection:
        ratio_intervals = _intersect_intervals(ratio_intervals, 0.0, 1.0)
    fmci = tuple((1.0 - right, 1.0 - left) for left, right in ratio_intervals)
    fmci = tuple(sorted(fmci))
    return FiellerSet(
        ratio_intervals=ratio_intervals,
        fmci_intervals=fmci,
        kind=kind,
        bounded=bounded,
        confidence_level=confidence,
        denominator_excludes_zero=denominator_excludes_zero,
    )


def regular_inference(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    estimate: FMCIEstimate,
    *,
    confidence: float = 0.95,
    probability_floor: float = 1.0e-5,
    retention_floor: float = 1.0e-4,
    denominator_z_threshold: float = 3.0,
) -> RegularInference:
    """Delta and Fieller inference under the smooth identified alternative."""

    covariance_latent = asymptotic_latent_covariance(
        scenario,
        estimate.latent_fit,
        channel,
        counts.context_trials,
    )
    full_gradient, observed_gradient = full_and_observed_gradients(
        scenario, estimate, channel
    )
    gradient_matrix = np.vstack((observed_gradient, full_gradient))
    covariance_ab = gradient_matrix @ covariance_latent @ gradient_matrix.T
    full_variance = float(covariance_ab[1, 1])
    observed_variance = float(covariance_ab[0, 0])
    absolute_gradient = full_gradient - observed_gradient
    absolute_variance = float(absolute_gradient @ covariance_latent @ absolute_gradient)

    full_interval = _normal_interval(
        estimate.full_divergence,
        full_variance,
        confidence,
        "regular delta method",
        lower_bound=0.0,
    )
    observed_interval = _normal_interval(
        estimate.observed_divergence,
        observed_variance,
        confidence,
        "regular delta method",
        lower_bound=0.0,
    )
    absolute_interval = _normal_interval(
        estimate.absolute_loss,
        absolute_variance,
        confidence,
        "regular delta method",
        lower_bound=0.0,
    )

    fmci_interval: ScalarInterval | None = None
    if estimate.fmci_reportable:
        lambda_gradient = (
            -observed_gradient / estimate.full_divergence
            + estimate.observed_divergence
            * full_gradient
            / (estimate.full_divergence**2)
        )
        lambda_variance = float(lambda_gradient @ covariance_latent @ lambda_gradient)
        fmci_interval = _normal_interval(
            estimate.fmci,
            lambda_variance,
            confidence,
            "regular delta method",
            lower_bound=0.0,
            upper_bound=1.0,
        )

    fieller = fieller_fmci_set(
        estimate.observed_divergence,
        estimate.full_divergence,
        covariance_ab,
        confidence=confidence,
    )
    minimum_p = float(np.min(estimate.latent_fit.target_flat))
    minimum_retention = estimate.latent_fit.identification.minimum_retention
    full_se = math.sqrt(max(0.0, full_variance))
    denominator_z = (
        estimate.full_divergence / full_se
        if full_se > 0
        else (math.inf if estimate.full_divergence > 0 else 0.0)
    )
    reasons: list[str] = []
    if minimum_p <= probability_floor:
        reasons.append("one or more latent probabilities are on/near the simplex boundary")
    if minimum_retention <= retention_floor:
        reasons.append("retention is on/near a non-identification boundary")
    if not estimate.latent_fit.identification.point_identified:
        reasons.append("the channel does not point-identify the complete behavior")
    if denominator_z < denominator_z_threshold:
        reasons.append("full contextual divergence is weakly separated from zero")
    if not fieller.bounded:
        reasons.append("Fieller ratio set is not a single bounded interval")
    maximum_gap = max(
        estimate.full_projection.optimality_gap,
        estimate.observed_projection.optimality_gap,
    )
    if maximum_gap > 1.0e-7:
        reasons.append("KL projection optimality certificate is too loose")

    if not reasons:
        classification = "regular"
    elif any("point-identify" in reason for reason in reasons):
        classification = "not-identified"
    elif denominator_z < denominator_z_threshold or not fieller.bounded:
        classification = "weak-denominator/nonregular"
    else:
        classification = "boundary-risk"
    diagnostics = RegularityDiagnostics(
        classification=classification,
        reasons=tuple(reasons),
        minimum_latent_probability=minimum_p,
        minimum_retention=float(minimum_retention),
        denominator_z_score=float(denominator_z),
        fieller_kind=fieller.kind,
        maximum_solver_gap=float(maximum_gap),
    )
    return RegularInference(
        full=full_interval,
        observed=observed_interval,
        absolute_loss=absolute_interval,
        fmci_delta=fmci_interval,
        fieller=fieller,
        covariance_observed_full=covariance_ab,
        diagnostics=diagnostics,
    )


def _simulate_fixed_context_counts(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
    context_trials: np.ndarray,
    rng: np.random.Generator,
) -> ObservedCounts:
    blocks = observed_probabilities(scenario, target_flat, channel)
    counts = tuple(
        rng.multinomial(int(n), q)
        for n, q in zip(context_trials, blocks, strict=True)
    )
    return ObservedCounts(tuple(np.asarray(block, dtype=int) for block in counts))


def parametric_bootstrap(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    estimate: FMCIEstimate,
    *,
    replicates: int = 999,
    confidence: float = 0.95,
    seed: int = 20260713,
) -> BootstrapSummary:
    """Conditional parametric bootstrap for the regular identified regime.

    This routine intentionally refuses to label itself boundary-valid.  The
    caller should use ``regular_inference`` diagnostics before interpreting
    the percentile interval for FMCI.
    """

    if replicates <= 1:
        raise ValueError("replicates must exceed one")
    rng = np.random.default_rng(seed)
    values: list[list[float]] = []
    for _ in range(replicates):
        bootstrap_counts = _simulate_fixed_context_counts(
            scenario,
            estimate.latent_fit.target_flat,
            channel,
            counts.context_trials,
            rng,
        )
        try:
            result = estimate_fmci(scenario, bootstrap_counts, channel)
        except (IdentificationError, RuntimeError, ValueError):
            continue
        values.append(
            [
                result.full_divergence,
                result.observed_divergence,
                result.absolute_loss,
                result.fmci if result.fmci_reportable else math.nan,
            ]
        )
    array = np.asarray(values, dtype=float)
    if array.ndim != 2 or array.shape[0] < max(20, replicates // 2):
        raise RuntimeError("too few successful bootstrap replicates")
    alpha = (1.0 - confidence) / 2.0

    def interval(column: int) -> tuple[float, float]:
        finite = array[np.isfinite(array[:, column]), column]
        if finite.size < 20:
            return (math.nan, math.nan)
        return tuple(np.quantile(finite, [alpha, 1.0 - alpha]).astype(float))

    original = np.asarray(
        [
            estimate.full_divergence,
            estimate.observed_divergence,
            estimate.absolute_loss,
            estimate.fmci,
        ]
    )
    means = np.nanmean(array, axis=0)
    biases = means - original
    return BootstrapSummary(
        replicates_requested=replicates,
        replicates_successful=int(array.shape[0]),
        confidence_level=confidence,
        full_bias=float(biases[0]),
        observed_bias=float(biases[1]),
        absolute_loss_bias=float(biases[2]),
        fmci_bias=float(biases[3]),
        full_interval=interval(0),
        observed_interval=interval(1),
        absolute_loss_interval=interval(2),
        fmci_interval=interval(3),
        replicate_values=array,
    )
