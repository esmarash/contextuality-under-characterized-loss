from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np

from fmci_benchmarks.channels import Channel
from fmci_benchmarks.model import Scenario


@dataclass(frozen=True)
class ObservedCounts:
    """Context-stratified counts with one terminal star category per context.

    Each block has length ``len(context.outcomes) + 1``.  The final entry is
    the number of attempted trials for which the context was recorded but the
    complete outcome was erased.
    """

    counts_by_context: tuple[np.ndarray, ...]

    def validate(self, scenario: Scenario) -> None:
        if len(self.counts_by_context) != scenario.n_contexts:
            raise ValueError("counts have the wrong number of contexts")
        for context, counts in zip(
            scenario.contexts, self.counts_by_context, strict=True
        ):
            values = np.asarray(counts)
            if values.shape != (len(context.outcomes) + 1,):
                raise ValueError(f"count shape mismatch in {context.name}")
            if np.any(~np.isfinite(values)):
                raise ValueError("counts must be finite")
            if np.any(values < 0) or np.any(values != np.floor(values)):
                raise ValueError("counts must be nonnegative integers")

    @property
    def total_trials(self) -> int:
        return int(sum(np.sum(block) for block in self.counts_by_context))

    @property
    def context_trials(self) -> np.ndarray:
        return np.asarray([np.sum(block) for block in self.counts_by_context], dtype=int)

    @property
    def detected_trials(self) -> int:
        return int(sum(np.sum(block[:-1]) for block in self.counts_by_context))

    @property
    def star_trials(self) -> int:
        return int(sum(block[-1] for block in self.counts_by_context))

    def empirical_observed_blocks(self, scenario: Scenario) -> tuple[np.ndarray, ...]:
        self.validate(scenario)
        blocks: list[np.ndarray] = []
        for context, counts in zip(
            scenario.contexts, self.counts_by_context, strict=True
        ):
            total = int(np.sum(counts))
            if total <= 0:
                raise ValueError(f"context {context.name} has no attempted trials")
            blocks.append(np.asarray(counts, dtype=float) / total)
        return tuple(blocks)

    def flattened(self, scenario: Scenario) -> np.ndarray:
        self.validate(scenario)
        return np.concatenate([np.asarray(x, dtype=int) for x in self.counts_by_context])


@dataclass(frozen=True)
class CalibrationCounts:
    """Independent cell-level detector calibration data.

    ``successes_by_context[c][i]`` detections are observed in
    ``totals_by_context[c][i]`` calibration attempts prepared in complete-data
    cell ``(c, i)``.
    """

    successes_by_context: tuple[np.ndarray, ...]
    totals_by_context: tuple[np.ndarray, ...]

    def validate(self, scenario: Scenario) -> None:
        if len(self.successes_by_context) != scenario.n_contexts:
            raise ValueError("calibration has the wrong number of contexts")
        if len(self.totals_by_context) != scenario.n_contexts:
            raise ValueError("calibration has the wrong number of contexts")
        for context, successes, totals in zip(
            scenario.contexts,
            self.successes_by_context,
            self.totals_by_context,
            strict=True,
        ):
            successes = np.asarray(successes)
            totals = np.asarray(totals)
            expected = (len(context.outcomes),)
            if successes.shape != expected or totals.shape != expected:
                raise ValueError(f"calibration shape mismatch in {context.name}")
            if np.any(successes < 0) or np.any(totals < 0):
                raise ValueError("calibration counts must be nonnegative")
            if np.any(successes > totals):
                raise ValueError("calibration successes cannot exceed totals")
            if np.any(successes != np.floor(successes)) or np.any(
                totals != np.floor(totals)
            ):
                raise ValueError("calibration counts must be integers")

    def empirical_channel(self, scenario: Scenario, *, smoothing: float = 0.5) -> Channel:
        """Return a Jeffreys-smoothed cellwise retention estimate."""

        self.validate(scenario)
        if smoothing < 0:
            raise ValueError("smoothing must be nonnegative")
        blocks: list[np.ndarray] = []
        for successes, totals in zip(
            self.successes_by_context, self.totals_by_context, strict=True
        ):
            denominator = np.asarray(totals, dtype=float) + 2.0 * smoothing
            if np.any(denominator <= 0):
                raise ValueError("all calibration cells need positive total or smoothing")
            blocks.append((np.asarray(successes, dtype=float) + smoothing) / denominator)
        return Channel(name="calibration_empirical", retention_by_context=tuple(blocks))


@dataclass(frozen=True)
class SimulatedTrialRecord:
    counts: ObservedCounts
    context_sequence: np.ndarray | None
    success_sequence: np.ndarray | None


def observed_probabilities(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
) -> tuple[np.ndarray, ...]:
    """Transport a complete behavior through a whole-outcome erasure channel."""

    channel.validate(scenario)
    target = np.asarray(target_flat, dtype=float)
    if target.shape != (scenario.n_events,):
        raise ValueError("target_flat has the wrong shape")
    blocks: list[np.ndarray] = []
    for context, sl, retention in zip(
        scenario.contexts,
        scenario.context_slices,
        channel.retention_by_context,
        strict=True,
    ):
        p = target[sl]
        if np.any(p < -1.0e-12) or not np.isclose(np.sum(p), 1.0, atol=1.0e-10):
            raise ValueError(f"invalid complete distribution in {context.name}")
        detected = retention * np.maximum(p, 0.0)
        star = 1.0 - float(np.sum(detected))
        if star < -1.0e-12:
            raise ValueError("transported star probability became negative")
        block = np.concatenate((detected, np.asarray([max(0.0, star)])))
        block /= np.sum(block)
        blocks.append(block)
    return tuple(blocks)


def allocate_context_trials(
    total_trials: int,
    context_weights: Sequence[float],
    rng: np.random.Generator,
    *,
    randomized: bool,
) -> np.ndarray:
    if total_trials <= 0:
        raise ValueError("total_trials must be positive")
    weights = np.asarray(context_weights, dtype=float)
    if np.any(weights < 0) or not np.isclose(np.sum(weights), 1.0):
        raise ValueError("context weights must be a probability vector")
    if randomized:
        return rng.multinomial(total_trials, weights)
    raw = total_trials * weights
    counts = np.floor(raw).astype(int)
    remainder = total_trials - int(np.sum(counts))
    if remainder:
        order = np.argsort(-(raw - counts))
        counts[order[:remainder]] += 1
    return counts


def simulate_observed_counts(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
    total_trials: int,
    rng: np.random.Generator,
    *,
    randomized_contexts: bool = False,
    return_trial_sequence: bool = False,
    success_masks: tuple[np.ndarray, ...] | None = None,
) -> SimulatedTrialRecord:
    """Simulate context-labelled observed counts.

    When ``randomized_contexts`` is true, context totals are multinomial with
    probabilities ``scenario.context_weights``.  This is the design required
    by the memory-robust win/lose p-value unless a separate setting-generation
    argument is supplied.
    """

    q_blocks = observed_probabilities(scenario, target_flat, channel)
    n_by_context = allocate_context_trials(
        total_trials,
        scenario.context_weights,
        rng,
        randomized=randomized_contexts,
    )
    count_blocks = tuple(
        rng.multinomial(int(n), q)
        for n, q in zip(n_by_context, q_blocks, strict=True)
    )
    counts = ObservedCounts(tuple(np.asarray(x, dtype=int) for x in count_blocks))

    if not return_trial_sequence:
        return SimulatedTrialRecord(counts, None, None)

    contexts: list[int] = []
    successes: list[int] = []
    if success_masks is not None and len(success_masks) != scenario.n_contexts:
        raise ValueError("success_masks has the wrong number of contexts")
    for c, block in enumerate(count_blocks):
        categories = np.repeat(np.arange(len(block)), block)
        rng.shuffle(categories)
        contexts.extend([c] * len(categories))
        if success_masks is not None:
            mask = np.concatenate(
                (np.asarray(success_masks[c], dtype=bool), np.asarray([False]))
            )
            successes.extend(mask[categories].astype(int).tolist())
    permutation = rng.permutation(len(contexts))
    context_array = np.asarray(contexts, dtype=int)[permutation]
    success_array = (
        None
        if success_masks is None
        else np.asarray(successes, dtype=int)[permutation]
    )
    return SimulatedTrialRecord(counts, context_array, success_array)


def simulate_calibration_counts(
    scenario: Scenario,
    channel: Channel,
    attempts_per_cell: int | Sequence[np.ndarray],
    rng: np.random.Generator,
) -> CalibrationCounts:
    channel.validate(scenario)
    if isinstance(attempts_per_cell, int):
        if attempts_per_cell <= 0:
            raise ValueError("attempts_per_cell must be positive")
        totals = tuple(
            np.full(len(context.outcomes), attempts_per_cell, dtype=int)
            for context in scenario.contexts
        )
    else:
        totals = tuple(np.asarray(x, dtype=int) for x in attempts_per_cell)
        if len(totals) != scenario.n_contexts:
            raise ValueError("attempt arrays have the wrong number of contexts")
    successes = tuple(
        rng.binomial(n, retention).astype(int)
        for n, retention in zip(totals, channel.retention_by_context, strict=True)
    )
    result = CalibrationCounts(successes, totals)
    result.validate(scenario)
    return result


def counts_from_blocks(blocks: Iterable[Sequence[int]]) -> ObservedCounts:
    return ObservedCounts(tuple(np.asarray(block, dtype=int) for block in blocks))
