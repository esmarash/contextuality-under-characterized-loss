# Operational and finite-sample validation report

## Scope

This package separates three inferential tasks: estimating latent complete behavior under a declared channel, quantifying FMCI in the regular identified regime, and testing a pre-specified contextuality game with a finite-sample p-value. Unknown MNAR mechanisms are handled by a declared sensitivity family and a union interval rather than by a single unidentified point estimate.

## Regular alternative

The fitted log-log RMSE slope for FMCI is -0.581; a root-N regime corresponds to -0.5.
Across the evaluated sample sizes, among replications for which the smooth calculation completed, delta-method FMCI coverage ranged from 0.960 to 0.996, and Fieller coverage ranged from 0.960 to 0.992.
The minimum successful smooth-calculation fraction was 0.952. Individual KL delta intervals showed finite-sample coverage as low as 0.916; these results are retained rather than described as uniformly accurate small-sample intervals.

## Near-boundary behavior

At the smallest near-boundary sample size, only 0.012 of replications produced a bounded Fieller set. This is the intended diagnostic: an FMCI ratio should not be reported as a stable scalar when the full contextual divergence is weakly separated from zero.

## Bias

The output table reports N times the bias separately for full divergence, observed divergence, and FMCI. The coefficients vary across visibility, sample size, and estimand; the simulations therefore do not support a universal d/(2N) correction for the projected KL or its ratio.

## Contextuality p-values

No evaluated type-I rejection rate exceeded its nominal level; the maximum excess above level was 0.0000 (the largest signed difference was -0.0012). The binary-game tail bound is conditional on randomized, unpredictable context choices and on the declared transported noncontextual null.

## Calibration and MNAR sensitivity

The simultaneous calibration box had empirical familywise coverage 0.982 at nominal level 0.975.
The calibrated sensitivity scan retained 16 of 567 channel candidates. Its point FMCI range was [0.3050310439883347, 0.354984049264614]; the union interval was [0.3021864841468159, 0.35848220434438927]. The nominal Bonferroni combined-coverage lower bound is 0.950 provided the fixed-channel intervals attain their stated conditional coverage, the declared family contains the true mechanism, and the computational grid covers it.

## Joint reporting example

FMCI = 0.328278; Fieller set = [[0.32492275377957325, 0.33166633770396514]]; memory-robust win/lose p-value = 3.487e-09.

The p-value and FMCI answer different questions. They are displayed side by side and are not combined arithmetically.

## Files

- `finite_sample_replicates.csv`: replicate-level estimates and diagnostics.
- `finite_sample_summary.csv`: bias, RMSE, coverage, and reportability by regime and sample size.
- `pvalue_validation.csv`: type-I error and power for the binary contextuality game.
- `calibration_coverage.csv`: simultaneous detector-calibration coverage.
- `sensitivity_scan.csv`: candidate-level MNAR analysis.
- `joint_reporting_example.json`: recommended two-axis experimental report.
- `bootstrap_summary.json`: regular-regime conditional bootstrap only.
- `identification_scan.csv`: rank and conditioning near the positivity boundary.
