from __future__ import annotations

import math
import time
from dataclasses import dataclass

import numpy as np

from fmci_benchmarks.channels import Channel, identity_channel
from fmci_benchmarks.model import Scenario
from fmci_benchmarks.solvers import (
    SolveResult,
    observed_target_and_components,
    solve_hidden,
    weighted_kl,
)

from .data import ObservedCounts
from .identification import (
    IdentificationError,
    LatentBehaviorFit,
    channel_tangent_jacobian,
    fit_latent_behavior,
)


@dataclass(frozen=True)
class FMCIEstimate:
    latent_fit: LatentBehaviorFit
    full_projection: SolveResult
    observed_projection: SolveResult
    full_divergence: float
    observed_divergence: float
    absolute_loss: float
    fmci: float
    fmci_reportable: bool
    mean_retention: float
    numerical_dpi_gap: float


@dataclass(frozen=True)
class EmpiricalProjection:
    divergence: float
    fitted_observed: np.ndarray
    observed_empirical: np.ndarray
    optimizer: np.ndarray
    iterations: int
    converged: bool
    optimality_gap: float
    runtime_seconds: float


def _require_projection(result: SolveResult) -> None:
    if not result.success:
        raise RuntimeError(
            f"KL projection failed: {result.message}; gap={result.optimality_gap:.3e}"
        )


def estimate_fmci(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    *,
    denominator_floor: float = 1.0e-12,
    require_point_identified: bool = True,
    solver_tolerance: float = 1.0e-11,
) -> FMCIEstimate:
    """Coherent plug-in estimate based on the known-channel latent MLE.

    Both divergences are evaluated at the same fitted complete behavior and
    through the same declared channel.  Consequently numerical violations of
    data processing are solver diagnostics rather than an estimator-design
    artifact.
    """

    latent = fit_latent_behavior(
        scenario,
        counts,
        channel,
        require_point_identified=require_point_identified,
        tolerance=solver_tolerance,
    )
    full = solve_hidden(
        scenario,
        target_flat=latent.target_flat,
        tolerance=solver_tolerance,
    )
    observed = solve_hidden(
        scenario,
        target_flat=latent.target_flat,
        channel=channel,
        tolerance=solver_tolerance,
    )
    _require_projection(full)
    _require_projection(observed)
    full_d = float(max(0.0, full.divergence))
    observed_d = float(max(0.0, observed.divergence))
    dpi_gap = observed_d - full_d
    absolute_loss = full_d - observed_d
    reportable = bool(full_d > denominator_floor)
    fmci = float(1.0 - observed_d / full_d) if reportable else math.nan
    if reportable and -1.0e-8 <= fmci <= 1.0 + 1.0e-8:
        fmci = float(np.clip(fmci, 0.0, 1.0))
    return FMCIEstimate(
        latent_fit=latent,
        full_projection=full,
        observed_projection=observed,
        full_divergence=full_d,
        observed_divergence=observed_d,
        absolute_loss=absolute_loss,
        fmci=fmci,
        fmci_reportable=reportable,
        mean_retention=channel.target_mean_retention(scenario, latent.target_flat),
        numerical_dpi_gap=dpi_gap,
    )


def project_empirical_observed_distribution(
    scenario: Scenario,
    counts: ObservedCounts,
    channel: Channel,
    *,
    use_empirical_context_weights: bool = True,
    tolerance: float = 1.0e-11,
    max_iterations: int = 100_000,
) -> EmpiricalProjection:
    """KL projection of raw observed frequencies onto the transported NC set.

    With empirical context weights this is the multinomial generalized
    likelihood-ratio divergence per attempted trial.
    """

    counts.validate(scenario)
    channel.validate(scenario)
    empirical_blocks = counts.empirical_observed_blocks(scenario)
    p_obs = np.concatenate(empirical_blocks)
    _, components, row_contexts = observed_target_and_components(
        scenario, scenario.target_flat, channel
    )
    if use_empirical_context_weights:
        context_weights = counts.context_trials.astype(float)
        context_weights /= np.sum(context_weights)
    else:
        context_weights = scenario.context_weights
    row_weights = context_weights[row_contexts]
    weighted_mass = row_weights * p_obs
    active_mass = float(np.sum(weighted_mass))
    normalized_counts = weighted_mass / active_mass
    positive = normalized_counts > 0
    hidden = np.full(scenario.n_assignments, 1.0 / scenario.n_assignments)
    q_obs = components @ hidden
    previous = math.inf
    started = time.perf_counter()
    gap = math.inf
    converged = False
    iteration = 0
    for iteration in range(1, max_iterations + 1):
        if np.any(q_obs[positive] <= 0):
            raise RuntimeError("transported NC fit has zero mass on empirical support")
        score = components[positive].T @ (
            normalized_counts[positive] / q_obs[positive]
        )
        gap = max(0.0, float(np.max(score) - 1.0)) * active_mass
        divergence = weighted_kl(p_obs, q_obs, row_weights)
        if gap <= tolerance and abs(previous - divergence) <= tolerance * max(
            1.0, abs(divergence)
        ):
            converged = True
            break
        updated = hidden * score
        total = float(np.sum(updated))
        if not math.isfinite(total) or total <= 0:
            raise RuntimeError("empirical projection update became degenerate")
        hidden = updated / total
        hidden = np.maximum(hidden, 1.0e-300)
        hidden /= np.sum(hidden)
        previous = divergence
        q_obs = components @ hidden
    runtime = time.perf_counter() - started
    divergence = weighted_kl(p_obs, q_obs, row_weights)
    return EmpiricalProjection(
        divergence=float(divergence),
        fitted_observed=q_obs,
        observed_empirical=p_obs,
        optimizer=hidden,
        iterations=iteration,
        converged=converged,
        optimality_gap=float(gap),
        runtime_seconds=runtime,
    )


def divergence_gradient_latent(
    scenario: Scenario,
    target_flat: np.ndarray,
    channel: Channel,
    projection: SolveResult,
    *,
    zero_tolerance: float = 1.0e-14,
) -> np.ndarray:
    """Envelope gradient of the projected KL value in latent simplex coordinates.

    This is valid only in the smooth regime: observed probabilities that vary
    with the latent parameter and fitted probabilities on those rows must be
    strictly positive, and the KL projection must be locally stable.
    """

    target = np.asarray(target_flat, dtype=float)
    if target.shape != (scenario.n_events,):
        raise ValueError("target_flat has the wrong shape")
    q = np.asarray(projection.observed_target, dtype=float)
    r = np.asarray(projection.observed_fit, dtype=float)
    gradients: list[np.ndarray] = []
    row_start = 0
    for c, (context, retention) in enumerate(
        zip(scenario.contexts, channel.retention_by_context, strict=True)
    ):
        block_size = len(context.outcomes) + 1
        block_q = q[row_start : row_start + block_size]
        block_r = r[row_start : row_start + block_size]
        jacobian = channel_tangent_jacobian(np.asarray(retention, dtype=float))
        varying = np.linalg.norm(jacobian, axis=1) > zero_tolerance
        if np.any(block_q[varying] <= zero_tolerance):
            raise IdentificationError(
                f"nonregular divergence gradient in {context.name}: zero target cell"
            )
        if np.any(block_r[varying] <= zero_tolerance):
            raise IdentificationError(
                f"nonregular divergence gradient in {context.name}: zero fitted cell"
            )
        influence = np.zeros(block_size, dtype=float)
        influence[varying] = np.log(block_q[varying] / block_r[varying]) + 1.0
        gradients.append(
            scenario.context_weights[c] * (jacobian.T @ influence)
        )
        row_start += block_size
    return np.concatenate(gradients)


def full_and_observed_gradients(
    scenario: Scenario,
    estimate: FMCIEstimate,
    channel: Channel,
) -> tuple[np.ndarray, np.ndarray]:
    full_gradient = divergence_gradient_latent(
        scenario,
        estimate.latent_fit.target_flat,
        identity_channel(scenario),
        estimate.full_projection,
    )
    observed_gradient = divergence_gradient_latent(
        scenario,
        estimate.latent_fit.target_flat,
        channel,
        estimate.observed_projection,
    )
    return full_gradient, observed_gradient
