from __future__ import annotations

import hashlib
import itertools
import json
import math
import platform
import statistics
import sys
import time
from datetime import UTC, datetime
from importlib.metadata import PackageNotFoundError, version as package_version
from math import factorial
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy

from .channels import design_subcover_channel, three_cycle_eta_alpha_channel
from .geometry import FacetRepresentation, facet_representation
from .metrics import ContextualFractionResult, contextual_fraction, witness_result
from .model import Scenario
from .scenarios import get_scenario, list_scenarios
from .solvers import SolveResult, solve_facets, solve_hidden


NUMERIC_ZERO = 2.0e-9


def _package_version() -> str:
    try:
        return package_version("fmci-benchmarks")
    except PackageNotFoundError:
        return "source-tree"


def _require_success(result: SolveResult) -> None:
    if not result.success:
        raise RuntimeError(
            f"{result.formulation} solver failed: {result.message}; "
            f"gap={result.optimality_gap:.3e}, violation={result.constraint_violation:.3e}"
        )


def _require_cf_success(result: ContextualFractionResult) -> None:
    if not result.success:
        raise RuntimeError(
            f"Contextual Fraction LP failed: {result.message}; "
            f"violation={result.constraint_violation:.3e}"
        )


def _json_dump(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def _scenario_analytic_values(scenario: Scenario) -> tuple[float, float]:
    if scenario.key == "three_cycle":
        return math.log(3.0 / 2.0), 1.0
    if scenario.key == "magic_square":
        return math.log(6.0 / 5.0), 1.0
    if scenario.key == "kcbs":
        q = 1.0 / math.sqrt(5.0)
        divergence = (1.0 - 2.0 * q) * math.log((1.0 - 2.0 * q) / 0.2)
        divergence += 2.0 * q * math.log(q / 0.4)
        return divergence, 2.0 * (math.sqrt(5.0) - 2.0)
    raise KeyError(scenario.key)


def benchmark_summary(
    scenarios: Iterable[Scenario],
    facets: dict[str, FacetRepresentation],
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for scenario in scenarios:
        hidden = solve_hidden(scenario)
        inequality = solve_facets(scenario, facets=facets[scenario.key])
        _require_success(hidden)
        _require_success(inequality)
        cf = contextual_fraction(scenario)
        _require_cf_success(cf)
        witness = witness_result(scenario, scenario.target_reduced)
        analytic_d, analytic_cf = _scenario_analytic_values(scenario)
        rows.append(
            {
                "scenario": scenario.key,
                "title": scenario.title,
                "contexts": scenario.n_contexts,
                "observables": len(scenario.observable_names),
                "local_events": scenario.n_events,
                "deterministic_assignments": scenario.n_assignments,
                "reduced_vertices": facets[scenario.key].n_vertices,
                "reduced_dimension": scenario.reduced_dimension,
                "facet_count": facets[scenario.key].n_facets,
                "facet_generation_seconds": facets[scenario.key].generation_seconds,
                "kl_hidden_nats": hidden.divergence,
                "kl_facets_nats": inequality.divergence,
                "kl_analytic_nats": analytic_d,
                "kl_formulation_gap": abs(hidden.divergence - inequality.divergence),
                "kl_analytic_gap": abs(hidden.divergence - analytic_d),
                "contextual_fraction": cf.contextual_fraction,
                "contextual_fraction_analytic": analytic_cf,
                "cf_analytic_gap": abs(cf.contextual_fraction - analytic_cf),
                "witness_value": witness.value,
                "witness_noncontextual_bound": witness.noncontextual_bound,
                "witness_algebraic_bound": witness.algebraic_bound,
                "normalized_witness_violation": witness.normalized_violation,
                "visibility_threshold": scenario.visibility_threshold,
                "hidden_runtime_seconds": hidden.runtime_seconds,
                "hidden_iterations": hidden.iterations,
                "hidden_optimality_gap_nats": hidden.optimality_gap,
                "facet_runtime_seconds": inequality.runtime_seconds,
                "facet_iterations": inequality.iterations,
                "facet_optimality_gap_nats": inequality.optimality_gap,
                "facet_constraint_violation": inequality.constraint_violation,
                "cf_runtime_seconds": cf.runtime_seconds,
                "reduction_scope": scenario.reduction_scope,
            }
        )
    return pd.DataFrame(rows)


def context_removal_sweep(
    scenarios: Iterable[Scenario],
    facets: dict[str, FacetRepresentation],
    *,
    zero_tolerance: float = NUMERIC_ZERO,
) -> pd.DataFrame:
    """Exhaustively evaluate every design subcover with original weights."""

    rows: list[dict[str, object]] = []
    for scenario in scenarios:
        full_hidden = solve_hidden(scenario)
        _require_success(full_hidden)
        full_divergence = full_hidden.divergence
        scenario_rows: list[dict[str, object]] = []
        for bits in itertools.product((False, True), repeat=scenario.n_contexts):
            mask = np.asarray(bits, dtype=bool)
            channel = design_subcover_channel(scenario, mask)
            hidden = solve_hidden(scenario, channel=channel)
            inequality = solve_facets(
                scenario,
                channel=channel,
                facets=facets[scenario.key],
            )
            _require_success(hidden)
            _require_success(inequality)
            cf = contextual_fraction(scenario, channel=channel)
            _require_cf_success(cf)
            retained = [
                context.name
                for context, keep in zip(scenario.contexts, mask, strict=True)
                if keep
            ]
            omitted = [
                context.name
                for context, keep in zip(scenario.contexts, mask, strict=True)
                if not keep
            ]
            divergence = 0.0 if hidden.divergence <= zero_tolerance else hidden.divergence
            contextual = divergence > zero_tolerance
            mask_string = "".join("1" if value else "0" for value in mask)
            mask_integer = sum((1 << i) for i, value in enumerate(mask) if value)
            row = {
                "scenario": scenario.key,
                "mask_integer": mask_integer,
                "mask": mask_string,
                "retained_contexts": ";".join(retained),
                "omitted_contexts": ";".join(omitted),
                "n_retained": int(np.sum(mask)),
                "n_omitted": int(scenario.n_contexts - np.sum(mask)),
                "retained_design_weight": float(
                    np.dot(scenario.context_weights, mask.astype(float))
                ),
                "kl_hidden_nats": divergence,
                "kl_facets_nats": (
                    0.0 if inequality.divergence <= zero_tolerance else inequality.divergence
                ),
                "kl_formulation_gap": abs(hidden.divergence - inequality.divergence),
                "fmci_design": (
                    0.0
                    if full_divergence <= zero_tolerance
                    else float(np.clip(1.0 - divergence / full_divergence, 0.0, 1.0))
                ),
                "contextual_fraction": (
                    0.0
                    if cf.contextual_fraction <= zero_tolerance
                    else cf.contextual_fraction
                ),
                "extends_noncontextually": not contextual,
                "contextual": contextual,
                "is_full_cover": bool(np.all(mask)),
                "is_empty_cover": bool(not np.any(mask)),
                "hidden_optimality_gap_nats": hidden.optimality_gap,
                "facet_optimality_gap_nats": inequality.optimality_gap,
            }
            scenario_rows.append(row)

        by_mask = {str(row["mask"]): row for row in scenario_rows}
        for row in scenario_rows:
            mask = np.asarray([character == "1" for character in str(row["mask"])])
            immediate_submasks: list[str] = []
            for i, value in enumerate(mask):
                if value:
                    smaller = mask.copy()
                    smaller[i] = False
                    immediate_submasks.append(
                        "".join("1" if item else "0" for item in smaller)
                    )
            immediate_supermasks: list[str] = []
            for i, value in enumerate(mask):
                if not value:
                    larger = mask.copy()
                    larger[i] = True
                    immediate_supermasks.append(
                        "".join("1" if item else "0" for item in larger)
                    )
            row["is_minimal_contextual"] = bool(
                row["contextual"]
                and all(not by_mask[item]["contextual"] for item in immediate_submasks)
            )
            row["is_maximal_noncontextual"] = bool(
                row["extends_noncontextually"]
                and bool(immediate_supermasks)
                and all(by_mask[item]["contextual"] for item in immediate_supermasks)
            )
        rows.extend(scenario_rows)
    return pd.DataFrame(rows)


def context_criticality(context_removal: pd.DataFrame) -> pd.DataFrame:
    """Compute leave-one-out and Shapley information contributions."""

    rows: list[dict[str, object]] = []
    for scenario_key, frame in context_removal.groupby("scenario"):
        scenario = get_scenario(str(scenario_key))
        n = scenario.n_contexts
        divergence_by_mask = {
            int(row.mask_integer): float(row.kl_hidden_nats)
            for row in frame.itertuples()
        }
        full_mask = (1 << n) - 1
        full_divergence = divergence_by_mask[full_mask]
        if full_divergence <= 0.0:
            raise RuntimeError(f"full benchmark {scenario_key} is not contextual")
        denominator = factorial(n)
        for index, context in enumerate(scenario.contexts):
            without_mask = full_mask & ~(1 << index)
            after_removal = divergence_by_mask[without_mask]
            shapley = 0.0
            for subset_mask in range(1 << n):
                if subset_mask & (1 << index):
                    continue
                size = subset_mask.bit_count()
                coefficient = (
                    factorial(size) * factorial(n - size - 1) / denominator
                )
                with_context = subset_mask | (1 << index)
                shapley += coefficient * (
                    divergence_by_mask[with_context] - divergence_by_mask[subset_mask]
                )
            rows.append(
                {
                    "scenario": scenario_key,
                    "context": context.name,
                    "full_kl_nats": full_divergence,
                    "kl_after_removal_nats": after_removal,
                    "leave_one_out_fraction_lost": float(
                        np.clip(1.0 - after_removal / full_divergence, 0.0, 1.0)
                    ),
                    "remaining_contextual": after_removal > NUMERIC_ZERO,
                    "shapley_information_nats": shapley,
                    "shapley_share": shapley / full_divergence,
                }
            )
    result = pd.DataFrame(rows)
    for scenario_key, frame in result.groupby("scenario"):
        total = float(frame["shapley_information_nats"].sum())
        full = float(frame["full_kl_nats"].iloc[0])
        if not np.isclose(total, full, atol=2.0e-8, rtol=0.0):
            raise RuntimeError(
                f"Shapley contributions for {scenario_key} do not sum to full KL"
            )
    return result


def subcover_summary(context_removal: pd.DataFrame) -> pd.DataFrame:
    return (
        context_removal.groupby(["scenario", "n_retained"], as_index=False)
        .agg(
            n_subcovers=("mask", "count"),
            n_contextual=("contextual", "sum"),
            min_kl_nats=("kl_hidden_nats", "min"),
            max_kl_nats=("kl_hidden_nats", "max"),
            mean_kl_nats=("kl_hidden_nats", "mean"),
            min_fmci=("fmci_design", "min"),
            max_fmci=("fmci_design", "max"),
        )
        .sort_values(["scenario", "n_retained"])
        .reset_index(drop=True)
    )


def visibility_sweep(
    scenarios: Iterable[Scenario],
    facets: dict[str, FacetRepresentation],
    *,
    points: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    grid = np.linspace(0.0, 1.0, points)
    for scenario in scenarios:
        ideal = solve_hidden(scenario)
        _require_success(ideal)
        warm_reduced: np.ndarray | None = None
        warm_hidden: np.ndarray | None = None
        for visibility in grid:
            target, reduced = scenario.target_at_visibility(float(visibility))
            hidden = solve_hidden(
                scenario,
                target_flat=target,
                initial_weights=warm_hidden,
            )
            inequality = solve_facets(
                scenario,
                target_flat=target,
                target_reduced_hint=reduced,
                initial_reduced=warm_reduced,
                facets=facets[scenario.key],
            )
            _require_success(hidden)
            _require_success(inequality)
            warm_hidden = hidden.optimizer
            warm_reduced = inequality.optimizer
            cf = contextual_fraction(scenario, target_flat=target)
            _require_cf_success(cf)
            witness = witness_result(scenario, reduced)
            rows.append(
                {
                    "scenario": scenario.key,
                    "visibility": float(visibility),
                    "kl_hidden_nats": hidden.divergence,
                    "kl_facets_nats": inequality.divergence,
                    "kl_formulation_gap": abs(
                        hidden.divergence - inequality.divergence
                    ),
                    "kl_relative_to_ideal": hidden.divergence / ideal.divergence,
                    "contextual_fraction": cf.contextual_fraction,
                    "normalized_witness_violation": witness.normalized_violation,
                    "witness_value": witness.value,
                    "analytic_visibility_threshold": scenario.visibility_threshold,
                    "contextual_numeric": hidden.divergence > NUMERIC_ZERO,
                    "hidden_optimality_gap_nats": hidden.optimality_gap,
                    "facet_optimality_gap_nats": inequality.optimality_gap,
                }
            )
    return pd.DataFrame(rows)


def eta_alpha_sweep(
    scenario: Scenario,
    facets: FacetRepresentation,
    *,
    eta_points: int,
    alpha_points: int,
) -> pd.DataFrame:
    if scenario.key != "three_cycle":
        raise ValueError("eta-alpha sweep is defined only for the three-cycle")
    full = solve_hidden(scenario)
    _require_success(full)
    rows: list[dict[str, object]] = []
    for eta in np.linspace(0.0, 1.0, eta_points):
        warm: np.ndarray | None = None
        for alpha in np.linspace(0.0, 1.0, alpha_points):
            channel = three_cycle_eta_alpha_channel(
                scenario, float(eta), float(alpha)
            )
            result = solve_facets(
                scenario,
                channel=channel,
                initial_reduced=warm,
                facets=facets,
            )
            _require_success(result)
            warm = result.optimizer
            cf = contextual_fraction(scenario, channel=channel)
            _require_cf_success(cf)
            retained_fraction = result.divergence / full.divergence
            mean_efficiency = channel.target_mean_retention(scenario)
            a_min = channel.minimum_retention(scenario)
            a_max = channel.maximum_retention(scenario)
            lower = a_min * full.divergence
            upper = a_max * full.divergence
            theoretical_boundary = bool(
                np.isclose(eta, 0.0, atol=1.0e-15)
                or np.isclose(alpha, 0.0, atol=1.0e-15)
            )
            rows.append(
                {
                    "eta": float(eta),
                    "alpha": float(alpha),
                    "kl_observed_nats": result.divergence,
                    "kl_full_nats": full.divergence,
                    "retained_contextual_information": retained_fraction,
                    "fmci": float(np.clip(1.0 - retained_fraction, 0.0, 1.0)),
                    "target_mean_efficiency": mean_efficiency,
                    "minimum_cell_retention": a_min,
                    "maximum_cell_retention": a_max,
                    "rate_matched_residual": mean_efficiency - retained_fraction,
                    "contextual_fraction_observed": cf.contextual_fraction,
                    "sandwich_lower_nats": lower,
                    "sandwich_upper_nats": upper,
                    "lower_bound_margin_nats": result.divergence - lower,
                    "upper_bound_margin_nats": upper - result.divergence,
                    "exact_hiding_numeric": result.divergence <= NUMERIC_ZERO,
                    "theoretical_hiding_boundary": theoretical_boundary,
                    "facet_iterations": result.iterations,
                    "facet_optimality_gap_nats": result.optimality_gap,
                    "cf_runtime_seconds": cf.runtime_seconds,
                }
            )
    return pd.DataFrame(rows)


def eta_alpha_hidden_crosscheck(
    scenario: Scenario,
    facets: FacetRepresentation,
    *,
    random_points: int = 8,
    seed: int = 20260713,
) -> pd.DataFrame:
    fixed_points = [
        (0.2, 0.2),
        (0.5, 0.4),
        (0.7, 0.8),
        (1.0, 0.25),
        (1.0, 1.0),
        (0.0, 0.7),
        (0.8, 0.0),
    ]
    generator = np.random.default_rng(seed)
    sampled = [tuple(map(float, pair)) for pair in generator.random((random_points, 2))]
    points = fixed_points + sampled
    rows: list[dict[str, object]] = []
    for eta, alpha in points:
        channel = three_cycle_eta_alpha_channel(scenario, eta, alpha)
        hidden = solve_hidden(scenario, channel=channel)
        inequality = solve_facets(scenario, channel=channel, facets=facets)
        _require_success(hidden)
        _require_success(inequality)
        rows.append(
            {
                "eta": eta,
                "alpha": alpha,
                "kl_hidden_nats": hidden.divergence,
                "kl_facets_nats": inequality.divergence,
                "absolute_gap": abs(hidden.divergence - inequality.divergence),
                "hidden_iterations": hidden.iterations,
                "facet_iterations": inequality.iterations,
                "hidden_optimality_gap_nats": hidden.optimality_gap,
                "facet_optimality_gap_nats": inequality.optimality_gap,
            }
        )
    return pd.DataFrame(rows)


def formulation_runtime_benchmark(
    scenarios: Iterable[Scenario],
    facets: dict[str, FacetRepresentation],
    *,
    repetitions: int,
) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for scenario in scenarios:
        hidden_times: list[float] = []
        facet_times: list[float] = []
        hidden_result = solve_hidden(scenario)
        facet_result = solve_facets(scenario, facets=facets[scenario.key])
        _require_success(hidden_result)
        _require_success(facet_result)
        for _ in range(repetitions):
            started = time.perf_counter()
            hidden = solve_hidden(scenario)
            hidden_times.append(time.perf_counter() - started)
            _require_success(hidden)
            started = time.perf_counter()
            inequality = solve_facets(scenario, facets=facets[scenario.key])
            facet_times.append(time.perf_counter() - started)
            _require_success(inequality)
        observed_rows = scenario.n_events + scenario.n_contexts
        rows.extend(
            [
                {
                    "scenario": scenario.key,
                    "formulation": "hidden_V_representation",
                    "decision_variables": scenario.n_assignments,
                    "linear_equalities": 1,
                    "polytope_inequalities": scenario.n_assignments,
                    "observed_probability_rows": observed_rows,
                    "response_matrix_entries": observed_rows * scenario.n_assignments,
                    "setup_seconds": 0.0,
                    "median_runtime_seconds": statistics.median(hidden_times),
                    "minimum_runtime_seconds": min(hidden_times),
                    "maximum_runtime_seconds": max(hidden_times),
                    "iterations": hidden_result.iterations,
                    "optimality_gap_nats": hidden_result.optimality_gap,
                    "kl_nats": hidden_result.divergence,
                    "absolute_gap_to_other": abs(
                        hidden_result.divergence - facet_result.divergence
                    ),
                    "scope": "full deterministic-assignment model",
                },
                {
                    "scenario": scenario.key,
                    "formulation": "inequality_H_representation",
                    "decision_variables": scenario.reduced_dimension,
                    "linear_equalities": 0,
                    "polytope_inequalities": facets[scenario.key].n_facets
                    + 2 * scenario.reduced_dimension,
                    "observed_probability_rows": observed_rows,
                    "response_matrix_entries": observed_rows
                    * scenario.reduced_dimension,
                    "setup_seconds": facets[scenario.key].generation_seconds,
                    "median_runtime_seconds": statistics.median(facet_times),
                    "minimum_runtime_seconds": min(facet_times),
                    "maximum_runtime_seconds": max(facet_times),
                    "iterations": facet_result.iterations,
                    "optimality_gap_nats": facet_result.optimality_gap,
                    "kl_nats": facet_result.divergence,
                    "absolute_gap_to_other": abs(
                        hidden_result.divergence - facet_result.divergence
                    ),
                    "scope": scenario.reduction_scope,
                },
            ]
        )
    return pd.DataFrame(rows)


def cycle_complexity_scaling(max_observables: int = 15) -> pd.DataFrame:
    """Exact representation-size formulas for binary n-cycle models."""

    rows: list[dict[str, int]] = []
    for n in range(3, max_observables + 1):
        rows.append(
            {
                "observables_n": n,
                "contexts_n": n,
                "complete_local_event_rows": 4 * n,
                "hidden_assignment_variables": 2**n,
                "cycle_moment_variables": 2 * n,
                "local_positivity_inequalities": 4 * n,
                "cycle_inequalities": 2 ** (n - 1),
                "total_exact_cycle_H_inequalities": 4 * n + 2 ** (n - 1),
            }
        )
    return pd.DataFrame(rows)


def _monotonicity_min_increment(
    frame: pd.DataFrame,
    *,
    group: str,
    order: str,
    value: str,
) -> float:
    minima: list[float] = []
    for _, subset in frame.groupby(group):
        ordered = subset.sort_values(order)
        differences = np.diff(ordered[value].to_numpy(dtype=float))
        if len(differences):
            minima.append(float(np.min(differences)))
    return min(minima) if minima else 0.0


def validation_summary(
    summary: pd.DataFrame,
    context_removal: pd.DataFrame,
    criticality: pd.DataFrame,
    visibility: pd.DataFrame,
    eta_alpha: pd.DataFrame,
    eta_crosscheck: pd.DataFrame,
) -> dict[str, object]:
    proper_cover_results = {
        key: bool(
            context_removal.loc[
                (context_removal["scenario"] == key)
                & (~context_removal["is_full_cover"]),
                "extends_noncontextually",
            ].all()
        )
        for key in list_scenarios()
    }
    off_boundary = eta_alpha.loc[~eta_alpha["theoretical_hiding_boundary"]]
    boundary = eta_alpha.loc[eta_alpha["theoretical_hiding_boundary"]]
    alpha_one = eta_alpha.loc[np.isclose(eta_alpha["alpha"], 1.0)]
    mcar_gap = float(
        np.max(
            np.abs(
                alpha_one["kl_observed_nats"]
                - alpha_one["eta"] * alpha_one["kl_full_nats"]
            )
        )
    )
    shapley_errors = []
    for _, frame in criticality.groupby("scenario"):
        shapley_errors.append(
            abs(
                float(frame["shapley_information_nats"].sum())
                - float(frame["full_kl_nats"].iloc[0])
            )
        )
    return {
        "maximum_baseline_analytic_kl_gap": float(summary["kl_analytic_gap"].max()),
        "maximum_baseline_analytic_cf_gap": float(summary["cf_analytic_gap"].max()),
        "maximum_hidden_facet_gap": float(
            max(
                summary["kl_formulation_gap"].max(),
                context_removal["kl_formulation_gap"].max(),
                visibility["kl_formulation_gap"].max(),
                eta_crosscheck["absolute_gap"].max(),
            )
        ),
        "maximum_hidden_optimality_gap_nats": float(
            max(
                summary["hidden_optimality_gap_nats"].max(),
                context_removal["hidden_optimality_gap_nats"].max(),
                visibility["hidden_optimality_gap_nats"].max(),
                eta_crosscheck["hidden_optimality_gap_nats"].max(),
            )
        ),
        "maximum_facet_optimality_gap_nats": float(
            max(
                summary["facet_optimality_gap_nats"].max(),
                context_removal["facet_optimality_gap_nats"].max(),
                visibility["facet_optimality_gap_nats"].max(),
                eta_alpha["facet_optimality_gap_nats"].max(),
                eta_crosscheck["facet_optimality_gap_nats"].max(),
            )
        ),
        "all_proper_subcovers_noncontextual": proper_cover_results,
        "maximum_shapley_efficiency_error_nats": float(max(shapley_errors)),
        "eta_alpha_off_boundary_hiding_count": int(
            off_boundary["exact_hiding_numeric"].sum()
        ),
        "eta_alpha_boundary_nonhiding_count": int(
            (~boundary["exact_hiding_numeric"]).sum()
        ),
        "eta_alpha_maximum_lower_sandwich_violation_nats": float(
            max(0.0, -eta_alpha["lower_bound_margin_nats"].min())
        ),
        "eta_alpha_maximum_upper_sandwich_violation_nats": float(
            max(0.0, -eta_alpha["upper_bound_margin_nats"].min())
        ),
        "eta_alpha_mcar_line_maximum_gap_nats": mcar_gap,
        "eta_alpha_minimum_KL_increment_in_eta": _monotonicity_min_increment(
            eta_alpha,
            group="alpha",
            order="eta",
            value="kl_observed_nats",
        ),
        "eta_alpha_minimum_KL_increment_in_alpha": _monotonicity_min_increment(
            eta_alpha,
            group="eta",
            order="alpha",
            value="kl_observed_nats",
        ),
        "eta_alpha_minimum_CF_increment_in_eta": _monotonicity_min_increment(
            eta_alpha,
            group="alpha",
            order="eta",
            value="contextual_fraction_observed",
        ),
        "eta_alpha_minimum_CF_increment_in_alpha": _monotonicity_min_increment(
            eta_alpha,
            group="eta",
            order="alpha",
            value="contextual_fraction_observed",
        ),
    }


def _save_figure(figure: plt.Figure, base_path: Path) -> None:
    figure.tight_layout()
    figure.savefig(base_path.with_suffix(".png"), dpi=220, bbox_inches="tight")
    figure.savefig(base_path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(figure)


def _save_visibility_plots(frame: pd.DataFrame, figure_dir: Path) -> None:
    for scenario, subset in frame.groupby("scenario"):
        subset = subset.sort_values("visibility")
        figure, axis = plt.subplots(figsize=(7.2, 4.8))
        axis.plot(
            subset["visibility"],
            subset["kl_relative_to_ideal"],
            label="KL / ideal KL",
        )
        axis.plot(
            subset["visibility"],
            subset["contextual_fraction"],
            label="Contextual Fraction",
        )
        axis.plot(
            subset["visibility"],
            subset["normalized_witness_violation"],
            label="Normalized witness violation",
        )
        threshold = float(subset["analytic_visibility_threshold"].iloc[0])
        axis.axvline(threshold, linestyle="--", linewidth=1.0, label="NC threshold")
        axis.set_xlabel("Visibility")
        axis.set_ylabel("Normalized contextuality metric")
        axis.set_ylim(-0.02, 1.02)
        axis.set_title(f"Metric comparison: {scenario}")
        axis.legend()
        _save_figure(figure, figure_dir / f"visibility_metrics_{scenario}")


def _save_context_removal_plots(frame: pd.DataFrame, figure_dir: Path) -> None:
    for scenario, subset in frame.groupby("scenario"):
        full = float(subset.loc[subset["is_full_cover"], "kl_hidden_nats"].iloc[0])
        figure, axis = plt.subplots(figsize=(7.2, 4.8))
        axis.scatter(
            subset["n_retained"],
            subset["kl_hidden_nats"] / full,
            alpha=0.8,
        )
        axis.set_xlabel("Number of retained contexts")
        axis.set_ylabel("Retained KL contextuality / full KL")
        axis.set_ylim(-0.02, 1.05)
        axis.set_title(f"Exhaustive context removal: {scenario}")
        _save_figure(figure, figure_dir / f"context_removal_{scenario}")


def _pivot_eta_alpha(
    frame: pd.DataFrame,
    value: str,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    pivot = frame.pivot(index="alpha", columns="eta", values=value).sort_index()
    return (
        pivot.columns.to_numpy(dtype=float),
        pivot.index.to_numpy(dtype=float),
        pivot.to_numpy(dtype=float),
    )


def _save_eta_alpha_plots(frame: pd.DataFrame, figure_dir: Path) -> None:
    labels = {
        "kl_observed_nats": "Observed KL divergence (nats)",
        "fmci": "FMCI",
        "rate_matched_residual": "Rate-matched residual",
        "contextual_fraction_observed": "Transported Contextual Fraction",
    }
    for value, label in labels.items():
        eta, alpha, z = _pivot_eta_alpha(frame, value)
        figure, axis = plt.subplots(figsize=(7.2, 5.2))
        if value == "rate_matched_residual":
            maximum = float(np.max(np.abs(z)))
            levels = np.linspace(-maximum, maximum, 25) if maximum > 0 else 24
        else:
            levels = 24
        contour = axis.contourf(eta, alpha, z, levels=levels)
        figure.colorbar(contour, ax=axis, label=label)
        axis.set_xlabel(r"Baseline efficiency $\eta$")
        axis.set_ylabel(r"Bias parameter $\alpha$")
        axis.set_title(f"Three-cycle {label}")
        _save_figure(figure, figure_dir / f"eta_alpha_{value}")


def _save_runtime_plot(frame: pd.DataFrame, figure_dir: Path) -> None:
    pivot = frame.pivot(
        index="scenario", columns="formulation", values="median_runtime_seconds"
    )
    figure, axis = plt.subplots(figsize=(7.2, 4.8))
    pivot.plot(kind="bar", ax=axis)
    axis.set_ylabel("Median wall time per solve (seconds)")
    axis.set_xlabel("Scenario")
    axis.set_title("Formulation runtime comparison")
    axis.tick_params(axis="x", rotation=0)
    _save_figure(figure, figure_dir / "formulation_runtime")


def _save_complexity_plot(frame: pd.DataFrame, figure_dir: Path) -> None:
    figure, axis = plt.subplots(figsize=(7.2, 4.8))
    axis.semilogy(
        frame["observables_n"],
        frame["hidden_assignment_variables"],
        marker="o",
        label="Hidden variables: $2^n$",
    )
    axis.semilogy(
        frame["observables_n"],
        frame["total_exact_cycle_H_inequalities"],
        marker="s",
        label="Exact cycle H inequalities",
    )
    axis.set_xlabel("Number of binary observables $n$")
    axis.set_ylabel("Representation size (log scale)")
    axis.set_title("Exact binary-cycle representation growth")
    axis.legend()
    _save_figure(figure, figure_dir / "cycle_representation_scaling")


def _markdown_table(
    frame: pd.DataFrame,
    columns: Sequence[str],
    *,
    max_rows: int | None = None,
) -> str:
    table = frame.loc[:, columns].copy()
    if max_rows is not None:
        table = table.head(max_rows)

    def format_value(value: object) -> str:
        if isinstance(value, (float, np.floating)):
            return f"{float(value):.8g}"
        if isinstance(value, (bool, np.bool_)):
            return "yes" if bool(value) else "no"
        return str(value).replace("|", "\\|")

    header = "| " + " | ".join(columns) + " |"
    divider = "| " + " | ".join("---" for _ in columns) + " |"
    rows = [
        "| " + " | ".join(format_value(value) for value in row) + " |"
        for row in table.itertuples(index=False, name=None)
    ]
    return "\n".join([header, divider, *rows])


def _write_report(
    path: Path,
    summary: pd.DataFrame,
    context_removal: pd.DataFrame,
    criticality: pd.DataFrame,
    eta_alpha: pd.DataFrame,
    runtime: pd.DataFrame,
    validation: dict[str, object],
) -> None:
    subcover_counts = (
        context_removal.groupby("scenario", as_index=False)
        .agg(
            subcovers=("mask", "count"),
            contextual_subcovers=("contextual", "sum"),
            proper_contextual_subcovers=(
                "contextual",
                lambda values: int(values.sum()) - 1,
            ),
        )
    )
    eta_min_positive = eta_alpha.loc[
        (~eta_alpha["theoretical_hiding_boundary"])
        & (eta_alpha["kl_observed_nats"] > NUMERIC_ZERO),
        "kl_observed_nats",
    ].min()
    lines = [
        "# FMCI benchmark report",
        "",
        "This report is generated entirely by the code in this repository. The ",
        "hidden-variable and reduced inequality formulations are solved independently.",
        "",
        "## Canonical benchmark validation",
        "",
        _markdown_table(
            summary,
            [
                "scenario",
                "deterministic_assignments",
                "reduced_dimension",
                "facet_count",
                "kl_hidden_nats",
                "kl_analytic_nats",
                "kl_formulation_gap",
                "contextual_fraction",
            ],
        ),
        "",
        "The canonical analytic values are log(3/2) for the perfect-anticorrelation ",
        "3-cycle, the symmetric KCBS projection shown in the source, and log(6/5) ",
        "for the Peres–Mermin parity model.",
        "",
        "## Exhaustive context removal",
        "",
        _markdown_table(
            subcover_counts,
            ["scenario", "subcovers", "contextual_subcovers", "proper_contextual_subcovers"],
        ),
        "",
        "The design channel preserves the original context weights and maps each ",
        "omitted context to a deterministic star outcome. Thus these values quantify ",
        "loss relative to the intended full design rather than a renormalized experiment.",
        "",
        "### Context criticality",
        "",
        _markdown_table(
            criticality,
            [
                "scenario",
                "context",
                "leave_one_out_fraction_lost",
                "shapley_information_nats",
                "shapley_share",
            ],
        ),
        "",
        "## Three-cycle MNAR scan",
        "",
        f"Grid points: {len(eta_alpha):,}.",
        f" Smallest positive off-boundary observed divergence: {eta_min_positive:.8g} nats.",
        f" Off-boundary numerical hiding count: {validation['eta_alpha_off_boundary_hiding_count']}.",
        " Exact population hiding occurs only on the eta=0 or alpha=0 boundary for this family.",
        "",
        "The scan exports observed KL, FMCI, the signed rate-matched residual, ",
        "transported Contextual Fraction, cellwise erasure-sandwich bounds, and solver certificates.",
        "",
        "## Formulation comparison",
        "",
        _markdown_table(
            runtime,
            [
                "scenario",
                "formulation",
                "decision_variables",
                "polytope_inequalities",
                "setup_seconds",
                "median_runtime_seconds",
                "absolute_gap_to_other",
            ],
        ),
        "",
        "Facet-generation time is reported separately from repeated solve time. The ",
        "3-cycle and magic-square H-representations are symmetry reductions valid for ",
        "the benchmark families declared in `reduction_scope`; the hidden formulation ",
        "always retains the full deterministic assignment model.",
        "",
        "## Numerical validation summary",
        "",
        "```json",
        json.dumps(validation, indent=2, sort_keys=True),
        "```",
        "",
        "## Reproduce",
        "",
        "```bash",
        "python -m pip install -e '.[dev]'",
        "pytest",
        "fmci-benchmarks --config configs/default.yaml",
        "```",
        "",
    ]
    path.write_text("\n".join(lines))


def _write_manifest(output_dir: Path) -> None:
    entries: list[str] = []
    for path in sorted(output_dir.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(f"{digest}  {path.relative_to(output_dir).as_posix()}")
    (output_dir / "SHA256SUMS").write_text("\n".join(entries) + "\n")


def run_all(
    output_dir: Path,
    *,
    visibility_points: int = 101,
    eta_points: int = 51,
    alpha_points: int = 51,
    runtime_repetitions: int = 25,
) -> dict[str, object]:
    if min(visibility_points, eta_points, alpha_points) < 2:
        raise ValueError("all scan grids require at least two points")
    if runtime_repetitions < 1:
        raise ValueError("runtime_repetitions must be positive")

    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir = output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)

    scenarios = [get_scenario(key) for key in list_scenarios()]
    facets = {
        scenario.key: facet_representation(scenario.reduced_vertices)
        for scenario in scenarios
    }

    summary = benchmark_summary(scenarios, facets)
    context_removal = context_removal_sweep(scenarios, facets)
    criticality = context_criticality(context_removal)
    subcovers = subcover_summary(context_removal)
    visibility = visibility_sweep(scenarios, facets, points=visibility_points)
    three_cycle = get_scenario("three_cycle")
    eta_alpha = eta_alpha_sweep(
        three_cycle,
        facets[three_cycle.key],
        eta_points=eta_points,
        alpha_points=alpha_points,
    )
    eta_crosscheck = eta_alpha_hidden_crosscheck(
        three_cycle, facets[three_cycle.key]
    )
    runtime = formulation_runtime_benchmark(
        scenarios, facets, repetitions=runtime_repetitions
    )
    complexity = cycle_complexity_scaling()
    validation = validation_summary(
        summary,
        context_removal,
        criticality,
        visibility,
        eta_alpha,
        eta_crosscheck,
    )

    tables = {
        "benchmark_summary.csv": summary,
        "context_removal.csv": context_removal,
        "context_criticality.csv": criticality,
        "subcover_summary.csv": subcovers,
        "visibility_sweep.csv": visibility,
        "eta_alpha_scan.csv": eta_alpha,
        "eta_alpha_formulation_crosscheck.csv": eta_crosscheck,
        "formulation_runtime.csv": runtime,
        "cycle_complexity_scaling.csv": complexity,
    }
    for filename, frame in tables.items():
        frame.to_csv(output_dir / filename, index=False)

    _save_visibility_plots(visibility, figure_dir)
    _save_context_removal_plots(context_removal, figure_dir)
    _save_eta_alpha_plots(eta_alpha, figure_dir)
    _save_runtime_plot(runtime, figure_dir)
    _save_complexity_plot(complexity, figure_dir)

    metadata = {
        "generated_at_utc": datetime.now(UTC).isoformat(),
        "fmci_benchmarks_version": _package_version(),
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pandas": pd.__version__,
        "matplotlib": plt.matplotlib.__version__,
        "visibility_points": visibility_points,
        "eta_points": eta_points,
        "alpha_points": alpha_points,
        "runtime_repetitions": runtime_repetitions,
        "scenario_metadata": {
            scenario.key: {
                "title": scenario.title,
                "contexts": [context.name for context in scenario.contexts],
                "observables": list(scenario.observable_names),
                "deterministic_assignments": scenario.n_assignments,
                "reduced_dimension": scenario.reduced_dimension,
                "reduced_vertices": facets[scenario.key].n_vertices,
                "facets": facets[scenario.key].n_facets,
                "facet_generation_seconds": facets[scenario.key].generation_seconds,
                "visibility_threshold": scenario.visibility_threshold,
                "reduction_scope": scenario.reduction_scope,
            }
            for scenario in scenarios
        },
    }
    _json_dump(output_dir / "run_metadata.json", metadata)
    _json_dump(output_dir / "validation_summary.json", validation)

    headline = {
        "canonical_results": summary[
            [
                "scenario",
                "kl_hidden_nats",
                "kl_analytic_nats",
                "contextual_fraction",
                "normalized_witness_violation",
            ]
        ].to_dict(orient="records"),
        "all_proper_subcovers_noncontextual": validation[
            "all_proper_subcovers_noncontextual"
        ],
        "any_off_boundary_exact_hiding": bool(
            validation["eta_alpha_off_boundary_hiding_count"]
        ),
        "maximum_hidden_facet_gap": validation["maximum_hidden_facet_gap"],
        "maximum_analytic_kl_gap": validation["maximum_baseline_analytic_kl_gap"],
    }
    _json_dump(output_dir / "headline_results.json", headline)
    _write_report(
        output_dir / "REPORT.md",
        summary,
        context_removal,
        criticality,
        eta_alpha,
        runtime,
        validation,
    )
    _write_manifest(output_dir)
    return headline
